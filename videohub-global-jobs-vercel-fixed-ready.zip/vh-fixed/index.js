import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import crypto from 'crypto';
import os from 'os';
import { URL } from 'url';
import { initDatabase, persistToMongo, refreshFromMongo, memoryStore, isDbLive } from './db.js';
import * as adminService from './admin.js';
import { SEED_PLANS } from './seed-data.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const app = express();
// Vercel / Netlify / AWS Lambda: read-only disk, instances can be stale, no long-lived process
const IS_SERVERLESS = Boolean(process.env.VERCEL || process.env.NETLIFY || process.env.AWS_LAMBDA_FUNCTION_NAME);
const PORT = Number(process.env.PORT) || 3001;

// Fail closed in production: never sign sessions with a predictable fallback secret.
if (process.env.NODE_ENV === 'production' && !process.env.MONGODB_URI) {
  throw new Error('MONGODB_URI is required in production; in-memory storage is not safe for production data.');
}
if (process.env.NODE_ENV === 'production' && (!process.env.AUTH_SECRET || process.env.AUTH_SECRET.length < 32)) {
  throw new Error('AUTH_SECRET must be set to a random value of at least 32 characters in production.');
}
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-site');
  if (process.env.NODE_ENV === 'production') res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));
app.use(cookieParser());

// Cookie-authenticated state changes must originate from this deployment.
// Bearer-token clients are not vulnerable to browser cookie CSRF.
function configuredOrigins() {
  const values = [process.env.APP_URL, process.env.URL, process.env.DEPLOY_PRIME_URL, process.env.SITE_URL];
  return new Set(values.filter(Boolean).map(value => {
    try { return new URL(value).origin; } catch { return null; }
  }).filter(Boolean));
}
app.use('/api', (req, res, next) => {
  const isMutation = !['GET', 'HEAD', 'OPTIONS'].includes(req.method);
  const hasCookieSession = Boolean(req.cookies?.auth_token);
  if (process.env.NODE_ENV === 'production' && isMutation && hasCookieSession && !req.headers.authorization) {
    const origin = req.headers.origin;
    const allowed = configuredOrigins();
    if (!origin || !allowed.has(origin)) {
      return res.status(403).json({ error: 'Request origin is not permitted.' });
    }
  }
  next();
});

// Per-instance abuse protection. For serverless deployments, also enable platform/WAF rate limits.
const requestBuckets = new Map();
function rateLimit({ windowMs = 15 * 60 * 1000, max = 10 } = {}) {
  return (req, res, next) => {
    const key = `${req.ip || req.socket.remoteAddress}:${req.path}`;
    const now = Date.now();
    let bucket = requestBuckets.get(key);
    if (!bucket || now - bucket.startedAt >= windowMs) bucket = { startedAt: now, count: 0 };
    bucket.count += 1;
    requestBuckets.set(key, bucket);
    if (requestBuckets.size > 5000) {
      for (const [k, v] of requestBuckets) if (now - v.startedAt >= windowMs) requestBuckets.delete(k);
    }
    res.setHeader('RateLimit-Limit', String(max));
    res.setHeader('RateLimit-Remaining', String(Math.max(0, max - bucket.count)));
    if (bucket.count > max) return res.status(429).json({ error: 'Too many requests. Please try again later.' });
    next();
  };
}
const authRateLimit = rateLimit({ windowMs: 15 * 60 * 1000, max: 8 });
const writeRateLimit = rateLimit({ windowMs: 15 * 60 * 1000, max: 120 });
app.use('/api', (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  return writeRateLimit(req, res, next);
});

// This project currently has demo billing/creator-revenue flows, not a verified
// payment processor + webhook ledger. Never let demo balances become real money.
function requireLivePayments(req, res, next) {
  if (process.env.NODE_ENV === 'production') {
    return res.status(503).json({ error: 'Payments are not enabled. Configure a real payment provider and verified webhooks before enabling this feature.' });
  }
  next();
}

// Connect to MongoDB Atlas (loads saved data / seeds on first run) or use the in-memory store
const dbReady = initDatabase().catch(err => {
  console.warn('[Server] DB initialization notice:', err.message);
  return false;
});

// Before each API request: wait for the DB load. On serverless (Vercel) every instance
// can hold stale data, so refresh from MongoDB first. After any write request, save to
// MongoDB BEFORE the response is sent, because serverless functions freeze afterwards.
app.use('/api', async (req, res, next) => {
  try {
    const live = await dbReady;
    if (!live && process.env.NODE_ENV === 'production') {
      return res.status(503).json({ error: 'Persistent database is unavailable. Please try again shortly.' });
    }
    if (live) {
      if (IS_SERVERLESS) {
        await refreshFromMongo(req.method === 'GET' ? 4000 : 0);
      }
      if (req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'OPTIONS') {
        const originalEnd = res.end.bind(res);
        res.end = (...args) => {
          persistToMongo().finally(() => originalEnd(...args));
          return res;
        };
      }
    }
  } catch (err) {
    console.error('[Server] DB sync error:', err.message);
    if (process.env.NODE_ENV === 'production') {
      return res.status(503).json({ error: 'Database synchronization failed. Please retry shortly.' });
    }
  }
  next();
});

// Default-deny protection runs after the DB has loaded/refreshed the user store.
// Only account bootstrap/sign-in endpoints are public; all other writes require
// a valid active user session.
app.use('/api', (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const publicAuthPaths = new Set(['/auth/register', '/auth/login', '/auth/google', '/auth/logout']);
  if (publicAuthPaths.has(req.path)) return next();
  if (!getCurrentUser(req)) return res.status(401).json({ error: 'Authentication required.' });
  next();
});

// ----------------------------------------------------
// Auth helpers: signed session tokens + scrypt password hashing
// ----------------------------------------------------
const AUTH_SECRET = process.env.AUTH_SECRET || (process.env.NODE_ENV === 'production' ? null : crypto.randomBytes(48).toString('hex'));
if (!AUTH_SECRET) throw new Error('AUTH_SECRET is required.');

function signToken(userId) {
  const payload = Buffer.from(JSON.stringify({ id: userId, exp: Date.now() + 12 * 60 * 60 * 1000 })).toString('base64url');
  const sig = crypto.createHmac('sha256', AUTH_SECRET).update(payload).digest('base64url');
  return payload + '.' + sig;
}

function verifyToken(token) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const [payload, sig] = token.split('.');
  const expected = crypto.createHmac('sha256', AUTH_SECRET).update(payload).digest('base64url');
  const a = Buffer.from(sig || '');
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (!data.id || data.exp < Date.now()) return null;
    return data.id;
  } catch {
    return null;
  }
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return salt + ':' + hash;
}

function checkPassword(password, stored) {
  if (!stored || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  const test = crypto.scryptSync(String(password || ''), salt, 64);
  const known = Buffer.from(hash, 'hex');
  return test.length === known.length && crypto.timingSafeEqual(test, known);
}

function publicUser(user) {
  if (!user) return user;
  const { passwordHash, googleId, sessionVersion, ...safe } = user;
  return safe;
}

function setAuthCookie(res, userId) {
  const token = signToken(userId);
  res.cookie('auth_token', token, {
    httpOnly: true,
    path: '/',
    maxAge: 12 * 60 * 60 * 1000,
    sameSite: 'strict',
    secure: process.env.NODE_ENV === 'production'
  });
  return token;
}

// Resolve the current user from a signed token (cookie or Authorization header)
function getCurrentUser(req, fallbackToDemo = false) {
  const authHeader = req.headers.authorization;
  const bearer = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;
  for (const token of [bearer, req.cookies?.auth_token]) {
    const userId = verifyToken(token);
    if (userId) {
      const user = memoryStore.users.find(u => u.id === userId);
      if (user && user.status === 'active') return user;
    }
  }
  if (fallbackToDemo) {
    return memoryStore.users.find(u => u.id === 'u-candidate1') || memoryStore.users[0];
  }
  return null;
}

// ----------------------------------------------------
// Health Check Endpoint
// ----------------------------------------------------
app.get('/api/health', async (_req, res) => {
  const databaseReady = await dbReady;
  const healthy = process.env.NODE_ENV !== 'production' || databaseReady;
  res.status(healthy ? 200 : 503).json({
    status: healthy ? 'ok' : 'degraded',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
    database: isDbLive() ? 'MongoDB Atlas Connected' : (process.env.NODE_ENV === 'production' ? 'Unavailable' : 'In-Memory Development Store'),
    version: '2.4.0'
  });
});

// ----------------------------------------------------
// Authentication Routes
// ----------------------------------------------------
app.post('/api/auth/register', authRateLimit, (req, res) => {
  try {
    const { name, username, email, password, country, phone, role, avatar } = req.body || {};
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required.' });
    }
    const bounded = { name: 80, username: 40, email: 254, country: 100, phone: 40, avatar: 2048 };
    for (const [field, max] of Object.entries(bounded)) {
      const value = req.body?.[field];
      if (value !== undefined && (typeof value !== 'string' || value.length > max)) {
        return res.status(400).json({ error: `Invalid ${field} value.` });
      }
    }
    if (String(name).trim().length < 2 || typeof password !== 'string' || password.length < 12 || password.length > 128) {
      return res.status(400).json({ error: 'Name must be at least 2 characters and password must be 12–128 characters.' });
    }
    const cleanEmail = String(email).toLowerCase().trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }
    if (String(password).length < 12 || String(password).length > 128) {
      return res.status(400).json({ error: 'Password must be 12–128 characters long.' });
    }
    const cleanUsername = String(username || cleanEmail.split('@')[0]).trim().toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '') || ('user_' + Date.now());

    const existing = memoryStore.users.find(u =>
      (u.username || '').toLowerCase() === cleanUsername || (u.email || '').toLowerCase() === cleanEmail);
    if (existing) {
      return res.status(409).json({ error: 'Username or email already registered.' });
    }

    const newUser = {
      id: 'u-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6),
      name: String(name).trim(),
      username: cleanUsername,
      email: cleanEmail,
      passwordHash: hashPassword(String(password)),
      avatar: avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop&crop=faces',
      banner: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&h=400&fit=crop',
      bio: 'Passionate ' + (role === 'employer' ? 'recruiter' : role === 'creator' ? 'content creator' : 'professional') + ' on VideoHub + Global Jobs.',
      country: country || 'Worldwide',
      phone: phone || '',
      role: (role === 'employer' || role === 'creator' ? role : 'user'),
      verified: false,
      membershipPlan: 'free',
      subscribersCount: 0,
      followingCount: 0,
      status: 'active',
      createdAt: new Date().toISOString()
    };

    memoryStore.users.unshift(newUser);
    const token = setAuthCookie(res, newUser.id);
    res.json({ success: true, user: publicUser(newUser), token });
  } catch (err) {
    console.error('[Register] Error:', err);
    res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
});

app.post('/api/auth/login', authRateLimit, (req, res) => {
  try {
    const { emailOrUsername, password } = req.body || {};
    if (typeof emailOrUsername !== 'string' || emailOrUsername.length > 254 || typeof password !== 'string' || password.length > 128) {
      return res.status(400).json({ error: 'Valid email/username and password are required.' });
    }

    const identifier = String(emailOrUsername).toLowerCase().trim();
    const user = memoryStore.users.find(u =>
      (u.email || '').toLowerCase() === identifier ||
      (u.username || '').toLowerCase() === identifier ||
      u.id === identifier);

    if (!user) {
      return res.status(401).json({ error: 'Invalid email/username or password.' });
    }
    if (!user.passwordHash) {
      return res.status(401).json({ error: 'This demo account cannot be used for production sign-in. Register a password-protected account.' });
    }

    if (user.status !== 'active') {
      return res.status(403).json({ error: 'This account has been suspended by administration.' });
    }

    if (!checkPassword(password, user.passwordHash)) {
      return res.status(401).json({ error: 'Invalid email/username or password.' });
    }

    const token = setAuthCookie(res, user.id);
    res.json({ success: true, user: publicUser(user), token });
  } catch (err) {
    console.error('[Login] Error:', err);
    res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

app.post('/api/auth/google', authRateLimit, async (req, res) => {
  try {
    const idToken = req.body?.idToken;
    const clientId = process.env.GOOGLE_CLIENT_ID;
    if (!clientId) return res.status(503).json({ error: 'Google sign-in is not configured on this server.' });
    if (typeof idToken !== 'string' || idToken.length > 10000) {
      return res.status(400).json({ error: 'A valid Google ID token is required.' });
    }

    // Verify the signed token with Google's tokeninfo endpoint; never trust profile fields from the browser.
    const response = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(idToken)}`, { signal: AbortSignal.timeout(5000) });
    if (!response.ok) return res.status(401).json({ error: 'Google identity verification failed.' });
    const claims = await response.json();
    const validIssuer = claims.iss === 'https://accounts.google.com' || claims.iss === 'accounts.google.com';
    const expiresAt = Number(claims.exp) * 1000;
    if (!validIssuer || claims.aud !== clientId || !Number.isFinite(expiresAt) || expiresAt <= Date.now() || claims.email_verified !== 'true' || !claims.sub || !claims.email) {
      return res.status(401).json({ error: 'Google identity token is invalid or not verified.' });
    }

    const userEmail = String(claims.email).toLowerCase().trim();
    const adminEmails = (process.env.ADMIN_EMAILS || '').split(',').map(v => v.trim().toLowerCase()).filter(Boolean);
    let user = memoryStore.users.find(u => (u.email || '').toLowerCase() === userEmail);
    if (!user) {
      const cleanUsername = userEmail.split('@')[0].replace(/[^a-z0-9_]/g, '_');
      user = {
        id: 'u-google-' + crypto.randomUUID(), name: claims.name || cleanUsername, username: cleanUsername,
        email: userEmail, avatar: claims.picture || '', banner: '', bio: 'Verified Google Account on VideoHub + Global Jobs.',
        country: '', phone: '', role: adminEmails.includes(userEmail) ? 'admin' : 'user', verified: true,
        membershipPlan: 'free', authProvider: 'google', googleId: claims.sub,
        subscribersCount: 0, followingCount: 0, status: 'active', createdAt: new Date().toISOString()
      };
      memoryStore.users.unshift(user);
    } else {
      if (user.status !== 'active') return res.status(403).json({ error: 'This account is not active.' });
      user.authProvider = 'google';
      user.googleId = claims.sub;
      user.verified = true;
      if (adminEmails.includes(userEmail)) user.role = 'admin';
    }

    const gToken = setAuthCookie(res, user.id);
    return res.json({ success: true, user: publicUser(user), token: gToken, message: 'Google identity verified.' });
  } catch (err) {
    console.error('[Google Auth] Verification error:', err.message);
    return res.status(503).json({ error: 'Google sign-in verification is temporarily unavailable.' });
  }
});

app.post('/api/auth/logout', (_req, res) => {
  res.clearCookie('auth_token', { httpOnly: true, path: '/', sameSite: 'strict', secure: process.env.NODE_ENV === 'production' });
  res.json({ success: true });
});

app.get('/api/auth/me', (req, res) => {
  const user = getCurrentUser(req);
  res.json({ user: publicUser(user), authenticated: !!user });
});

app.put('/api/auth/profile', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const { name, bio, country, avatar, banner } = req.body || {};
  const values = { name, bio, country, avatar, banner };
  const limits = { name: 80, bio: 1000, country: 100, avatar: 2048, banner: 2048 };
  for (const [key, value] of Object.entries(values)) {
    if (value !== undefined && (typeof value !== 'string' || value.length > limits[key])) {
      return res.status(400).json({ error: `Invalid ${key} value.` });
    }
  }
  if (name !== undefined) {
    if (name.trim().length < 2) return res.status(400).json({ error: 'Name is too short.' });
    user.name = name.trim();
  }
  if (bio !== undefined) user.bio = bio;
  if (country !== undefined) user.country = country;
  if (avatar !== undefined) user.avatar = avatar;
  if (banner !== undefined) user.banner = banner;
  res.json({ success: true, user: publicUser(user) });
});

// ----------------------------------------------------
// Media Streaming API (Robust HTTP 206 Range & Caching Support)
// ----------------------------------------------------
const BUNDLED_VIDEO_DIR = path.resolve(__dirname, 'public', 'videos');
// Vercel / serverless file systems are read-only except /tmp
const UPLOAD_DIR = IS_SERVERLESS ? path.join(os.tmpdir(), 'videohub-uploads') : BUNDLED_VIDEO_DIR;
const ALLOWED_VIDEO_EXT = ['.mp4', '.webm', '.mov', '.mkv', '.m4v'];
const MAX_UPLOAD_BYTES = 100 * 1024 * 1024;

function ensureUploadDir() {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

function pickVideoExt(fileName, contentType) {
  const type = String(contentType || '').toLowerCase();
  if (type.includes('webm')) return '.webm';
  if (type.includes('quicktime')) return '.mov';
  const ext = path.extname(String(fileName || '')).toLowerCase();
  return ALLOWED_VIDEO_EXT.includes(ext) ? ext : '.mp4';
}

app.get(['/api/media/stream/:name', '/videos/:name'], (req, res) => {
  const fileName = path.basename(req.params.name);
  const candidates = [
    path.join(UPLOAD_DIR, fileName),
    path.join(BUNDLED_VIDEO_DIR, fileName)
  ];
  let filePath = candidates.find(f => fs.existsSync(f));

  if (!filePath) {
    // On serverless hosts the bundled sample videos are served as static files from /videos
    if (IS_SERVERLESS && req.path.startsWith('/api/media/')) {
      return res.redirect(302, '/videos/' + encodeURIComponent(fileName));
    }
    return res.status(404).send('Video not found');
  }

  const finalExt = path.extname(filePath).toLowerCase();
  const contentType = finalExt === '.webm' ? 'video/webm' : finalExt === '.mov' ? 'video/quicktime' : 'video/mp4';

  res.sendFile(filePath, {
    acceptRanges: true,
    cacheControl: true,
    maxAge: 86400000,
    headers: {
      'Accept-Ranges': 'bytes',
      'Content-Type': contentType
    }
  }, (err) => {
    if (err && err.code !== 'ECONNABORTED' && err.syscall !== 'write') {
      if (!res.headersSent) {
        res.status(err.status || 500).end();
      }
    }
  });
});

// ----------------------------------------------------
// Cloudinary direct upload (signed). Bypasses serverless body-size limits and
// stores videos permanently. Falls back to local/server upload when not configured.
// ----------------------------------------------------
function cloudinaryConfig() {
  const cloudName = process.env.CLOUDINARY_CLOUD_NAME;
  const apiKey = process.env.CLOUDINARY_API_KEY;
  const apiSecret = process.env.CLOUDINARY_API_SECRET;
  const placeholder = v => !v || /^(demo-cloud|your-|123456789012345)/.test(v);
  if (placeholder(cloudName) || placeholder(apiKey) || placeholder(apiSecret)) return null;
  return { cloudName, apiKey, apiSecret };
}

app.get('/api/upload/config', (_req, res) => {
  res.json({ provider: cloudinaryConfig() ? 'cloudinary' : 'server' });
});

app.post('/api/upload/sign', rateLimit({ windowMs: 60 * 60 * 1000, max: 20 }), (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to upload videos.' });
  const cfg = cloudinaryConfig();
  if (!cfg) return res.status(501).json({ error: 'Cloudinary is not configured.', serverless: IS_SERVERLESS });

  const timestamp = Math.floor(Date.now() / 1000);
  const folder = 'videohub/' + user.id;
  // Restrict server-signed upload parameters; Cloudinary credentials never reach the browser.
  const toSign = `folder=${folder}&timestamp=${timestamp}`;
  const signature = crypto.createHash('sha1').update(toSign + cfg.apiSecret).digest('hex');

  res.json({
    provider: 'cloudinary',
    cloudName: cfg.cloudName,
    apiKey: cfg.apiKey,
    timestamp,
    folder,
    signature,
    uploadUrl: `https://api.cloudinary.com/v1_1/${cfg.cloudName}/video/upload`
  });
});

// ----------------------------------------------------
// Video Upload Endpoints (Binary Raw, Base64 JSON & /api/upload)
// ----------------------------------------------------
async function saveVideoBuffer(buffer, fileName, contentType) {
  if (IS_SERVERLESS && !cloudinaryConfig()) {
    const e = new Error('Durable video storage is not configured. Configure Cloudinary before enabling uploads on serverless hosting.');
    e.status = 503;
    throw e;
  }
  if (!buffer || buffer.length === 0) {
    const e = new Error('No video data was received.');
    e.status = 400;
    throw e;
  }
  if (buffer.length > MAX_UPLOAD_BYTES) {
    const e = new Error('Video is too large. Maximum size is 100MB.');
    e.status = 413;
    throw e;
  }
  // Basic file-signature validation; extension/MIME values supplied by browsers are untrusted.
  const isWebm = buffer.length >= 4 && buffer.subarray(0, 4).equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3]));
  const isMp4Family = buffer.length >= 12 && buffer.toString('ascii', 4, 8) === 'ftyp';
  if (!isWebm && !isMp4Family) {
    const e = new Error('Unsupported or invalid video file. Upload a valid MP4, MOV, M4V, WebM or MKV file.');
    e.status = 415;
    throw e;
  }
  ensureUploadDir();
  const safeName = `upload-${Date.now()}-${Math.random().toString(36).substring(2, 7)}${pickVideoExt(fileName, contentType)}`;
  await fs.promises.writeFile(path.join(UPLOAD_DIR, safeName), buffer);
  return safeName;
}

function requireSignedIn(req, res, next) {
  if (!getCurrentUser(req)) return res.status(401).json({ error: 'Please sign in first.' });
  next();
}

const handleVideoRawUpload = async (req, res) => {
  try {
    if (!getCurrentUser(req)) {
      return res.status(401).json({ error: 'Please sign in to upload videos.' });
    }
    let rawFileName = req.query.filename || req.headers['x-filename'] || 'video.mp4';
    try { rawFileName = decodeURIComponent(String(rawFileName)); } catch {}
    const isShortParam = req.query.isShort === 'true';

    let buffer;
    if (Buffer.isBuffer(req.body) && req.body.length > 0) {
      buffer = req.body;
    } else if (typeof req.body === 'string' && req.body.startsWith('data:')) {
      buffer = Buffer.from(req.body.replace(/^data:[^;]+;base64,/, ''), 'base64');
    } else if (req.body && typeof req.body.base64Data === 'string') {
      buffer = Buffer.from(req.body.base64Data.replace(/^data:[^;]+;base64,/, ''), 'base64');
    }

    const safeName = await saveVideoBuffer(buffer, rawFileName, req.headers['content-type']);
    res.json({
      success: true,
      url: `/api/media/stream/${safeName}`,
      fileName: safeName,
      size: buffer.length,
      isShort: isShortParam
    });
  } catch (err) {
    console.error('[Upload-Raw] Error:', err);
    res.status(err.status || 500).json({ error: err.message || 'Server failed to save the video.' });
  }
};

app.post(['/api/videos/upload-raw', '/api/upload'], rateLimit({ windowMs: 60 * 60 * 1000, max: 10 }), requireSignedIn, express.raw({ type: () => true, limit: '100mb' }), handleVideoRawUpload);

app.post('/api/videos/upload', rateLimit({ windowMs: 60 * 60 * 1000, max: 10 }), async (req, res) => {
  try {
    if (!getCurrentUser(req)) {
      return res.status(401).json({ error: 'Please sign in to upload videos.' });
    }
    const { filename, base64Data, isShort } = req.body || {};
    if (!base64Data) {
      return res.status(400).json({ error: 'Missing base64Data' });
    }
    const buffer = Buffer.from(String(base64Data).replace(/^data:[^;]+;base64,/, ''), 'base64');
    const safeName = await saveVideoBuffer(buffer, filename, '');
    res.json({
      success: true,
      url: `/api/media/stream/${safeName}`,
      fileName: safeName,
      size: buffer.length,
      isShort: Boolean(isShort)
    });
  } catch (err) {
    console.error('[Upload-JSON] Error:', err);
    res.status(err.status || 500).json({ error: err.message || 'Server failed to process video.' });
  }
});

// ----------------------------------------------------
// Videos API
// ----------------------------------------------------
app.get('/api/videos', (req, res) => {
  const { category, search, creatorId, isShort } = req.query;
  let results = memoryStore.videos.filter(v => v.visibility === 'public' && v.moderationStatus === 'approved');

  if (isShort !== undefined) {
    const shortBool = isShort === 'true';
    results = results.filter(v => v.isShort === shortBool);
  }

  if (category && category !== 'All') {
    const catLower = String(category).toLowerCase().trim();
    results = results.filter(v => {
      const vCat = (v.category || '').toLowerCase();
      if (vCat === catLower) return true;
      if (vCat.includes(catLower) || catLower.includes(vCat)) return true;
      // Tag matching
      if (v.tags && v.tags.some(t => t.toLowerCase() === catLower || t.toLowerCase().includes(catLower))) return true;
      // Topic alias matches
      if (catLower === 'technology' && (vCat.includes('software') || vCat.includes('it') || v.tags?.some(t => ['tech', 'technology', 'bim', 'ai', 'cnc', 'robotics', 'hardware'].includes(t.toLowerCase())))) return true;
      if (catLower === 'education' && (vCat.includes('masterclass') || vCat.includes('academy') || v.title?.toLowerCase().includes('masterclass') || v.title?.toLowerCase().includes('course') || v.title?.toLowerCase().includes('explained') || v.tags?.some(t => ['tutorial', 'masterclass', 'education', 'learning', 'training'].includes(t.toLowerCase())))) return true;
      if (catLower === 'gaming' && (vCat.includes('gaming') || vCat.includes('simulator') || v.tags?.some(t => ['gaming', 'game', 'simulation', 'unrealengine5', 'simulator', 'tournament', 'physics'].includes(t.toLowerCase())) || v.title?.toLowerCase().includes('tournament') || v.title?.toLowerCase().includes('simulator'))) return true;
      if (catLower === 'design' && (vCat.includes('design') || vCat.includes('drafting') || vCat.includes('autocad') || vCat.includes('creative') || vCat.includes('parametric') || v.tags?.some(t => ['design', 'autocad', 'drafting', 'architecture', 'parametric', 'uiux'].includes(t.toLowerCase())))) return true;
      if ((catLower.includes('bim') || catLower.includes('cad')) && (vCat.includes('bim') || vCat.includes('cad') || vCat.includes('revit') || v.tags?.some(t => ['bim', 'revit', 'autocad', 'cad'].includes(t.toLowerCase())))) return true;
      if (catLower === 'construction' && (vCat.includes('construction') || vCat.includes('site') || v.tags?.some(t => ['construction', 'rigging', 'safety'].includes(t.toLowerCase())))) return true;
      if (catLower === 'fabrication' && (vCat.includes('fabrication') || vCat.includes('manufacturing') || v.tags?.some(t => ['fabrication', 'cnc', 'manufacturing', 'extrusions', 'aluminium'].includes(t.toLowerCase())))) return true;
      return false;
    });
  }

  if (creatorId) {
    results = results.filter(v => v.creatorId === creatorId);
  }

  if (search) {
    const q = String(search).toLowerCase();
    results = results.filter(v =>
      v.title.toLowerCase().includes(q) ||
      v.description.toLowerCase().includes(q) ||
      v.tags.some(t => t.toLowerCase().includes(q)) ||
      v.creator.name.toLowerCase().includes(q)
    );
  }

  const user = getCurrentUser(req);
  const enriched = results.map(v => ({
    ...v,
    isLiked: memoryStore.likedVideos.some(lv => lv.userId === user?.id && lv.videoId === v.id),
    isReposted: (memoryStore.reposts || []).some(r => r.userId === user?.id && r.videoId === v.id),
    repostsCount: (memoryStore.reposts || []).filter(r => r.videoId === v.id).length
  }));

  res.json({ videos: enriched, total: enriched.length });
});

app.get('/api/shorts', (req, res) => {
  const shorts = memoryStore.videos.filter(v => v.isShort && v.visibility === 'public');
  const user = getCurrentUser(req);
  const enriched = shorts.map(s => ({
    ...s,
    isLiked: memoryStore.likedVideos.some(lv => lv.userId === user?.id && lv.videoId === s.id),
    isReposted: (memoryStore.reposts || []).some(r => r.userId === user?.id && r.videoId === s.id),
    repostsCount: (memoryStore.reposts || []).filter(r => r.videoId === s.id).length
  }));
  res.json({ shorts: enriched });
});

app.get('/api/videos/:id', (req, res) => {
  const video = memoryStore.videos.find(v => v.id === req.params.id);
  if (!video) return res.status(404).json({ error: 'Video not found' });

  // Increment views
  video.views += 1;
  const user = getCurrentUser(req);
  const isLiked = memoryStore.likedVideos.some(lv => lv.userId === user?.id && lv.videoId === video.id);
  const isReposted = (memoryStore.reposts || []).some(r => r.userId === user?.id && r.videoId === video.id);
  const repostsCount = (memoryStore.reposts || []).filter(r => r.videoId === video.id).length;

  // Recommendations: same category or popular
  const related = memoryStore.videos
    .filter(v => v.id !== video.id && !v.isShort && v.visibility === 'public')
    .slice(0, 8)
    .map(v => ({
      ...v,
      isLiked: memoryStore.likedVideos.some(lv => lv.userId === user?.id && lv.videoId === v.id),
      isReposted: (memoryStore.reposts || []).some(r => r.userId === user?.id && r.videoId === v.id),
      repostsCount: (memoryStore.reposts || []).filter(r => r.videoId === v.id).length
    }));

  res.json({ video: { ...video, isLiked, isReposted, repostsCount }, related });
});

app.post('/api/videos', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to publish videos.' });

  const { title, description, category, tags, duration, isShort, visibility, commentsEnabled, videoUrl, thumbnailUrl } = req.body;
  if (!title) return res.status(400).json({ error: 'Video title is required' });

  if (typeof title !== 'string' || title.trim().length < 2 || title.length > 160) return res.status(400).json({ error: 'Video title must be 2–160 characters.' });
  if (description !== undefined && (typeof description !== 'string' || description.length > 5000)) return res.status(400).json({ error: 'Video description is too long or invalid.' });
  if (videoUrl !== undefined && (typeof videoUrl !== 'string' || videoUrl.length > 2048 || !(/^(https:\/\/|\/api\/media\/stream\/)/i).test(videoUrl))) {
    return res.status(400).json({ error: 'Video URL must be an HTTPS URL or a valid local media path.' });
  }
  const shortFlag = Boolean(isShort);
  
  // Ensure videoUrl is never a dead blob URL
  let resolvedVideoUrl = videoUrl;
  if (!resolvedVideoUrl || resolvedVideoUrl.startsWith('blob:') || !resolvedVideoUrl.trim()) {
    resolvedVideoUrl = shortFlag 
      ? '/api/media/stream/video2.mp4' 
      : '/api/media/stream/video1.mp4';
  }

  // Ensure thumbnailUrl is valid
  let resolvedThumb = thumbnailUrl;
  if (!resolvedThumb || resolvedThumb.startsWith('blob:') || !resolvedThumb.trim()) {
    resolvedThumb = shortFlag
      ? 'https://images.unsplash.com/photo-1506157786151-b8491531f063?w=600&h=1000&fit=crop'
      : 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&h=450&fit=crop';
  }

  const newVideo = {
    id: (shortFlag ? 'v-short-up-' : 'v-up-') + Date.now(),
    title,
    description: description || '',
    videoUrl: resolvedVideoUrl,
    thumbnailUrl: resolvedThumb,
    duration: duration || (shortFlag ? '0:35' : '10:00'),
    category: category || (shortFlag ? 'Curtain Wall & Glazing' : 'Aluminium & Façade Engineering'),
    tags: Array.isArray(tags) ? tags : typeof tags === 'string' ? tags.split(',').map((t) => t.trim()).filter(Boolean) : ['VideoHub', shortFlag ? 'Shorts' : 'Video'],
    creatorId: user.id,
    creator: {
      name: user.name,
      username: user.username,
      avatar: user.avatar,
      verified: user.verified,
      role: user.role
    },
    views: 1,
    likesCount: 0,
    commentsCount: 0,
    isShort: shortFlag,
    visibility: visibility || 'public',
    commentsEnabled: commentsEnabled !== false,
    processingStatus: 'ready',
    moderationStatus: 'pending',
    createdAt: new Date().toISOString()
  };

  memoryStore.videos.unshift(newVideo);

  // Generate video ready notification
  memoryStore.notifications.unshift({
    id: 'notif-v-' + Date.now(),
    recipientId: user.id,
    type: 'video_ready',
    title: shortFlag ? '⚡ Short Published Successfully!' : '🎬 Video Published Successfully',
    message: shortFlag
      ? 'Your Short "' + newVideo.title + '" is now live in the global Shorts reel.'
      : 'Your video "' + newVideo.title + '" is live and ready for streaming.',
    link: shortFlag ? '/shorts' : '/watch/' + newVideo.id,
    read: false,
    createdAt: new Date().toISOString()
  });

  res.json({ success: true, video: newVideo });
});

app.delete('/api/videos/:id', (req, res) => {
  const user = getCurrentUser(req);
  const index = memoryStore.videos.findIndex(v => v.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Video not found' });

  const video = memoryStore.videos[index];
  if (!user || (video.creatorId !== user.id && user.role !== 'admin')) {
    return res.status(403).json({ error: 'Unauthorized to delete this video' });
  }

  // If local uploaded file exists, delete it
  if (video.videoUrl && video.videoUrl.startsWith('/api/media/stream/upload-')) {
    const fName = path.basename(video.videoUrl);
    const p = path.resolve(__dirname, 'public', 'videos', fName);
    if (fs.existsSync(p)) {
      try { fs.unlinkSync(p); } catch (e) {}
    }
  }

  memoryStore.videos.splice(index, 1);
  res.json({ success: true, message: 'Video deleted successfully' });
});

app.post('/api/videos/:id/like', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to like videos' });

  const video = memoryStore.videos.find(v => v.id === req.params.id);
  if (!video) return res.status(404).json({ error: 'Video not found' });

  const existingIdx = memoryStore.likedVideos.findIndex(lv => lv.userId === user.id && lv.videoId === video.id);
  let isLiked = false;

  if (existingIdx > -1) {
    memoryStore.likedVideos.splice(existingIdx, 1);
    video.likesCount = Math.max(0, video.likesCount - 1);
  } else {
    memoryStore.likedVideos.push({ userId: user.id, videoId: video.id });
    video.likesCount += 1;
    isLiked = true;

    // Trigger notification to creator if not self
    if (video.creatorId !== user.id) {
      memoryStore.notifications.unshift({
        id: 'notif-like-' + Date.now(),
        recipientId: video.creatorId,
        actorId: user.id,
        actorName: user.name,
        actorAvatar: user.avatar,
        type: 'like',
        title: 'New Like on your Video',
        message: user.name + ' liked "' + video.title + '"',
        link: '/watch/' + video.id,
        read: false,
        createdAt: new Date().toISOString()
      });
    }
  }

  res.json({ success: true, isLiked, likesCount: video.likesCount });
});

// ----------------------------------------------------
// Video Live Engagement Reactions (Like, Laugh, Fire, etc.)
// ----------------------------------------------------
app.get('/api/videos/:id/reactions', (req, res) => {
  const videoId = req.params.id;
  const video = memoryStore.videos.find(v => v.id === videoId);
  const baseLikes = video ? video.likesCount : 50;

  if (!memoryStore.reactions) {
    memoryStore.reactions = {};
  }

  if (!memoryStore.reactions[videoId]) {
    memoryStore.reactions[videoId] = {
      counts: {
        like: Math.max(15, Math.round(baseLikes * 0.8)),
        laugh: Math.max(8, Math.round(baseLikes * 0.35)),
        fire: Math.max(28, Math.round(baseLikes * 1.05)),
        mindblown: Math.max(5, Math.round(baseLikes * 0.25)),
        rocket: Math.max(9, Math.round(baseLikes * 0.3)),
        clap: Math.max(12, Math.round(baseLikes * 0.4))
      },
      userReactions: {}
    };
  }

  const user = getCurrentUser(req);
  const userList = user && memoryStore.reactions[videoId].userReactions[user.id]
    ? memoryStore.reactions[videoId].userReactions[user.id]
    : [];

  const counts = memoryStore.reactions[videoId].counts;
  const total = Object.values(counts).reduce((a, b) => a + b, 0);

  res.json({
    success: true,
    videoId,
    reactions: counts,
    userReactions: userList,
    totalReactions: total
  });
});

app.post('/api/videos/:id/react', (req, res) => {
  const videoId = req.params.id;
  const { type, count = 1 } = req.body;
  const validTypes = ['like', 'laugh', 'fire', 'mindblown', 'rocket', 'clap'];

  if (!validTypes.includes(type)) {
    return res.status(400).json({ error: `Invalid reaction type. Must be one of: ${validTypes.join(', ')}` });
  }

  if (!memoryStore.reactions) {
    memoryStore.reactions = {};
  }

  const video = memoryStore.videos.find(v => v.id === videoId);
  const baseLikes = video ? video.likesCount : 50;

  if (!memoryStore.reactions[videoId]) {
    memoryStore.reactions[videoId] = {
      counts: {
        like: Math.max(15, Math.round(baseLikes * 0.8)),
        laugh: Math.max(8, Math.round(baseLikes * 0.35)),
        fire: Math.max(28, Math.round(baseLikes * 1.05)),
        mindblown: Math.max(5, Math.round(baseLikes * 0.25)),
        rocket: Math.max(9, Math.round(baseLikes * 0.3)),
        clap: Math.max(12, Math.round(baseLikes * 0.4))
      },
      userReactions: {}
    };
  }

  const increment = Math.max(1, Math.min(Number(count) || 1, 20));
  memoryStore.reactions[videoId].counts[type] = (memoryStore.reactions[videoId].counts[type] || 0) + increment;

  const user = getCurrentUser(req);
  if (user) {
    if (!memoryStore.reactions[videoId].userReactions[user.id]) {
      memoryStore.reactions[videoId].userReactions[user.id] = [];
    }
    if (!memoryStore.reactions[videoId].userReactions[user.id].includes(type)) {
      memoryStore.reactions[videoId].userReactions[user.id].push(type);
    }
  }

  const counts = memoryStore.reactions[videoId].counts;
  const total = Object.values(counts).reduce((a, b) => a + b, 0);

  res.json({
    success: true,
    videoId,
    reaction: type,
    increment,
    reactions: counts,
    userReactions: user ? memoryStore.reactions[videoId].userReactions[user.id] : [type],
    totalReactions: total
  });
});


app.get('/api/videos/:id/comments', (req, res) => {
  const comments = memoryStore.comments.filter(c => c.videoId === req.params.id);
  res.json({ comments });
});

app.post('/api/videos/:id/comments', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to comment' });

  const video = memoryStore.videos.find(v => v.id === req.params.id);
  if (!video) return res.status(404).json({ error: 'Video not found' });

  const { text } = req.body;
  if (!text || !text.trim()) return res.status(400).json({ error: 'Comment cannot be blank' });

  const newComment = {
    id: 'c-' + Date.now(),
    videoId: video.id,
    userId: user.id,
    user: {
      name: user.name,
      username: user.username,
      avatar: user.avatar,
      verified: user.verified
    },
    text: text.trim(),
    likesCount: 0,
    createdAt: new Date().toISOString()
  };

  memoryStore.comments.unshift(newComment);
  video.commentsCount += 1;

  if (video.creatorId !== user.id) {
    memoryStore.notifications.unshift({
      id: 'notif-com-' + Date.now(),
      recipientId: video.creatorId,
      actorId: user.id,
      actorName: user.name,
      actorAvatar: user.avatar,
      type: 'comment',
      title: 'New Comment',
      message: user.name + ' commented on "' + video.title + '": "' + text.slice(0, 60) + '..."',
      link: '/watch/' + video.id,
      read: false,
      createdAt: new Date().toISOString()
    });
  }

  res.json({ success: true, comment: newComment });
});

// ----------------------------------------------------
// Video Repost API
// ----------------------------------------------------
app.get('/api/videos/:id/reposts', (req, res) => {
  const reposts = (memoryStore.reposts || []).filter(r => r.videoId === req.params.id);
  res.json({ reposts });
});

app.post('/api/videos/:id/repost', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to repost videos' });

  const video = memoryStore.videos.find(v => v.id === req.params.id);
  if (!video) return res.status(404).json({ error: 'Video not found' });

  if (!memoryStore.reposts) memoryStore.reposts = [];

  const { quoteText } = req.body || {};
  const existingIdx = memoryStore.reposts.findIndex(r => r.userId === user.id && r.videoId === video.id);

  let isReposted = false;
  let newRepost = null;

  if (existingIdx > -1 && !quoteText) {
    // Toggle off simple repost
    memoryStore.reposts.splice(existingIdx, 1);
    isReposted = false;
  } else {
    // If updating quote or creating new repost
    if (existingIdx > -1) {
      memoryStore.reposts.splice(existingIdx, 1);
    }

    newRepost = {
      id: 'rep-' + Date.now(),
      videoId: video.id,
      userId: user.id,
      user: {
        name: user.name,
        username: user.username,
        avatar: user.avatar,
        verified: user.verified,
        role: user.role
      },
      quoteText: quoteText ? quoteText.trim() : undefined,
      createdAt: new Date().toISOString()
    };

    memoryStore.reposts.unshift(newRepost);
    isReposted = true;

    // Notify creator if not self
    if (video.creatorId !== user.id) {
      memoryStore.notifications.unshift({
        id: 'notif-rep-' + Date.now(),
        recipientId: video.creatorId,
        actorId: user.id,
        actorName: user.name,
        actorAvatar: user.avatar,
        type: 'like',
        title: 'Video Reposted',
        message: user.name + ' reposted your video "' + video.title + '"' + (quoteText ? ': "' + quoteText.slice(0, 50) + '..."' : ''),
        link: '/watch/' + video.id,
        read: false,
        createdAt: new Date().toISOString()
      });
    }
  }

  const count = memoryStore.reposts.filter(r => r.videoId === video.id).length;
  res.json({ success: true, isReposted, repostsCount: count, repost: newRepost });
});

app.get('/api/creators/:username/reposts', (req, res) => {
  const targetUser = memoryStore.users.find(u => u.username.toLowerCase() === req.params.username.toLowerCase());
  if (!targetUser) return res.status(404).json({ error: 'User not found' });

  const userReposts = (memoryStore.reposts || []).filter(r => r.userId === targetUser.id);
  const repostedVideos = userReposts.map(rep => {
    const vid = memoryStore.videos.find(v => v.id === rep.videoId);
    return vid ? { ...vid, repostDetails: rep } : null;
  }).filter(Boolean);

  res.json({ reposts: userReposts, repostedVideos });
});

// ----------------------------------------------------
// Creator Monetization & Partner Program API
// ----------------------------------------------------
function getOrCreateCreatorMonetization(userId) {
  if (!memoryStore.creatorMonetization) {
    memoryStore.creatorMonetization = {};
  }

  if (!memoryStore.creatorMonetization[userId]) {
    const user = memoryStore.users.find(u => u.id === userId);
    const isAdmin = user?.role === 'admin' || userId === 'u-admin';
    const isCreatorPlus = user?.membershipPlan === 'pro_creator' || user?.membershipPlan === 'creator_plus' || isAdmin;
    const subsCount = user?.subscribersCount || (isAdmin ? 28400 : 820);

    memoryStore.creatorMonetization[userId] = {
      eligibility: {
        isEligible: subsCount >= 1000 || isCreatorPlus,
        status: (isCreatorPlus || isAdmin) ? 'active' : subsCount >= 1000 ? 'eligible' : 'under_review',
        currentSubscribers: subsCount,
        requiredSubscribers: 1000,
        currentWatchHours: isAdmin ? 6420 : 3480,
        requiredWatchHours: 4000,
        currentShortsViews: isAdmin ? 1420000 : 640000,
        requiredShortsViews: 10000000,
        twoStepVerification: true,
        communityGuidelinesCompliant: true,
        termsAcceptedDate: (isCreatorPlus || isAdmin) ? '2025-01-15T08:00:00Z' : undefined
      },
      totalEstimatedRevenue: isAdmin ? 4890.50 : 1280.40,
      pendingBalance: isAdmin ? 520.00 : 140.00,
      availableCashoutBalance: isAdmin ? 2450.00 : 680.00,
      lifetimeEarnings: isAdmin ? 18450.00 : 3420.00,
      currency: 'USD',
      rpm: isAdmin ? 3.85 : 3.20,
      cpm: isAdmin ? 7.20 : 6.40,
      adsEnabledGlobally: true,
      revenueBreakdown: {
        watchPageAds: isAdmin ? 2650.00 : 680.00,
        shortsFeedAds: isAdmin ? 680.50 : 210.40,
        channelMemberships: isAdmin ? 820.00 : 180.00,
        liveGiftDrops: isAdmin ? 490.00 : 120.00,
        superThanksTips: isAdmin ? 250.00 : 90.00,
        sponsoredDeals: isAdmin ? 1000.00 : 0.00
      },
      payoutMethod: {
        type: 'iban',
        accountName: user?.name || 'Shafi Afzal Shah',
        details: 'SA82 **** **** **** 4892'
      },
      recentTransactions: [
        {
          id: 'tx-101',
          type: 'ad_revenue',
          amount: 284.50,
          description: 'September 2026 YouTube-style Watch Page Ad Share (55%)',
          date: new Date(Date.now() - 3600000 * 48).toISOString(),
          status: 'completed'
        },
        {
          id: 'tx-102',
          type: 'super_thanks',
          amount: 50.00,
          description: 'Super Thanks tip on "Spider Fitting Deflection Masterclass"',
          date: new Date(Date.now() - 3600000 * 24).toISOString(),
          status: 'completed'
        },
        {
          id: 'tx-103',
          type: 'gift_winnings',
          amount: 140.00,
          description: 'Live Match Winnings & Subscriber Gift Coin Conversion',
          date: new Date(Date.now() - 3600000 * 12).toISOString(),
          status: 'completed'
        },
        {
          id: 'tx-104',
          type: 'payout',
          amount: -1200.00,
          description: 'Monthly Disbursal to Bank IBAN (SA82...4892)',
          date: new Date(Date.now() - 3600000 * 240).toISOString(),
          status: 'completed'
        }
      ]
    };
  }

  return memoryStore.creatorMonetization[userId];
}

app.get('/api/creator/monetization', (req, res) => {
  if (process.env.NODE_ENV === 'production') return res.status(503).json({ error: 'Creator monetization is not enabled until a verified payment and accounting system is configured.' });
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to view monetization' });

  const data = getOrCreateCreatorMonetization(user.id);
  res.json({ success: true, monetization: data, user: publicUser(user) });
});

app.post('/api/creator/monetization/apply', (req, res, next) => {
  if (process.env.NODE_ENV === 'production') return requireLivePayments(req, res, next);
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to apply for monetization' });

  const { termsAccepted, paymentMethod } = req.body;
  if (!termsAccepted) {
    return res.status(400).json({ error: 'You must accept the World Video Hub Creator Monetization Terms and Conditions' });
  }

  const data = getOrCreateCreatorMonetization(user.id);
  data.eligibility.status = 'active';
  data.eligibility.isEligible = true;
  data.eligibility.termsAcceptedDate = new Date().toISOString();
  data.adsEnabledGlobally = true;

  if (paymentMethod) {
    data.payoutMethod = paymentMethod;
  }

  // Update user role if regular user
  if (user.role === 'user') {
    user.role = 'creator';
  }

  memoryStore.notifications.unshift({
    id: 'notif-mon-' + Date.now(),
    recipientId: user.id,
    type: 'membership',
    title: '🎉 Monetization Approved!',
    message: 'Welcome to the World Video Hub Partner Program. Your channel is now earning revenue.',
    link: '/monetization',
    read: false,
    createdAt: new Date().toISOString()
  });

  res.json({ success: true, message: 'Monetization activated successfully!', monetization: data });
});

app.post('/api/creator/monetization/payout', (req, res, next) => {
  if (process.env.NODE_ENV === 'production') return requireLivePayments(req, res, next);
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to request a payout' });

  const { amount, payoutType, details, accountName } = req.body;
  const numAmount = Number(amount);
  const data = getOrCreateCreatorMonetization(user.id);

  if (!numAmount || numAmount < 50) {
    return res.status(400).json({ error: 'Minimum cash-out threshold is $50.00 USD' });
  }

  if (numAmount > data.availableCashoutBalance) {
    return res.status(400).json({ error: `Insufficient available balance. You have $${data.availableCashoutBalance.toFixed(2)} available.` });
  }

  data.availableCashoutBalance -= numAmount;
  data.pendingBalance += numAmount;

  const newPayoutTx = {
    id: 'tx-payout-' + Date.now(),
    type: 'payout',
    amount: -numAmount,
    description: `Cashout Request via ${payoutType.toUpperCase()} (${details ? details.slice(-4) : 'Direct'})`,
    date: new Date().toISOString(),
    status: 'processing'
  };

  data.recentTransactions.unshift(newPayoutTx);

  if (details) {
    data.payoutMethod = {
      type: payoutType || 'iban',
      accountName: accountName || user.name,
      details: details
    };
  }

  res.json({ success: true, message: `Payout request for $${numAmount.toFixed(2)} submitted. Disbursed per Terms within 1-3 business days.`, monetization: data });
});

app.post('/api/videos/:id/super-thanks', (req, res, next) => {
  if (process.env.NODE_ENV === 'production') return requireLivePayments(req, res, next);
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to send Super Thanks' });

  const video = memoryStore.videos.find(v => v.id === req.params.id);
  if (!video) return res.status(404).json({ error: 'Video not found' });

  const { amount, message } = req.body;
  const tipAmount = Math.max(2, Number(amount) || 5);

  // Credit creator earnings (70% share)
  const creatorData = getOrCreateCreatorMonetization(video.creatorId);
  const creatorShare = Number((tipAmount * 0.7).toFixed(2));
  creatorData.availableCashoutBalance += creatorShare;
  creatorData.totalEstimatedRevenue += creatorShare;
  creatorData.lifetimeEarnings += creatorShare;
  creatorData.revenueBreakdown.superThanksTips += creatorShare;

  // Log transaction
  creatorData.recentTransactions.unshift({
    id: 'tx-tip-' + Date.now(),
    type: 'super_thanks',
    amount: creatorShare,
    description: `Super Thanks from ${user.name} on "${video.title.slice(0, 30)}..."`,
    date: new Date().toISOString(),
    status: 'completed'
  });

  // Post a special highlighted golden comment
  const superComment = {
    id: 'com-tip-' + Date.now(),
    videoId: video.id,
    userId: user.id,
    user: {
      name: user.name,
      username: user.username,
      avatar: user.avatar,
      verified: user.verified
    },
    text: `💖 Super Thanks ($${tipAmount.toFixed(2)}): ${message || 'Thank you for this engineering masterclass!'}`,
    likesCount: 1,
    isSuperThanks: true,
    tipAmount: tipAmount,
    createdAt: new Date().toISOString()
  };

  memoryStore.comments.unshift(superComment);
  video.commentsCount += 1;

  // Notify creator
  memoryStore.notifications.unshift({
    id: 'notif-tip-' + Date.now(),
    recipientId: video.creatorId,
    actorId: user.id,
    actorName: user.name,
    actorAvatar: user.avatar,
    type: 'like',
    title: `💖 Super Thanks Received ($${tipAmount.toFixed(2)})!`,
    message: `${user.name} sent you a $${tipAmount.toFixed(2)} Super Thanks tip on "${video.title}"!`,
    link: '/watch/' + video.id,
    read: false,
    createdAt: new Date().toISOString()
  });

  res.json({ success: true, comment: superComment, tipAmount, creatorShare });
});

app.put('/api/videos/:id/monetization', (req, res) => {
  const user = getCurrentUser(req);
  const video = memoryStore.videos.find(v => v.id === req.params.id);
  if (!video) return res.status(404).json({ error: 'Video not found' });

  if (video.creatorId !== user?.id && user?.role !== 'admin') {
    return res.status(403).json({ error: 'Unauthorized to change video monetization' });
  }

  const { isMonetized } = req.body;
  video.isMonetized = Boolean(isMonetized);

  res.json({ success: true, videoId: video.id, isMonetized: video.isMonetized });
});

// ----------------------------------------------------
// Live Match Arena & Subscriber Gift Winnings API
// ----------------------------------------------------
app.get('/api/live-matches', (_req, res) => {
  const matches = (memoryStore.liveMatches || []).map(m => ({
    id: m.id,
    title: m.title,
    category: m.category,
    status: m.status,
    viewersCount: m.viewersCount,
    subscribersCount: m.subscribersCount,
    winningsPool: m.winningsPool,
    host: m.host,
    opponent: m.opponent,
    hasActiveDrop: Boolean(m.activeDrop && m.activeDrop.remainingClaims > 0)
  }));
  res.json({ matches });
});

app.get('/api/live-matches/:id', (req, res) => {
  const match = (memoryStore.liveMatches || []).find(m => m.id === req.params.id);
  if (!match) return res.status(404).json({ error: 'Live match room not found' });
  res.json({ match });
});

app.post('/api/live-matches/:id/gift', (req, res, next) => {
  if (process.env.NODE_ENV === 'production') return requireLivePayments(req, res, next);
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to send gifts in live match' });

  const match = (memoryStore.liveMatches || []).find(m => m.id === req.params.id);
  if (!match) return res.status(404).json({ error: 'Live match room not found' });

  const { giftId, targetTeam, isSubscriber } = req.body;
  if (!giftId || !targetTeam || !['red', 'blue'].includes(targetTeam)) {
    return res.status(400).json({ error: 'Gift and valid target team (red/blue) required' });
  }

  const giftCatalog = {
    rose: { name: 'Rose', icon: '🌹', cost: 10, basePoints: 10 },
    espresso: { name: 'Espresso', icon: '☕', cost: 50, basePoints: 50 },
    wrench: { name: 'Golden Wrench', icon: '🔧', cost: 200, basePoints: 200 },
    rocket: { name: 'Turbo Rocket', icon: '🚀', cost: 500, basePoints: 500 },
    trophy: { name: 'Victory Cup', icon: '🏆', cost: 1200, basePoints: 1200 },
    galaxy: { name: 'Galaxy Blast', icon: '🌌', cost: 3000, basePoints: 3000, exclusiveSubscriber: true },
    crown: { name: 'Crown of Legends', icon: '👑', cost: 5000, basePoints: 5000, exclusiveSubscriber: true }
  };

  const gift = giftCatalog[giftId] || giftCatalog.rose;

  // Calculate Multiplier:
  // Subscribers get 2x bonus!
  // Speed challenge mode gives 2x bonus!
  let multiplier = 1;
  const isSub = Boolean(isSubscriber || user.membershipPlan !== 'free');
  if (isSub) multiplier *= 2;
  if (match.status === 'speed_challenge') multiplier *= 2;

  const pointsAwarded = gift.basePoints * multiplier;

  // Add points to team score
  if (targetTeam === 'red') {
    match.host.score += pointsAwarded;
    match.host.subscribersGiftingCount = (match.host.subscribersGiftingCount || 0) + (isSub ? 1 : 0);
  } else {
    match.opponent.score += pointsAwarded;
    match.opponent.subscribersGiftingCount = (match.opponent.subscribersGiftingCount || 0) + (isSub ? 1 : 0);
  }

  // Add 80% of gift cost to Subscriber Winnings Pool!
  const poolAddition = Math.round(gift.cost * 0.8);
  match.winningsPool += poolAddition;

  // Record gift event
  const giftEvent = {
    id: 'gift-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6),
    userId: user.id,
    userName: user.name,
    userAvatar: user.avatar,
    giftId,
    giftName: gift.name,
    giftIcon: gift.icon,
    giftCost: gift.cost,
    points: pointsAwarded,
    multiplier,
    targetTeam,
    createdAt: new Date().toISOString()
  };

  if (!match.recentGifts) match.recentGifts = [];
  match.recentGifts.unshift(giftEvent);
  if (match.recentGifts.length > 25) match.recentGifts.pop();

  // Update top donor
  if (!match.topDonors) match.topDonors = [];
  const existingDonor = match.topDonors.find(d => d.userId === user.id && d.targetTeam === targetTeam);
  if (existingDonor) {
    existingDonor.totalPoints += pointsAwarded;
    existingDonor.isSubscriber = isSub;
  } else {
    match.topDonors.push({
      userId: user.id,
      userName: user.name,
      userAvatar: user.avatar,
      targetTeam,
      totalPoints: pointsAwarded,
      isSubscriber: isSub
    });
  }
  match.topDonors.sort((a, b) => b.totalPoints - a.totalPoints);
  match.topDonors = match.topDonors.slice(0, 10);

  // If high-value gift sent, trigger Lucky Mystery Drop for subscribers!
  if (gift.cost >= 500 && (!match.activeDrop || match.activeDrop.remainingClaims <= 0)) {
    match.activeDrop = {
      id: 'drop-' + Date.now(),
      title: '🎁 ' + gift.name.toUpperCase() + ' LUCKY COIN DROP!',
      prizeCoins: Math.min(500, Math.round(gift.cost * 0.5)),
      remainingClaims: 15,
      totalClaims: 15,
      expiresAt: new Date(Date.now() + 1000 * 120).toISOString(),
      claimedByUserIds: []
    };
  }

  res.json({
    success: true,
    giftEvent,
    pointsAwarded,
    multiplier,
    winningsPool: match.winningsPool,
    hostScore: match.host.score,
    opponentScore: match.opponent.score,
    activeDrop: match.activeDrop
  });
});

app.post('/api/live-matches/:id/claim-drop', (req, res, next) => {
  if (process.env.NODE_ENV === 'production') return requireLivePayments(req, res, next);
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to claim winnings' });

  const match = (memoryStore.liveMatches || []).find(m => m.id === req.params.id);
  if (!match || !match.activeDrop) {
    return res.status(400).json({ error: 'No active mystery drop in this room' });
  }

  const drop = match.activeDrop;
  if (drop.remainingClaims <= 0) {
    return res.status(400).json({ error: 'All mystery drop rewards have already been claimed!' });
  }

  if (drop.claimedByUserIds.includes(user.id)) {
    return res.status(400).json({ error: 'You have already claimed this drop!' });
  }

  drop.remainingClaims -= 1;
  drop.claimedByUserIds.push(user.id);

  // Record subscriber winning notification
  memoryStore.notifications.unshift({
    id: 'notif-' + Date.now(),
    recipientId: user.id,
    type: 'system',
    title: '🎉 Gift Winnings Claimed!',
    message: 'You won ' + drop.prizeCoins + ' Coins from the Live Match Mystery Drop!',
    link: '/live-match',
    read: false,
    createdAt: new Date().toISOString()
  });

  res.json({
    success: true,
    prizeCoins: drop.prizeCoins,
    remainingClaims: drop.remainingClaims,
    message: 'Congratulations! You won ' + drop.prizeCoins + ' Coins!'
  });
});

app.post('/api/live-matches/:id/chat', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to chat' });

  const match = (memoryStore.liveMatches || []).find(m => m.id === req.params.id);
  if (!match) return res.status(404).json({ error: 'Match room not found' });

  const { text, isSubscriber } = req.body;
  if (!text || !text.trim()) return res.status(400).json({ error: 'Message text required' });

  const newMsg = {
    id: 'msg-' + Date.now(),
    userId: user.id,
    userName: user.name,
    userAvatar: user.avatar,
    isSubscriber: Boolean(isSubscriber || user.membershipPlan !== 'free'),
    subscriberTier: user.membershipPlan !== 'free' ? 'VIP Sub' : (isSubscriber ? 'Subscriber' : undefined),
    text: text.trim().slice(0, 200),
    createdAt: new Date().toISOString()
  };

  if (!match.chatMessages) match.chatMessages = [];
  match.chatMessages.push(newMsg);
  if (match.chatMessages.length > 50) match.chatMessages.shift();

  res.json({ success: true, message: newMsg });
});

app.post('/api/live-matches/create', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to start a live match' });

  const { title, category, opponentName } = req.body;
  const newMatch = {
    id: 'match-' + Date.now(),
    title: title ? title.trim() : '🔥 SUBSCRIBER BATTLE: ' + user.name + ' vs ' + (opponentName || 'Challenger'),
    category: category || 'Engineering & Tech',
    status: 'live',
    startedAt: new Date().toISOString(),
    endsAt: new Date(Date.now() + 1000 * 300).toISOString(),
    durationSeconds: 300,
    viewersCount: 1,
    subscribersCount: 1,
    winningsPool: 5000,
    activeDrop: {
      id: 'drop-' + Date.now(),
      title: '🎁 WELCOME SUBSCRIBER GIFT DROP!',
      prizeCoins: 200,
      remainingClaims: 10,
      totalClaims: 10,
      expiresAt: new Date(Date.now() + 1000 * 180).toISOString(),
      claimedByUserIds: []
    },
    host: {
      id: user.id,
      name: user.name,
      username: user.username,
      avatar: user.avatar,
      role: user.role,
      verified: user.verified,
      team: 'red',
      teamName: 'Team ' + user.name,
      score: 100,
      videoUrl: '/api/media/stream/video1.mp4',
      subscribersGiftingCount: 1
    },
    opponent: {
      id: 'u-facade',
      name: opponentName || 'Façade Engineering Academy',
      username: 'facade_academy',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
      role: 'creator',
      verified: true,
      team: 'blue',
      teamName: 'Team ' + (opponentName || 'Challenger'),
      score: 100,
      videoUrl: '/api/media/stream/short1.mp4',
      subscribersGiftingCount: 0
    },
    chatMessages: [
      {
        id: 'msg-init',
        userId: 'system',
        userName: 'Battle System',
        userAvatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&h=200&fit=crop',
        isSubscriber: true,
        text: 'Live Subscriber Match room opened! Send gifts to grow the winning prize pool! 🏆',
        createdAt: new Date().toISOString()
      }
    ],
    recentGifts: [],
    topDonors: []
  };

  if (!memoryStore.liveMatches) memoryStore.liveMatches = [];
  memoryStore.liveMatches.unshift(newMatch);

  res.json({ success: true, match: newMatch });
});

// ----------------------------------------------------
// Global Jobs Portal Routes
// ----------------------------------------------------
app.get('/api/jobs', (req, res) => {
  const { search, category, country, type, experience, featured } = req.query;
  let results = memoryStore.jobs.filter(j => j.status === 'active');

  if (category && category !== 'All') {
    results = results.filter(j => j.category.toLowerCase() === String(category).toLowerCase());
  }

  if (country && country !== 'All') {
    results = results.filter(j => j.country.toLowerCase().includes(String(country).toLowerCase()));
  }

  if (type && type !== 'All') {
    results = results.filter(j => j.employmentType.toLowerCase() === String(type).toLowerCase());
  }

  if (experience && experience !== 'All') {
    results = results.filter(j => j.experienceLevel.toLowerCase() === String(experience).toLowerCase());
  }

  if (featured === 'true') {
    results = results.filter(j => j.featured);
  }

  if (search) {
    const q = String(search).toLowerCase();
    results = results.filter(j =>
      j.title.toLowerCase().includes(q) ||
      j.company.toLowerCase().includes(q) ||
      j.location.toLowerCase().includes(q) ||
      j.description.toLowerCase().includes(q) ||
      j.category.toLowerCase().includes(q)
    );
  }

  const user = getCurrentUser(req);
  const enriched = results.map(job => ({
    ...job,
    isSaved: memoryStore.savedJobs.some(sj => sj.userId === user?.id && sj.jobId === job.id)
  }));

  res.json({ jobs: enriched, total: enriched.length });
});

app.get('/api/jobs/:id', (req, res) => {
  const job = memoryStore.jobs.find(j => j.id === req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });

  const user = getCurrentUser(req);
  const isSaved = memoryStore.savedJobs.some(sj => sj.userId === user?.id && sj.jobId === job.id);
  res.json({ job: { ...job, isSaved } });
});

app.post('/api/jobs', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to post vacancies' });
  if (!['employer', 'admin'].includes(user.role)) return res.status(403).json({ error: 'An employer account is required to post vacancies.' });

  const { title, company, companyLogo, location, country, category, employmentType, experienceLevel, salaryMin, salaryMax, currency, description, responsibilities, qualifications, deadline, contactEmail } = req.body;

  if (!title || !company || !location || !description) {
    return res.status(400).json({ error: 'Title, company, location, and description are required.' });
  }

  const newJob = {
    id: 'job-' + Date.now(),
    title,
    company,
    companyLogo: companyLogo || 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=120&h=120&fit=crop',
    location,
    country: country || 'Worldwide',
    category: category || 'Aluminium & Façade Engineering',
    employmentType: employmentType || 'Full-time',
    experienceLevel: experienceLevel || 'Mid-level',
    salaryMin: Number(salaryMin) || 60000,
    salaryMax: Number(salaryMax) || 90000,
    currency: currency || 'USD',
    description,
    responsibilities: Array.isArray(responsibilities) ? responsibilities : (responsibilities ? [responsibilities] : []),
    qualifications: Array.isArray(qualifications) ? qualifications : (qualifications ? [qualifications] : []),
    deadline: deadline || '2026-12-31',
    contactEmail: user.email,
    employerId: user.id,
    status: 'pending',
    featured: false,
    applicantsCount: 0,
    createdAt: new Date().toISOString()
  };

  memoryStore.jobs.unshift(newJob);
  res.json({ success: true, job: newJob });
});

app.post('/api/jobs/:id/save', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to save jobs' });

  const jobId = req.params.id;
  const idx = memoryStore.savedJobs.findIndex(sj => sj.userId === user.id && sj.jobId === jobId);
  let isSaved = false;

  if (idx > -1) {
    memoryStore.savedJobs.splice(idx, 1);
  } else {
    memoryStore.savedJobs.push({ userId: user.id, jobId });
    isSaved = true;
  }

  res.json({ success: true, isSaved });
});

app.get('/api/jobs/saved', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.json({ savedJobs: [] });

  const savedJobIds = memoryStore.savedJobs.filter(sj => sj.userId === user.id).map(sj => sj.jobId);
  const jobs = memoryStore.jobs.filter(j => savedJobIds.includes(j.id)).map(j => ({ ...j, isSaved: true }));
  res.json({ savedJobs: jobs });
});

// ----------------------------------------------------
// Job Applications Routes
// ----------------------------------------------------
app.post('/api/jobs/:id/apply', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to apply' });

  const job = memoryStore.jobs.find(j => j.id === req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });

  if (memoryStore.applications.some(a => a.jobId === job.id && a.applicantId === user.id)) {
    return res.status(409).json({ error: 'You have already applied for this job.' });
  }
  const { resumeFileName, portfolioUrl, coverNote, videoPitchUrl, videoPitchTitle, videoPitchDuration } = req.body || {};
  const boundedString = (value, max) => typeof value === 'string' ? value.slice(0, max) : '';
  const newApp = {
    id: 'app-' + Date.now(),
    jobId: job.id,
    jobTitle: job.title,
    company: job.company,
    applicantId: user.id,
    applicantName: user.name,
    applicantEmail: user.email,
    applicantPhone: String(user.phone || '').slice(0, 40),
    resumeFileName: boundedString(resumeFileName, 180),
    portfolioUrl: boundedString(portfolioUrl, 2048),
    coverNote: boundedString(coverNote, 3000),
    videoPitchUrl: boundedString(videoPitchUrl, 2048) || undefined,
    videoPitchTitle: boundedString(videoPitchTitle, 160) || undefined,
    videoPitchDuration: Number.isFinite(Number(videoPitchDuration)) ? Math.max(0, Math.min(3600, Number(videoPitchDuration))) : undefined,
    status: 'Submitted',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  memoryStore.applications.unshift(newApp);
  job.applicantsCount += 1;

  // Notify recruiter
  if (job.employerId) {
    memoryStore.notifications.unshift({
      id: 'notif-app-' + Date.now(),
      recipientId: job.employerId,
      actorId: user.id,
      actorName: user.name,
      actorAvatar: user.avatar,
      type: 'job_alert',
      title: 'New Candidate Application',
      message: user.name + ' applied for "' + job.title + '"',
      link: '/applications',
      read: false,
      createdAt: new Date().toISOString()
    });
  }

  res.json({ success: true, application: newApp });
});

app.get('/api/applications/my', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.json({ applications: [] });

  const userApps = memoryStore.applications.filter(a => a.applicantId === user.id);
  res.json({ applications: userApps });
});

app.get('/api/applications/employer', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  // Employer can see applications for their jobs (or all if admin)
  if (user.role === 'admin') {
    return res.json({ applications: memoryStore.applications });
  }

  const employerJobIds = memoryStore.jobs.filter(j => j.employerId === user.id).map(j => j.id);
  const apps = memoryStore.applications.filter(a => employerJobIds.includes(a.jobId));
  res.json({ applications: apps });
});

app.put('/api/applications/:id/status', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const appItem = memoryStore.applications.find(a => a.id === req.params.id);
  if (!appItem) return res.status(404).json({ error: 'Application not found' });

  const relatedJob = memoryStore.jobs.find(j => j.id === appItem.jobId);
  if (user.role !== 'admin' && (!relatedJob || relatedJob.employerId !== user.id)) {
    return res.status(403).json({ error: 'Only the hiring employer or an administrator can update this application.' });
  }
  const { status } = req.body || {};
  const allowed = ['Submitted', 'Under Review', 'Shortlisted', 'Interview', 'Rejected', 'Hired'];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: 'Invalid application status' });
  }

  appItem.status = status;
  appItem.updatedAt = new Date().toISOString();

  // Notify applicant of status update!
  memoryStore.notifications.unshift({
    id: 'notif-st-' + Date.now(),
    recipientId: appItem.applicantId,
    actorId: user.id,
    actorName: user.name,
    type: 'job_status',
    title: 'Application Status: ' + status,
    message: 'Your application for "' + appItem.jobTitle + '" at ' + appItem.company + ' has been updated to "' + status + '".',
    link: '/applications',
    read: false,
    createdAt: new Date().toISOString()
  });

  res.json({ success: true, application: appItem });
});

// ----------------------------------------------------
// Notifications Routes
// ----------------------------------------------------
app.get('/api/notifications', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.json({ notifications: [] });

  const userNotifs = memoryStore.notifications.filter(n => n.recipientId === user.id || n.recipientId === 'all');
  res.json({ notifications: userNotifs });
});

app.get('/api/notifications/unread-count', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.json({ unreadCount: 0 });

  const count = memoryStore.notifications.filter(n => (n.recipientId === user.id || n.recipientId === 'all') && !n.read).length;
  res.json({ unreadCount: count });
});

app.put('/api/notifications/:id/read', (req, res) => {
  const user = getCurrentUser(req);
  const notif = memoryStore.notifications.find(n => n.id === req.params.id && (n.recipientId === user.id || n.recipientId === 'all'));
  if (!notif) return res.status(404).json({ error: 'Notification not found.' });
  notif.read = true;
  res.json({ success: true });
});

app.put('/api/notifications/read-all', (req, res) => {
  const user = getCurrentUser(req);
  if (user) {
    memoryStore.notifications.forEach(n => {
      if (n.recipientId === user.id || n.recipientId === 'all') n.read = true;
    });
  }
  res.json({ success: true });
});

// ----------------------------------------------------
// Subscriptions & Creators
// ----------------------------------------------------
app.get('/api/subscriptions/plans', (_req, res) => {
  res.json({ plans: SEED_PLANS });
});

app.post('/api/subscriptions/checkout', (req, res, next) => {
  if (process.env.NODE_ENV === 'production') return requireLivePayments(req, res, next);
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Please sign in to subscribe' });

  const { tier } = req.body;
  const plan = SEED_PLANS.find(p => p.id === tier);
  if (!plan) return res.status(400).json({ error: 'Invalid membership plan tier' });

  user.membershipPlan = plan.id;

  memoryStore.notifications.unshift({
    id: 'notif-sub-' + Date.now(),
    recipientId: user.id,
    type: 'membership',
    title: 'Welcome to ' + plan.name + '!',
    message: 'Your membership has been activated with tier perks unlocked.',
    read: false,
    createdAt: new Date().toISOString()
  });

  res.json({
    success: true,
    message: 'Successfully upgraded to ' + plan.name + ' (Demo Mode).',
    user
  });
});

app.post('/api/creators/:id/follow', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to follow creators' });

  const targetCreator = memoryStore.users.find(u => u.id === req.params.id || u.username === req.params.id);
  if (!targetCreator) return res.status(404).json({ error: 'Creator not found' });

  const idx = memoryStore.follows.findIndex(f => f.followerId === user.id && f.targetId === targetCreator.id);
  let isFollowing = false;

  if (idx > -1) {
    memoryStore.follows.splice(idx, 1);
    targetCreator.subscribersCount = Math.max(0, targetCreator.subscribersCount - 1);
    user.followingCount = Math.max(0, user.followingCount - 1);
  } else {
    memoryStore.follows.push({ followerId: user.id, targetId: targetCreator.id });
    targetCreator.subscribersCount += 1;
    user.followingCount += 1;
    isFollowing = true;

    memoryStore.notifications.unshift({
      id: 'notif-fol-' + Date.now(),
      recipientId: targetCreator.id,
      actorId: user.id,
      actorName: user.name,
      actorAvatar: user.avatar,
      type: 'follow',
      title: 'New Subscriber',
      message: user.name + ' followed your channel.',
      link: '/profile/' + user.username,
      read: false,
      createdAt: new Date().toISOString()
    });
  }

  res.json({ success: true, isFollowing, subscribersCount: targetCreator.subscribersCount });
});

app.get('/api/creators/:username', (req, res) => {
  const creator = memoryStore.users.find(u => u.username.toLowerCase() === req.params.username.toLowerCase());
  if (!creator) return res.status(404).json({ error: 'Creator not found' });

  const user = getCurrentUser(req);
  const isFollowing = memoryStore.follows.some(f => f.followerId === user?.id && f.targetId === creator.id);
  const videos = memoryStore.videos.filter(v => v.creatorId === creator.id && v.visibility === 'public');

  res.json({ creator: publicUser(creator), isFollowing, videos });
});

// ----------------------------------------------------
// Direct Messages API
// ----------------------------------------------------
app.get('/api/messages/conversations', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Authentication required.' });
  const conversations = memoryStore.conversations.filter(c => (c.participants || []).some(p => p.id === user.id));
  res.json({ conversations });
});

app.get('/api/messages/:convId', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Authentication required.' });
  const conversation = memoryStore.conversations.find(c => c.id === req.params.convId && (c.participants || []).some(p => p.id === user.id));
  if (!conversation) return res.status(404).json({ error: 'Conversation not found.' });
  const messages = memoryStore.messages.filter(m => m.conversationId === req.params.convId);
  res.json({ messages });
});

app.post('/api/messages', (req, res) => {
  const user = getCurrentUser(req);
  const { conversationId, text } = req.body || {};
  const conversation = memoryStore.conversations.find(c => c.id === conversationId && (c.participants || []).some(p => p.id === user.id));
  if (!conversation) return res.status(404).json({ error: 'Conversation not found.' });
  if (typeof text !== 'string' || !text.trim() || text.length > 5000) return res.status(400).json({ error: 'Message must contain 1–5000 characters.' });

  const newMsg = {
    id: 'm-' + crypto.randomUUID(),
    conversationId: conversationId,
    senderId: user.id,
    senderName: user.name,
    senderAvatar: user.avatar,
    text: text.trim(),
    createdAt: new Date().toISOString()
  };

  memoryStore.messages.push(newMsg);

  const conv = memoryStore.conversations.find(c => c.id === newMsg.conversationId);
  if (conv) {
    conv.lastMessage = newMsg.text;
    conv.lastMessageAt = newMsg.createdAt;
  }

  res.json({ success: true, message: newMsg });
});

// ----------------------------------------------------
// Reports & Moderation Submissions
// ----------------------------------------------------
app.post('/api/reports', (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to submit a report.' });
  const { targetType, targetId, targetTitle, reason, details } = req.body || {};
  const reportFields = { targetType, targetId, targetTitle, reason, details };
  const reportLimits = { targetType: 30, targetId: 120, targetTitle: 200, reason: 100, details: 3000 };
  for (const [key, value] of Object.entries(reportFields)) {
    if (value !== undefined && (typeof value !== 'string' || value.length > reportLimits[key])) return res.status(400).json({ error: 'Invalid report details.' });
  }
  const newReport = {
    id: 'rep-' + Date.now(),
    reporterId: user.id,
    reporterName: user.name,
    targetType: targetType || 'video',
    targetId: targetId || 'unknown',
    targetTitle: targetTitle || 'Reported item',
    reason: reason || 'Inappropriate content',
    details: details || '',
    status: 'pending',
    createdAt: new Date().toISOString()
  };

  memoryStore.reports.unshift(newReport);
  res.json({ success: true, message: 'Report submitted for review.' });
});

// ----------------------------------------------------
// Protected Administrative Routes (Backed by admin.js)
// ----------------------------------------------------
function requireAdmin(req, res, next) {
  const user = getCurrentUser(req);
  if (user?.role !== 'admin') {
    return res.status(403).json({ error: 'Access forbidden: Administrative credentials required.' });
  }
  next();
}

app.get('/api/admin/metrics', requireAdmin, async (_req, res) => {
  try {
    const metrics = await adminService.getPlatformMetrics();
    res.json(metrics);
  } catch (err) {
    res.status(500).json({ error: 'The request could not be completed.' });
  }
});

app.get('/api/admin/users', requireAdmin, async (req, res) => {
  try {
    const { search, role, status, page } = req.query;
    const result = await adminService.listUsers({
      search: String(search || '').slice(0, 100),
      role: String(role || ''),
      status: String(status || ''),
      page: Math.max(1, Math.min(100000, Number(page) || 1)),
      limit: 50
    });
    res.json({ ...result, users: result.users.map(publicUser) });
  } catch (err) {
    res.status(500).json({ error: 'The request could not be completed.' });
  }
});

app.put('/api/admin/users/:id/status', requireAdmin, async (req, res) => {
  try {
    const adminUser = getCurrentUser(req);
    const { status } = req.body;
    const result = await adminService.updateUserStatus(req.params.id, status, adminUser);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/admin/users/:id/role', requireAdmin, async (req, res) => {
  try {
    const adminUser = getCurrentUser(req);
    const { role, verified } = req.body;
    const result = await adminService.updateUserRole(req.params.id, { role, verified }, adminUser);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/admin/videos/:id/moderation', requireAdmin, async (req, res) => {
  try {
    const adminUser = getCurrentUser(req);
    const { moderationStatus } = req.body;
    const result = await adminService.moderateVideo(req.params.id, moderationStatus, adminUser);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/admin/jobs/:id/moderation', requireAdmin, async (req, res) => {
  try {
    const adminUser = getCurrentUser(req);
    const { status, featured } = req.body;
    const result = await adminService.moderateJob(req.params.id, { status, featured }, adminUser);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/admin/reports', requireAdmin, (_req, res) => {
  res.json({ reports: memoryStore.reports });
});

app.put('/api/admin/reports/:id/resolve', requireAdmin, async (req, res) => {
  try {
    const adminUser = getCurrentUser(req);
    const { status } = req.body;
    const result = await adminService.resolveReport(req.params.id, status, adminUser);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/admin/announcements', requireAdmin, async (req, res) => {
  try {
    const adminUser = getCurrentUser(req);
    const { title, message, target } = req.body;
    const result = await adminService.sendAdminAnnouncement(title, message, target, adminUser);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/admin/audit-logs', requireAdmin, async (_req, res) => {
  try {
    const logs = await adminService.getAuditLogs();
    res.json({ auditLogs: logs });
  } catch (err) {
    res.status(500).json({ error: 'The request could not be completed.' });
  }
});

// ----------------------------------------------------
// Online Shopping Store & Listings API
// ----------------------------------------------------
app.get('/api/store/products', (req, res) => {
  try {
    let list = [...(memoryStore.storeProducts || [])];
    const { category, search, sellerId, sort, featured } = req.query;

    if (category && category !== 'all') {
      list = list.filter(p => p.category === category);
    }

    if (sellerId) {
      list = list.filter(p => p.sellerId === sellerId);
    }

    if (featured === 'true') {
      list = list.filter(p => p.isFeatured);
    }

    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter(p =>
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        (p.tags && p.tags.some(t => t.toLowerCase().includes(q)))
      );
    }

    if (sort === 'price_asc') {
      list.sort((a, b) => a.price - b.price);
    } else if (sort === 'price_desc') {
      list.sort((a, b) => b.price - a.price);
    } else if (sort === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    } else {
      // Default: newest first or featured
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    res.json({ products: list, total: list.length });
  } catch (err) {
    res.status(500).json({ error: 'The request could not be completed.' });
  }
});

app.get('/api/store/products/:id', (req, res) => {
  const product = (memoryStore.storeProducts || []).find(p => p.id === req.params.id);
  if (!product) {
    return res.status(404).json({ error: 'Product not found' });
  }
  res.json({ product });
});

app.post('/api/store/products', (req, res) => {
  try {
    const currentUser = getCurrentUser(req);
    const {
      title,
      description,
      category,
      categoryName,
      price,
      compareAtPrice,
      condition,
      stock,
      images,
      thumbnailUrl,
      features,
      specifications,
      brand,
      shippingInfo,
      tags
    } = req.body;

    if (!title || !price) {
      return res.status(400).json({ error: 'Title and price are required to list a product.' });
    }

    const categoryLabels = {
      electronics: 'Electronics & Tech Gadgets',
      fashion: 'Fashion & Apparel',
      home_living: 'Home, Kitchen & Living',
      tools_diy: 'Tools, Hardware & DIY',
      sports_fitness: 'Sports, Fitness & Outdoor',
      digital_assets: 'Digital Assets, Software & Templates',
      creator_merch: 'Creator Merch & Swag',
      industrial_facade: 'Industrial, Architectural & Façade',
      facade_hardware: 'Façade Hardware & Glass Lifters',
      fabrication_tools: 'Fabrication & Site Tools',
      safety_gear: 'Safety Gear & Site PPE',
      machinery: 'Heavy Machinery & Fabrication Plant',
      bim_templates: 'BIM & Digital Engineering Assets'
    };

    const newProduct = {
      id: 'prod-' + Date.now(),
      title: title.trim(),
      description: description ? description.trim() : 'Quality product listed on World Video Hub Store.',
      category: category || 'electronics',
      categoryName: categoryName || categoryLabels[category] || 'Electronics & Tech Gadgets',
      price: Number(price),
      compareAtPrice: compareAtPrice ? Number(compareAtPrice) : undefined,
      currency: 'USD',
      condition: condition || 'new',
      rating: 5.0,
      reviewsCount: 1,
      stock: stock ? Number(stock) : 10,
      images: Array.isArray(images) && images.length > 0 ? images : [
        thumbnailUrl || 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=800&h=600&fit=crop'
      ],
      thumbnailUrl: thumbnailUrl || (Array.isArray(images) && images[0]) || 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=600&h=450&fit=crop',
      features: Array.isArray(features) && features.length > 0 ? features : [
        'Certified engineering specification',
        'Direct creator / manufacturer backed warranty',
        'Express dispatch & verified tracking'
      ],
      specifications: specifications && typeof specifications === 'object' ? specifications : {
        'Quality Standard': 'Architectural Grade 6063-T6 / EN Standard',
        'Inspection': '100% Pre-Shipment Tested'
      },
      brand: brand ? brand.trim() : (currentUser.displayName || currentUser.name || 'World Video Hub Store'),
      sellerId: currentUser.id,
      sellerName: currentUser.displayName || currentUser.name,
      sellerAvatar: currentUser.avatar,
      sellerVerified: Boolean(currentUser.verified),
      shippingInfo: shippingInfo || {
        freeShipping: true,
        estimatedDelivery: '2–4 Business Days (Express)',
        shipsFrom: currentUser.country || 'Saudi Arabia'
      },
      tags: Array.isArray(tags) ? tags : ['Store', 'EngineeringTools'],
      isFeatured: false,
      isCreatorProduct: true,
      createdAt: new Date().toISOString()
    };

    if (!memoryStore.storeProducts) memoryStore.storeProducts = [];
    memoryStore.storeProducts.unshift(newProduct);

    res.status(201).json({
      success: true,
      product: newProduct,
      message: 'Product listed successfully in the online store!'
    });
  } catch (err) {
    res.status(500).json({ error: 'The request could not be completed.' });
  }
});

app.delete('/api/store/products/:id', (req, res) => {
  try {
    const currentUser = getCurrentUser(req);
    const index = (memoryStore.storeProducts || []).findIndex(p => p.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: 'Product not found' });
    }

    const prod = memoryStore.storeProducts[index];
    if (prod.sellerId !== currentUser.id && currentUser.role !== 'admin') {
      return res.status(403).json({ error: 'You are not authorized to delete this store listing.' });
    }

    memoryStore.storeProducts.splice(index, 1);
    res.json({ success: true, message: 'Product listing removed from store.' });
  } catch (err) {
    res.status(500).json({ error: 'The request could not be completed.' });
  }
});

app.post('/api/store/orders', (req, res, next) => {
  if (process.env.NODE_ENV === 'production') return requireLivePayments(req, res, next);
  try {
    const currentUser = getCurrentUser(req);
    const { items, shippingAddress, paymentMethod, couponCode } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Cart is empty. Please add items to checkout.' });
    }

    let subtotal = 0;
    const orderItems = [];
    for (const item of items) {
      const prodId = String(item?.productId || item?.product?.id || '');
      const foundProduct = (memoryStore.storeProducts || []).find(p => p.id === prodId && p.status !== 'removed');
      const qty = Number(item?.quantity || 1);
      if (!foundProduct || !Number.isInteger(qty) || qty < 1 || qty > 20 || Number(foundProduct.stock || 0) < qty) {
        return res.status(400).json({ error: 'One or more cart items are invalid or out of stock.' });
      }
      const price = Number(foundProduct.price || 0);
      if (!Number.isFinite(price) || price < 0) return res.status(400).json({ error: 'Product price is invalid.' });
      subtotal += price * qty;
      orderItems.push({ productId: prodId, title: foundProduct.title, price, quantity: qty, thumbnailUrl: foundProduct.thumbnailUrl });
    }

    let discount = 0;
    if (couponCode) {
      const code = couponCode.toUpperCase().trim();
      if (code === 'STORE20') {
        discount = subtotal * 0.20;
      } else if (code === 'ALUM2026' || code === 'SHAFI15' || code === 'GLOBAL15') {
        discount = subtotal * 0.15;
      } else if (code === 'WELCOME10') {
        discount = subtotal * 0.10;
      }
    }

    const shippingFee = subtotal > 150 ? 0 : 15.00;
    const total = Math.max(0, subtotal - discount + shippingFee);

    const newOrder = {
      id: 'ORD-' + Math.floor(100000 + Math.random() * 900000),
      userId: currentUser.id,
      userName: currentUser.displayName || currentUser.name,
      userEmail: currentUser.email,
      items: orderItems,
      subtotal,
      shippingFee,
      discount,
      total,
      currency: 'USD',
      shippingAddress: shippingAddress || {
        fullName: currentUser.displayName || currentUser.name,
        street: 'King Fahd Road, Al Olaya District',
        city: 'Riyadh',
        country: 'Saudi Arabia',
        postalCode: '12214',
        phone: currentUser.phone || '+966 50 123 4567'
      },
      paymentMethod: paymentMethod || 'mada',
      status: 'payment_pending',
      paymentStatus: 'unpaid',
      trackingNumber: null,
      createdAt: new Date().toISOString()
    };

    if (!memoryStore.storeOrders) memoryStore.storeOrders = [];
    memoryStore.storeOrders.unshift(newOrder);

    res.status(201).json({
      success: true,
      order: newOrder,
      message: 'Order created. Payment is not processed in this demo environment; connect a verified payment gateway before fulfilment.'
    });
  } catch (err) {
    res.status(500).json({ error: 'The request could not be completed.' });
  }
});

app.get('/api/store/orders', (req, res) => {
  try {
    const currentUser = getCurrentUser(req);
    const userOrders = (memoryStore.storeOrders || []).filter(o => o.userId === currentUser.id || currentUser.role === 'admin');
    res.json({ orders: userOrders });
  } catch (err) {
    res.status(500).json({ error: 'The request could not be completed.' });
  }
});


// Vercel serves files from /public through its CDN. Unknown browser routes
// should receive the SPA entry page, while API and file requests keep their
// normal handling. This branch is not used by the local Vite development server.
if (IS_SERVERLESS) {
  app.get('*', (req, res, next) => {
    if (req.path === '/api' || req.path.startsWith('/api/') || path.extname(req.path)) return next();
    res.sendFile(path.resolve(__dirname, 'public', 'index.html'), err => {
      if (err) next(err);
    });
  });
}

export async function startServer() {
  await dbReady;
  // Safety net for changes made by GET requests (e.g. view counters)
  setInterval(() => { persistToMongo(); }, 15000).unref();
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const viteModule = 'vite'; // kept non-literal so serverless bundlers don't pull Vite in
    const { createServer: createViteServer } = await import(viteModule);
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log('[VideoHub + Global Jobs] Server active at http://localhost:' + PORT);
  });
}

// Vercel's Express integration expects a default-exported application.
export default app;
