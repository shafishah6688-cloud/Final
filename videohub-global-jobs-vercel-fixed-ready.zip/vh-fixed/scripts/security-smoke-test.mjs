import fs from 'node:fs';
import assert from 'node:assert/strict';

const read = (name) => fs.readFileSync(new URL(`../${name}`, import.meta.url), 'utf8');
const app = read('index.js');
const db = read('db.js');
const checks = [
  ['production requires MongoDB', app.includes("process.env.NODE_ENV === 'production' && !process.env.MONGODB_URI")],
  ['production requires strong AUTH_SECRET', app.includes("AUTH_SECRET.length < 32")],
  ['passwords use scrypt', app.includes('crypto.scryptSync')],
  ['session cookies are HttpOnly and Secure in production', app.includes('httpOnly: true') && app.includes("secure: process.env.NODE_ENV === 'production'")],
  ['API mutations default-deny unauthenticated users', app.includes('Default-deny protection runs after the DB')],
  ['cookie mutations enforce configured origin', app.includes('Request origin is not permitted.')],
  ['write rate limiting is enabled', app.includes('writeRateLimit')],
  ['uploads enforce 100 MB maximum', app.includes('MAX_UPLOAD_BYTES = 100 * 1024 * 1024')],
  ['uploads validate file signatures', app.includes('Basic file-signature validation')],
  ['creator profile strips password hash', app.includes('creator: publicUser(creator)')],
  ['private conversations check participants', app.includes('(c.participants || []).some(p => p.id === user.id)')],
  ['application status checks employer ownership', app.includes('relatedJob.employerId !== user.id')],
  ['duplicate job applications are rejected', app.includes('You have already applied for this job.')],
  ['video deletion enforces owner/admin check', app.includes('video.creatorId !== user.id && user.role !== \'admin\'')],
  ['production does not enable demo payments', app.includes('Payments are not enabled.')],
  ['production starts without seeded users', db.includes("const demo = process.env.NODE_ENV !== 'production'") && db.includes('this.users = demo ? [...SEED_USERS] : []')],
  ['production database migration purges demo records', db.includes('purgeProductionDemoData()')]
];
let failed = 0;
for (const [name, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`);
  if (!ok) failed++;
}
console.log(`\nSecurity static checks: ${checks.length - failed}/${checks.length} passed.`);
if (failed) process.exit(1);
