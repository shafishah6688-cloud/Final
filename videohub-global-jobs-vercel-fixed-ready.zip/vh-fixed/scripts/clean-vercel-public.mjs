import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const publicDir = path.join(root, 'public');
const manifestPath = path.join(root, '.vercel-public-manifest.json');

if (fs.existsSync(manifestPath)) {
  const names = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  for (const name of names) {
    if (typeof name !== 'string' || name.includes('/') || name.includes('\\') || name === '.' || name === '..') continue;
    fs.rmSync(path.join(publicDir, name), { recursive: true, force: true });
  }
  fs.rmSync(manifestPath, { force: true });
}
