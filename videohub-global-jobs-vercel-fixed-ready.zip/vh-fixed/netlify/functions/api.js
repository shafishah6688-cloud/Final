import serverless from 'serverless-http';
import { app } from '../../index.js';

// Netlify redirects /api/* to this function (see netlify.toml). Restore the original
// "/api/..." path so the Express routes match.
const PREFIX = '/.netlify/functions/api';
const run = serverless(app, { binary: ['video/*', 'application/octet-stream'] });

export const handler = async (event, context) => {
  if (event.path && event.path.startsWith(PREFIX)) {
    event.path = '/api' + event.path.slice(PREFIX.length);
  }
  return run(event, context);
};
