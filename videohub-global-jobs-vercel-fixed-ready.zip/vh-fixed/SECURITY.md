# VideoHub Global Jobs — Security release notes and production checklist

## Implemented in this release

- Production startup fails closed unless MongoDB and a strong `AUTH_SECRET` are configured.
- Production data starts without sample users, seeded administrator identities, demo videos/jobs, sample private conversations or demo activity. Existing MongoDB installations are migrated to remove known bundled seed records on startup.
- API write requests require an authenticated active user, except registration, login, Google sign-in and logout.
- Cookie-authenticated production mutations must have an origin matching the configured deployment URL.
- Security headers are set; Express identifies itself without the `X-Powered-By` header.
- Registration and profile inputs have type/length validation; passwords are limited to 12–128 characters and hashed with scrypt.
- API write traffic and authentication attempts are rate-limited per running instance.
- Video upload size and basic file signatures are checked; new user videos enter moderation as pending.
- Video deletion is limited to the owner or an administrator.
- Public creator responses remove private password-hash fields.
- Private message inboxes and message reads are restricted to conversation participants.
- Application submissions use the signed-in account's identity, reject duplicates, and application status changes are limited to the hiring employer or an administrator.
- Notification read operations are limited to the notification recipient.
- Store order totals are calculated from server-side product prices, not client-supplied prices. Orders remain payment-pending; inventory is not reduced before verified payment.
- Demo subscriptions, creator earnings, payouts, tips and live gifts are disabled in production until a real payment provider and verified webhook/accounting ledger are implemented.
- `scripts/security-smoke-test.mjs` checks for the presence of key security controls.

## Required deployment configuration

Set the following in the hosting provider's environment-variable dashboard. Do not put real values in Git, ZIP files, screenshots or chat messages.

- `NODE_ENV=production`
- `MONGODB_URI` — dedicated production MongoDB Atlas URI.
- `MONGODB_DB_NAME=videohub_jobs` (or your chosen database name).
- `AUTH_SECRET` — generate a unique random value of at least 32 characters (64 random bytes recommended).
- `APP_URL` — exact HTTPS origin of the deployed site, e.g. `https://your-domain.example`.
- `ADMIN_EMAILS` — comma-separated list of exact administrator email addresses. Keep this list very small.
- `GOOGLE_CLIENT_ID` — only if Google sign-in is enabled.
- `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` — only if Cloudinary video uploads are enabled.

Generate a secret locally with:

```bash
node -e "console.log(require('node:crypto').randomBytes(64).toString('hex'))"
```

Do not paste the generated secret into this document or commit it. Provision the first administrator by configuring their exact verified Google email in `ADMIN_EMAILS`, then have that person sign in with Google. Do not create a public admin-registration option.

## Hosting and infrastructure controls still required

1. Use HTTPS and enable your hosting provider's WAF/bot protection and distributed rate limiting. The included in-memory limiter is per process/instance and is not a substitute for a shared Redis/WAF limiter on serverless deployments.
2. Restrict MongoDB Atlas network access, use a dedicated least-privilege database user, enable backups and test restores.
3. Rotate every credential that has ever been committed, shared in a ZIP, or pasted into a chat. The `.env.example` values are examples only.
4. Configure Cloudinary upload quotas, allowed media formats, moderation, storage limits and signed upload restrictions. The server-side upload check is basic file-signature validation, not antivirus scanning or full media transcoding.
5. Add malware scanning, media transcoding, abuse reporting workflows, rate limits by account and IP, and moderation staffing before opening public uploads.
6. Add verified email and secure password-reset flows if you intend to support password login at scale.
7. Configure payment processing with signed webhook verification, idempotency keys, server-side price lookup, refunds, chargeback handling, payout compliance and a ledger before enabling any paid feature.
8. Review privacy, terms, cookies, data retention, child-safety, user-generated content, employment/recruitment and cross-border data obligations for every market you serve.
9. Run `npm run security:check`, `npm test`, `npm run lint` and `npm run build` in a Node.js 24 environment. Fix every failure before deployment.
10. Arrange an independent penetration test before storing real CVs, identity documents, private messages or payment details.

## Verification status and limitations

- JavaScript syntax checks were run on the edited server and database files.
- The static security smoke test is included in this release.
- Full application tests, TypeScript checks, dependency audit and production build were not run in this environment because dependencies are not installed and the available runtime is Node.js 22 while the project targets Node.js 24.
- This release is a security hardening pass, not a certification or guarantee of complete security. Real deployment secrets, hosting controls, provider settings and external penetration testing remain the operator's responsibility.
