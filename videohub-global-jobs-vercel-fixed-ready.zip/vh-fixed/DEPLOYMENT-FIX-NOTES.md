# VideoHub Global Jobs — Vercel deployment fix

## Changes in this package

- The root `index.js` now exports the Express application as a default export, which is the documented Vercel Express entry-point format. The named `app` export remains available for the Netlify adapter.
- Removed the redundant `vercel.js` and `api/vercel.ts` wrappers so Vercel has one clear Express entry point.
- Renamed the local development launcher from `server.ts` to `local-server.ts`; the `dev` and `start` scripts were updated accordingly.
- Added Vercel SPA fallback handling for browser routes while leaving `/api` and file requests alone.
- Added build lifecycle scripts that copy the Vite output into `public/`, because Vercel's Express integration serves static assets from `public/` rather than through `express.static()`. The existing `public/videos` files are preserved.
- Kept `engines.node` at `24.x`, matching this project and the Node.js 24 runtime shown in the deployment logs.

## Vercel settings

1. Extract this ZIP. The project root is the folder containing `package.json` and `index.js`. Deploy that folder, not an outer folder containing it.
2. Set the Root Directory to that project root.
3. Set Node.js Version to `24.x` (or leave the package engine override in effect). Do not downgrade this project to Node 22 based solely on the earlier advice.
4. Set Build Command to `npm run build`. Leave Output Directory empty for the Express deployment.
5. Add the production environment variables from `.env.example` in Vercel Project Settings before deploying. At minimum, production requires a MongoDB URI, an `AUTH_SECRET` of at least 32 characters, and the other provider settings documented in `SECURITY.md`. Do not upload a real `.env` file or commit secrets.

## Validation status

The 17 static security smoke checks pass, the edited JavaScript files pass syntax checks, and the Vercel static-file sync/cleanup scripts pass a simulated test. A full `npm run build`, TypeScript check, and end-to-end Vercel deployment were not completed in this environment because dependency installation did not finish. Confirm those checks in Vercel after deployment.
