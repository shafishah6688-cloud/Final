# VideoHub + Global Jobs — Vercel deployment

This package is prepared for Vercel with the Express backend and Vite frontend in one deployment.

## 1. Vercel project

- Import this project/repository.
- Root Directory: the folder containing `package.json` and `index.js`.
- Build Command: `npm run build`.
- Output Directory: leave empty.
- Node.js: `24.x` (the package engine pins Node 24).

Vercel supports Express/Node backends with zero configuration. The project root `index.js` exports the Express application.

## 2. Required Production Environment Variables

Set these in Vercel → Project Settings → Environment Variables for **Production**:

- `MONGODB_URI` — your MongoDB Atlas connection string.
- `MONGODB_DB_NAME` — recommended: `videohub_jobs`.
- `AUTH_SECRET` — a random secret of at least 32 characters.
- `APP_URL` — `https://videohub-global-jobs1.vercel.app` (or your final custom domain).
- `NEXT_PUBLIC_APP_URL` — same public URL.
- `ADMIN_EMAILS` — your admin email address(es), comma separated.

For video uploads, also configure real Cloudinary values:

- `CLOUDINARY_CLOUD_NAME`
- `CLOUDINARY_API_KEY`
- `CLOUDINARY_API_SECRET`

Google login requires:

- `GOOGLE_CLIENT_ID`

Stripe and SMTP variables are optional until those features are enabled.

## 3. After deployment

Open:

`https://videohub-global-jobs1.vercel.app/api/health`

Expected result contains:

`"status":"ok"`

and:

`"database":"MongoDB Atlas Connected"`

Then test:

1. Register a new account.
2. Log out.
3. Log in again.
4. Refresh the browser.
5. Confirm the account remains logged in.

## Important

Do not put real passwords, MongoDB credentials, Cloudinary secrets, or Google/Stripe secrets into the ZIP or GitHub repository. Add them only as Vercel Environment Variables.
