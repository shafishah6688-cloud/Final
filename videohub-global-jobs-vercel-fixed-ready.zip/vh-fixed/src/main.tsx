import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Attach the saved session token to every same-origin /api request, so login keeps
// working even when the browser blocks cookies (iframes, previews, Safari, etc.).
const originalFetch = window.fetch.bind(window);
window.fetch = (input: RequestInfo | URL, init: RequestInit = {}) => {
  try {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
    const isApi = url.startsWith('/api/') || url.startsWith(window.location.origin + '/api/');
    const token = localStorage.getItem('auth_token');
    if (isApi && token) {
      const headers = new Headers(init.headers || (typeof input !== 'string' && !(input instanceof URL) ? input.headers : undefined));
      if (!headers.has('Authorization')) headers.set('Authorization', `Bearer ${token}`);
      init = { ...init, headers, credentials: init.credentials || 'include' };
    }
  } catch {}
  return originalFetch(input, init);
};

createRoot(document.getElementById('root')!).render(<App />);
