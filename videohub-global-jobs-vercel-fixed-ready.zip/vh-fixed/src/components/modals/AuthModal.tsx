import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import {
  X,
  Lock,
  Mail,
  User,
  Shield,
  Briefcase,
  Video,
  Globe,
  Eye,
  EyeOff,
  CheckCircle,
  AlertCircle,
  LogIn,
  UserPlus,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { GoogleAuthButton } from '../common/GoogleAuthButton.tsx';

const AVATAR_OPTIONS = [
  { id: 'av-1', label: 'Engineer', url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop&crop=faces' },
  { id: 'av-2', label: 'Architect', url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop&crop=faces' },
  { id: 'av-3', label: 'Creator', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces' },
  { id: 'av-4', label: 'Executive', url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces' }
];

const COUNTRIES = [
  'Saudi Arabia',
  'United Arab Emirates',
  'Qatar',
  'Kuwait',
  'Bahrain',
  'Oman',
  'United Kingdom',
  'United States',
  'Japan',
  'Singapore',
  'Germany',
  'Canada',
  'Australia',
  'Egypt',
  'India',
  'Worldwide'
];

export const AuthModal: React.FC = () => {
  const { authModalOpen, setAuthModalOpen, authModalTab, setAuthModalTab, loginUser, showToast, refreshUserData } = useApp();
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');

  React.useEffect(() => {
    if (authModalTab) {
      setActiveTab(authModalTab);
    }
  }, [authModalTab]);

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  // Register form state
  const [regName, setRegName] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [regRole, setRegRole] = useState<'user' | 'creator' | 'employer'>('user');
  const [regCountry, setRegCountry] = useState('Saudi Arabia');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATAR_OPTIONS[0].url);
  const [agreeTerms, setAgreeTerms] = useState(true);

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [forgotPasswordTip, setForgotPasswordTip] = useState(false);

  if (!authModalOpen) return null;

  // Handle Login submission
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          emailOrUsername: loginIdentifier.trim(),
          password: loginPassword
        })
      });
      const data = await res.json().catch(() => ({} as any));

      if (!res.ok) {
        throw new Error(data.error || `Login failed (server error ${res.status}). Please try again.`);
      }

      loginUser(data.user, data.token || data.user.id);
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      showToast(`Welcome back, ${data.user.name}!`);
      setAuthModalOpen(false);
      refreshUserData();
    } catch (err: any) {
      setErrorMsg(err instanceof TypeError ? 'Cannot reach the server. Please check your connection and try again.' : err.message);
    } finally {
      setLoading(false);
    }
  };

  // Handle Registration submission
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (regPassword !== regConfirmPassword) {
      setErrorMsg('Passwords do not match. Please re-enter matching passwords.');
      return;
    }

    if (regPassword.length < 6) {
      setErrorMsg('Password must be at least 6 characters long.');
      return;
    }

    if (!agreeTerms) {
      setErrorMsg('Please accept the platform terms of service to proceed.');
      return;
    }

    setLoading(true);

    try {
      const payload = {
        name: regName.trim(),
        username: regUsername.trim() || regEmail.split('@')[0],
        email: regEmail.trim(),
        password: regPassword,
        role: regRole,
        country: regCountry,
        avatar: selectedAvatar
      };

      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json().catch(() => ({} as any));

      if (!res.ok) {
        throw new Error(data.error || `Registration failed (server error ${res.status}). Please try again.`);
      }

      loginUser(data.user, data.token || data.user.id);
      confetti({ particleCount: 75, spread: 80, origin: { y: 0.6 } });
      showToast(`🎉 Account created! Welcome to VideoHub, ${data.user.name}!`);
      setAuthModalOpen(false);
      refreshUserData();
    } catch (err: any) {
      setErrorMsg(err instanceof TypeError ? 'Cannot reach the server. Please check your connection and try again.' : err.message);
    } finally {
      setLoading(false);
    }
  };

  // 1-Click Fast Demo Login Handler
  const handleQuickDemo = async (userId: string) => {
    setLoading(true);
    setErrorMsg('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emailOrUsername: userId })
      });
      const data = await res.json().catch(() => ({} as any));
      if (!res.ok) throw new Error(data.error || `Login failed (server error ${res.status}).`);
      loginUser(data.user, data.token || data.user.id);
      confetti({ particleCount: 40, spread: 60, origin: { y: 0.6 } });
      showToast(`Logged in as demo persona: ${data.user.name}`);
      setAuthModalOpen(false);
      refreshUserData();
    } catch (err: any) {
      setErrorMsg(err instanceof TypeError ? 'Cannot reach the server. Please check your connection and try again.' : err.message);
    } finally {
      setLoading(false);
    }
  };

  // Compute password strength indicator
  const getPasswordStrength = (pw: string) => {
    if (!pw) return 0;
    let score = 0;
    if (pw.length >= 6) score++;
    if (pw.length >= 10) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;
    return Math.min(score, 4);
  };
  const pwStrength = getPasswordStrength(regPassword);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg clay-card p-6 bg-white dark:bg-[#181D2E] text-slate-800 dark:text-slate-100 shadow-2xl rounded-3xl max-h-[92vh] overflow-y-auto border border-slate-200/80 dark:border-slate-800">
        {/* Close Button */}
        <button
          onClick={() => setAuthModalOpen(false)}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
          aria-label="Close Authentication Modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-5">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-gradient-to-tr from-violet-600 via-indigo-600 to-pink-500 flex items-center justify-center text-white shadow-lg shadow-purple-500/30 mb-2.5">
            <Lock className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-black tracking-tight text-slate-900 dark:text-white">
            {activeTab === 'login' ? 'Sign In to VideoHub' : 'Create New Account'}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Access 4K engineering videos, live subscriber battles, and international career openings.
          </p>
        </div>

        {/* Tab Switcher: Login vs Register */}
        <div className="flex p-1 mb-5 rounded-2xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700/60">
          <button
            type="button"
            onClick={() => {
              setActiveTab('login');
              setErrorMsg('');
            }}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-black transition-all ${
              activeTab === 'login'
                ? 'clay-btn clay-btn-primary text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <LogIn className="w-4 h-4" />
            <span>Sign In</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('register');
              setErrorMsg('');
            }}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-black transition-all ${
              activeTab === 'register'
                ? 'clay-btn clay-btn-primary text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            <span>Register</span>
          </button>
        </div>

        {/* Error Alert Box */}
        {errorMsg && (
          <div className="mb-4 p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2.5 animate-in fade-in">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-500" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* ===================== TAB 1: LOGIN ===================== */}
        {activeTab === 'login' && (
          <div className="space-y-4">
            {/* Primary Google & Gmail Login Buttons */}
            <div className="space-y-2">
              <GoogleAuthButton
                variant="full"
                label="Sign In with Google"
                className="w-full py-2.5 text-xs font-black shadow-sm"
              />
              <GoogleAuthButton
                variant="gmail"
                label="Sign In with Gmail"
                className="w-full py-2 text-xs font-bold text-slate-700 dark:text-slate-200"
              />
            </div>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
              <span className="flex-shrink mx-3 text-[10px] font-black text-slate-400 uppercase tracking-widest">or sign in with demo / email</span>
              <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
            </div>

            {/* Quick 1-Click Demo Profiles */}
            <div className="p-3.5 rounded-2xl bg-violet-50/80 dark:bg-violet-950/40 border border-violet-200/50 dark:border-violet-800/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black text-violet-800 dark:text-violet-300 flex items-center gap-1.5 uppercase tracking-wider">
                  <Shield className="w-3.5 h-3.5" />
                  Quick Demo Sign-In (1 Click)
                </span>
                <span className="text-[10px] text-violet-600 dark:text-violet-400">Pre-seeded</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => handleQuickDemo('u-candidate1')}
                  className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left hover:border-violet-400 hover:shadow-xs transition"
                >
                  <div className="font-extrabold text-emerald-600 dark:text-emerald-400 flex items-center justify-between">
                    <span>Tariq Mansoor</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold">Candidate</span>
                  </div>
                  <div className="text-[10px] text-slate-400">Façade Engineer</div>
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickDemo('u-admin')}
                  className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left hover:border-violet-400 hover:shadow-xs transition"
                >
                  <div className="font-extrabold text-rose-600 dark:text-rose-400 flex items-center justify-between">
                    <span>Shafi Shah</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 font-bold">Admin</span>
                  </div>
                  <div className="text-[10px] text-slate-400">Chief Executive</div>
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickDemo('u-facade')}
                  className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left hover:border-violet-400 hover:shadow-xs transition"
                >
                  <div className="font-extrabold text-violet-600 dark:text-violet-400 flex items-center justify-between">
                    <span>Façade Academy</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-violet-100 dark:bg-violet-950 text-violet-700 dark:text-violet-300 font-bold">Creator</span>
                  </div>
                  <div className="text-[10px] text-slate-400">Top Publisher</div>
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickDemo('u-recruiter1')}
                  className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left hover:border-violet-400 hover:shadow-xs transition"
                >
                  <div className="font-extrabold text-blue-600 dark:text-blue-400 flex items-center justify-between">
                    <span>Apex Systems</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-bold">Employer</span>
                  </div>
                  <div className="text-[10px] text-slate-400">Recruiter Portal</div>
                </button>
              </div>
            </div>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
              <span className="flex-shrink mx-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">or sign in with credentials</span>
              <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Email or Username
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. shafi_shah or tariq@example.com"
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 text-xs clay-input bg-white dark:bg-slate-900 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => setForgotPasswordTip(!forgotPasswordTip)}
                    className="text-[11px] font-bold text-violet-600 dark:text-violet-400 hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    required
                    placeholder="Enter account password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full pl-9 pr-10 py-2.5 text-xs clay-input bg-white dark:bg-slate-900 rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  >
                    {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {forgotPasswordTip && (
                <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-amber-800 dark:text-amber-200 text-xs">
                  💡 In this sandbox demo, you can log in with any username from above (or click a Quick Demo persona) with any password!
                </div>
              )}

              <div className="flex items-center justify-between text-xs">
                <label className="flex items-center gap-2 cursor-pointer select-none text-slate-600 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded border-slate-300 text-violet-600 focus:ring-violet-500"
                  />
                  <span>Remember me on this browser</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 clay-btn clay-btn-primary text-xs font-black shadow-lg shadow-violet-500/25 active:scale-95 transition disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <span>{loading ? 'Authenticating...' : 'Sign In to VideoHub'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}

        {/* ===================== TAB 2: REGISTER ===================== */}
        {activeTab === 'register' && (
          <div className="space-y-4">
            {/* 1-Click Fast Google / Gmail Registration */}
            <div className="space-y-2">
              <GoogleAuthButton
                variant="full"
                label="Register Instantly with Google"
                className="w-full py-2.5 text-xs font-black shadow-sm"
              />
              <GoogleAuthButton
                variant="gmail"
                label="Register with Gmail Account"
                className="w-full py-2 text-xs font-bold text-slate-700 dark:text-slate-200"
              />
            </div>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
              <span className="flex-shrink mx-3 text-[10px] font-black text-slate-400 uppercase tracking-widest">or register with manual details</span>
              <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
            </div>

            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              {/* Account Role Selector Cards */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Select Account Type
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'user' as const, label: 'Candidate', icon: Briefcase, desc: 'Jobs & Tech' },
                  { id: 'creator' as const, label: 'Creator', icon: Video, desc: 'Videos & Merch' },
                  { id: 'employer' as const, label: 'Employer', icon: Shield, desc: 'Post Openings' }
                ].map((roleItem) => {
                  const Icon = roleItem.icon;
                  const isSelected = regRole === roleItem.id;
                  return (
                    <button
                      key={roleItem.id}
                      type="button"
                      onClick={() => setRegRole(roleItem.id)}
                      className={`p-2.5 rounded-2xl border text-left transition-all ${
                        isSelected
                          ? 'border-violet-500 bg-violet-50 dark:bg-violet-950/50 ring-2 ring-violet-500/30'
                          : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 hover:border-slate-300'
                      }`}
                    >
                      <Icon className={`w-4 h-4 mb-1 ${isSelected ? 'text-violet-600 dark:text-violet-400' : 'text-slate-400'}`} />
                      <div className="font-extrabold text-xs text-slate-900 dark:text-slate-100">{roleItem.label}</div>
                      <div className="text-[10px] text-slate-400">{roleItem.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Full Name & Username */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Yasmin Al-Ghamdi"
                    value={regName}
                    onChange={(e) => {
                      setRegName(e.target.value);
                      if (!regUsername) {
                        setRegUsername(e.target.value.toLowerCase().replace(/\s+/g, '_'));
                      }
                    }}
                    className="w-full pl-9 pr-3 py-2 text-xs clay-input bg-white dark:bg-slate-900 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Username Handle
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">@</span>
                  <input
                    type="text"
                    required
                    placeholder="username"
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                    className="w-full pl-7 pr-3 py-2 text-xs clay-input bg-white dark:bg-slate-900 rounded-xl"
                  />
                </div>
              </div>
            </div>

            {/* Email Address & Country */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Work / Personal Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                  <input
                    type="email"
                    required
                    placeholder="name@domain.com"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs clay-input bg-white dark:bg-slate-900 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Location / Country
                </label>
                <div className="relative">
                  <Globe className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                  <select
                    value={regCountry}
                    onChange={(e) => setRegCountry(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs clay-input bg-white dark:bg-slate-900 rounded-xl"
                  >
                    {COUNTRIES.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Avatar Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Choose Profile Avatar
              </label>
              <div className="flex items-center gap-3">
                {AVATAR_OPTIONS.map((av) => (
                  <button
                    key={av.id}
                    type="button"
                    onClick={() => setSelectedAvatar(av.url)}
                    className={`relative p-0.5 rounded-full transition-transform ${
                      selectedAvatar === av.url ? 'ring-3 ring-violet-500 scale-105' : 'opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={av.url} alt={av.label} className="w-10 h-10 rounded-full object-cover shadow-sm" />
                    {selectedAvatar === av.url && (
                      <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-violet-600 rounded-full flex items-center justify-center text-white">
                        <CheckCircle className="w-3 h-3" />
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Passwords */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Create Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                  <input
                    type={showRegPassword ? 'text' : 'password'}
                    required
                    placeholder="Min 6 characters"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="w-full pl-9 pr-8 py-2 text-xs clay-input bg-white dark:bg-slate-900 rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegPassword(!showRegPassword)}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                  >
                    {showRegPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Confirm Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                  <input
                    type={showRegPassword ? 'text' : 'password'}
                    required
                    placeholder="Re-enter password"
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs clay-input bg-white dark:bg-slate-900 rounded-xl"
                  />
                </div>
              </div>
            </div>

            {/* Password strength bar */}
            {regPassword && (
              <div className="space-y-1">
                <div className="flex h-1.5 w-full rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                  <div
                    className={`h-full transition-all duration-300 ${
                      pwStrength <= 1
                        ? 'w-1/4 bg-rose-500'
                        : pwStrength === 2
                        ? 'w-2/4 bg-amber-500'
                        : pwStrength === 3
                        ? 'w-3/4 bg-blue-500'
                        : 'w-full bg-emerald-500'
                    }`}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>Password Security:</span>
                  <span className="font-bold text-slate-600 dark:text-slate-300">
                    {pwStrength <= 1 ? 'Weak' : pwStrength === 2 ? 'Fair' : pwStrength === 3 ? 'Good' : 'Very Strong'}
                  </span>
                </div>
              </div>
            )}

            {/* Terms checkbox */}
            <div className="flex items-start gap-2 pt-1 text-xs">
              <input
                type="checkbox"
                id="terms"
                checked={agreeTerms}
                onChange={(e) => setAgreeTerms(e.target.checked)}
                className="mt-0.5 rounded border-slate-300 text-violet-600 focus:ring-violet-500"
              />
              <label htmlFor="terms" className="text-slate-600 dark:text-slate-400 text-[11px] leading-snug cursor-pointer select-none">
                I agree to VideoHub + Global Jobs platform rules, video publishing guidelines, and privacy policy.
              </label>
            </div>

            {/* Submit Registration Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 clay-btn clay-btn-primary text-xs font-black shadow-lg shadow-violet-500/25 active:scale-95 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{loading ? 'Creating Profile...' : 'Complete Registration & Start'}</span>
            </button>
          </form>
        </div>
      )}

        {/* Modal Footer helper */}
        <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 text-center text-xs">
          {activeTab === 'login' ? (
            <p className="text-slate-500">
              Don't have an account yet?{' '}
              <button
                type="button"
                onClick={() => {
                  setActiveTab('register');
                  setErrorMsg('');
                }}
                className="font-black text-violet-600 dark:text-violet-400 hover:underline"
              >
                Create one now for free
              </button>
            </p>
          ) : (
            <p className="text-slate-500">
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  setActiveTab('login');
                  setErrorMsg('');
                }}
                className="font-black text-violet-600 dark:text-violet-400 hover:underline"
              >
                Sign In to existing account
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
