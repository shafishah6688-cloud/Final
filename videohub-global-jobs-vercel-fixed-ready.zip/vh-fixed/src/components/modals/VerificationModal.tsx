import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { X, CheckCircle, Link as LinkIcon, FileText } from 'lucide-react';

export const VerificationModal: React.FC = () => {
  const { verificationModalOpen, setVerificationModalOpen, showToast } = useApp();
  const [step, setStep] = useState(1);
  const [socialLinks, setSocialLinks] = useState('');
  const [portfolio, setPortfolio] = useState('');

  if (!verificationModalOpen) return null;

  const handleClose = () => {
    setVerificationModalOpen(false);
    setStep(1);
  };

  const handleNext = () => {
    if (step < 3) setStep(step + 1);
    else {
      showToast('Verification request submitted successfully!');
      handleClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="clay-card p-6 w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-black text-slate-900 dark:text-slate-100">Request Creator Verification</h2>
          <button onClick={handleClose} className="p-1 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="mb-8">
          <div className="flex items-center gap-2">
            {[1, 2, 3].map((s) => (
              <div key={s} className={`h-2 flex-1 rounded-full ${s <= step ? 'bg-violet-600' : 'bg-slate-200 dark:bg-slate-700'}`} />
            ))}
          </div>
          <p className="text-xs text-slate-500 mt-2 font-bold uppercase tracking-wider">Step {step} of 3</p>
        </div>

        {step === 1 && (
          <div className="space-y-4">
            <label className="block text-sm font-bold text-slate-900 dark:text-slate-100">Social Media Links</label>
            <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus-within:border-violet-500">
              <LinkIcon className="text-slate-400" />
              <input
                type="text"
                value={socialLinks}
                onChange={(e) => setSocialLinks(e.target.value)}
                placeholder="e.g. twitter.com/creator, instagram.com/creator"
                className="flex-1 bg-transparent border-none outline-none text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <label className="block text-sm font-bold text-slate-900 dark:text-slate-100">Portfolio Description</label>
            <div className="flex gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus-within:border-violet-500">
              <FileText className="text-slate-400 mt-1" />
              <textarea
                value={portfolio}
                onChange={(e) => setPortfolio(e.target.value)}
                placeholder="Tell us about your work and content goals..."
                className="flex-1 bg-transparent border-none outline-none text-slate-900 dark:text-slate-100 h-32 resize-none"
              />
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="text-center py-6">
            <div className="mx-auto w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-black text-slate-900 dark:text-slate-100 mb-2">Ready to Submit?</h3>
            <p className="text-sm text-slate-500">Your information will be reviewed by our team.</p>
          </div>
        )}

        <div className="mt-8 flex justify-end gap-3">
          {step > 1 && (
            <button
              onClick={() => setStep(step - 1)}
              className="px-6 py-2 rounded-xl font-bold text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
            >
              Back
            </button>
          )}
          <button
            onClick={handleNext}
            className="px-6 py-2 rounded-xl font-black bg-violet-600 text-white hover:bg-violet-700 transition-colors"
          >
            {step === 3 ? 'Submit Request' : 'Next'}
          </button>
        </div>
      </div>
    </div>
  );
};
