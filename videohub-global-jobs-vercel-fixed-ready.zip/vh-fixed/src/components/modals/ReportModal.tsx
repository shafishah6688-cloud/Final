import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { X, ShieldAlert, CheckCircle2 } from 'lucide-react';

export const ReportModal: React.FC = () => {
  const { reportTarget, setReportTarget, showToast } = useApp();
  const [reason, setReason] = useState('Inappropriate content');
  const [details, setDetails] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  if (!reportTarget) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const res = await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetType: reportTarget.type,
          targetId: reportTarget.id,
          targetTitle: reportTarget.title,
          reason,
          details
        })
      });

      if (!res.ok) throw new Error('Failed to submit report');
      setSubmitted(true);
      showToast('Thank you. The report has been flagged for admin moderation.');
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleClose = () => {
    setReportTarget(null);
    setSubmitted(false);
    setDetails('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md clay-card p-6 bg-white dark:bg-[#181D2E] text-slate-800 dark:text-slate-100 shadow-2xl">
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="text-center py-6">
            <div className="w-14 h-14 mx-auto rounded-3xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/20 mb-3">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-extrabold text-slate-900 dark:text-slate-100 mb-1">
              Report Received
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-5">
              Our safety and moderation team will inspect this item in the Administrator Dashboard against community standards.
            </p>
            <button
              onClick={handleClose}
              className="clay-btn clay-btn-secondary px-5 py-2 text-xs font-bold"
            >
              Done
            </button>
          </div>
        ) : (
          <div>
            <div className="flex items-center gap-2.5 mb-4 text-rose-600 dark:text-rose-400">
              <ShieldAlert className="w-6 h-6" />
              <h3 className="text-base font-extrabold tracking-tight">Report Content</h3>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 mb-4 bg-slate-50 dark:bg-slate-800/50 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
              Reporting: <strong>"{reportTarget.title}"</strong> ({reportTarget.type})
            </p>

            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-300">
                    Reason for Report (Supplementary Rules Section F)
                  </label>
                  <span className="text-[10px] text-indigo-500 font-semibold">Rules Section F</span>
                </div>
                <select
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full px-3 py-2 text-xs clay-input bg-white dark:bg-slate-800"
                >
                  <option value="Copyright infringement">Copyright infringement (Section F)</option>
                  <option value="Fake jobs">Fake jobs (Section F)</option>
                  <option value="Fraud">Fraud (Section F)</option>
                  <option value="Harassment">Harassment (Section F)</option>
                  <option value="Illegal material">Illegal material (Section F)</option>
                  <option value="Privacy violations">Privacy violations (Section F)</option>
                  <option value="Misleading commercial content">Misleading commercial content (Section F)</option>
                  <option value="Dangerous or unsafe construction practice">Dangerous or unsafe construction practice</option>
                  <option value="Other policy violation">Other policy violation</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Additional Context (Optional)</label>
                <textarea
                  rows={3}
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  placeholder="Provide timestamps, URLs, or extra details to assist moderation..."
                  className="w-full px-3 py-2 text-xs clay-input"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={handleClose}
                  className="clay-btn clay-btn-secondary px-4 py-2 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="clay-btn clay-btn-coral px-4 py-2 text-xs font-bold"
                >
                  {submitting ? 'Submitting...' : 'Submit Report'}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
