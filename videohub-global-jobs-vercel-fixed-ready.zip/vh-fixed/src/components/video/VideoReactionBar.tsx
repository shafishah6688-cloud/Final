import React, { useState, useEffect, useRef } from 'react';
import { Flame, Sparkles, Volume2, VolumeX, TrendingUp, Users } from 'lucide-react';

export interface ReactionType {
  id: 'like' | 'laugh' | 'fire' | 'mindblown' | 'rocket' | 'clap';
  label: string;
  emoji: string;
  sublabel: string;
  glowColor: string;
  activeBg: string;
  textColor: string;
}

const REACTIONS: ReactionType[] = [
  {
    id: 'like',
    label: 'Like',
    emoji: '👍',
    sublabel: 'Helpful',
    glowColor: 'shadow-blue-500/30',
    activeBg: 'bg-blue-500/15 border-blue-500/40 text-blue-500 dark:text-blue-400',
    textColor: 'text-blue-600 dark:text-blue-400'
  },
  {
    id: 'laugh',
    label: 'Laugh',
    emoji: '😂',
    sublabel: 'Haha',
    glowColor: 'shadow-amber-500/30',
    activeBg: 'bg-amber-500/15 border-amber-500/40 text-amber-500 dark:text-amber-400',
    textColor: 'text-amber-600 dark:text-amber-400'
  },
  {
    id: 'fire',
    label: 'Fire',
    emoji: '🔥',
    sublabel: 'Lit & Epic',
    glowColor: 'shadow-orange-500/30',
    activeBg: 'bg-orange-500/15 border-orange-500/40 text-orange-500 dark:text-orange-400',
    textColor: 'text-orange-600 dark:text-orange-400'
  },
  {
    id: 'mindblown',
    label: 'Mind Blown',
    emoji: '🤯',
    sublabel: 'Genius',
    glowColor: 'shadow-purple-500/30',
    activeBg: 'bg-purple-500/15 border-purple-500/40 text-purple-500 dark:text-purple-400',
    textColor: 'text-purple-600 dark:text-purple-400'
  },
  {
    id: 'clap',
    label: 'Clap',
    emoji: '👏',
    sublabel: 'Bravo',
    glowColor: 'shadow-emerald-500/30',
    activeBg: 'bg-emerald-500/15 border-emerald-500/40 text-emerald-500 dark:text-emerald-400',
    textColor: 'text-emerald-600 dark:text-emerald-400'
  },
  {
    id: 'rocket',
    label: 'Rocket',
    emoji: '🚀',
    sublabel: 'Supercharge',
    glowColor: 'shadow-rose-500/30',
    activeBg: 'bg-rose-500/15 border-rose-500/40 text-rose-500 dark:text-rose-400',
    textColor: 'text-rose-600 dark:text-rose-400'
  }
];

interface FloatingParticle {
  id: string;
  emoji: string;
  leftOffset: number; // percentage across bar or player
  size: number;
  initRot: number;
  midRot: number;
  endRot: number;
}

interface VideoReactionBarProps {
  videoId: string;
  videoTitle?: string;
  className?: string;
}

export const VideoReactionBar: React.FC<VideoReactionBarProps> = ({
  videoId,
  videoTitle,
  className = ''
}) => {
  const [counts, setCounts] = useState<Record<string, number>>({
    like: 142,
    laugh: 65,
    fire: 218,
    mindblown: 48,
    clap: 84,
    rocket: 36
  });
  const [userReactions, setUserReactions] = useState<string[]>([]);
  const [totalReactions, setTotalReactions] = useState(593);
  const [floatingParticles, setFloatingParticles] = useState<FloatingParticle[]>([]);
  const [activeBounce, setActiveBounce] = useState<string | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [comboState, setComboState] = useState<{ type: string; count: number } | null>(null);
  const comboTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Fetch reactions from backend or local seed
  useEffect(() => {
    let isMounted = true;
    fetch(`/api/videos/${videoId}/reactions`)
      .then(res => res.json())
      .then(data => {
        if (!isMounted) return;
        if (data.success && data.reactions) {
          setCounts(data.reactions);
          setUserReactions(data.userReactions || []);
          setTotalReactions(data.totalReactions || Object.values(data.reactions).reduce((a: any, b: any) => a + b, 0));
        }
      })
      .catch(() => {
        // Fallback to local storage
        try {
          const saved = localStorage.getItem(`reactions_${videoId}`);
          if (saved) {
            const parsed = JSON.parse(saved);
            if (isMounted) {
              setCounts(parsed.counts || counts);
              setUserReactions(parsed.userReactions || []);
            }
          }
        } catch {
          // ignore
        }
      });

    return () => {
      isMounted = false;
      if (comboTimerRef.current) clearTimeout(comboTimerRef.current);
    };
  }, [videoId]);

  // Subtle web audio bubble pop effect
  const playSound = (type: string) => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      const baseFreq = type === 'fire' ? 520 : type === 'laugh' ? 620 : type === 'like' ? 440 : 480;
      const freqDrift = (Math.random() - 0.5) * 60;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreq + freqDrift, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime((baseFreq + freqDrift) * 1.5, ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.04, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.09);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.1);
    } catch {
      // Audio context policy blocked or unavailable
    }
  };

  const handleReact = (reaction: ReactionType, e: React.MouseEvent<HTMLButtonElement>) => {
    // 1. Play sound
    playSound(reaction.id);

    // 2. Trigger bounce animation on button
    setActiveBounce(reaction.id);
    setTimeout(() => setActiveBounce(null), 350);

    // 3. Update combo streak
    setComboState(prev => {
      if (prev && prev.type === reaction.id) {
        return { type: reaction.id, count: prev.count + 1 };
      }
      return { type: reaction.id, count: 1 };
    });

    if (comboTimerRef.current) clearTimeout(comboTimerRef.current);
    comboTimerRef.current = setTimeout(() => {
      setComboState(null);
    }, 1800);

    // 4. Spawn floating emoji fountain particles
    const rect = e.currentTarget.getBoundingClientRect();
    const containerRect = e.currentTarget.parentElement?.getBoundingClientRect();
    const btnCenterPercent = containerRect
      ? ((rect.left + rect.width / 2 - containerRect.left) / containerRect.width) * 100
      : 50;

    const particleBatchCount = 2 + Math.floor(Math.random() * 2);
    const newParticles: FloatingParticle[] = [];

    for (let i = 0; i < particleBatchCount; i++) {
      const pId = `particle-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const drift = (Math.random() - 0.5) * 18;
      newParticles.push({
        id: pId,
        emoji: reaction.emoji,
        leftOffset: Math.max(5, Math.min(95, btnCenterPercent + drift)),
        size: 1.3 + Math.random() * 0.8,
        initRot: (Math.random() - 0.5) * 20,
        midRot: (Math.random() - 0.5) * 45,
        endRot: (Math.random() - 0.5) * 60
      });
    }

    setFloatingParticles(prev => [...prev.slice(-15), ...newParticles]);

    // Clean up particles after animation finishes
    setTimeout(() => {
      const idsToRemove = new Set(newParticles.map(p => p.id));
      setFloatingParticles(prev => prev.filter(p => !idsToRemove.has(p.id)));
    }, 1300);

    // 5. Optimistically increment count
    setCounts(prev => ({
      ...prev,
      [reaction.id]: (prev[reaction.id] || 0) + 1
    }));
    setTotalReactions(prev => prev + 1);

    if (!userReactions.includes(reaction.id)) {
      setUserReactions(prev => [...prev, reaction.id]);
    }

    // 6. Send to backend
    fetch(`/api/videos/${videoId}/react`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: reaction.id, count: 1 })
    })
      .then(res => res.json())
      .then(data => {
        if (data.success && data.reactions) {
          setCounts(data.reactions);
          setTotalReactions(data.totalReactions || totalReactions + 1);
          if (data.userReactions) setUserReactions(data.userReactions);
        }
      })
      .catch(() => {
        // Save locally
        try {
          const updatedCounts = { ...counts, [reaction.id]: (counts[reaction.id] || 0) + 1 };
          localStorage.setItem(`reactions_${videoId}`, JSON.stringify({
            counts: updatedCounts,
            userReactions: [...userReactions, reaction.id]
          }));
        } catch {
          // ignore
        }
      });
  };

  const formatCount = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'k';
    return num.toLocaleString();
  };

  return (
    <div className={`relative w-full ${className}`}>
      {/* Inline styles for 60fps GPU animated reaction fountain */}
      <style>{`
        @keyframes reactionFloatUp {
          0% {
            opacity: 0;
            transform: translateY(14px) scale(0.6) rotate(0deg);
          }
          15% {
            opacity: 1;
            transform: translateY(0px) scale(1.2) rotate(var(--init-rot));
          }
          65% {
            opacity: 0.95;
            transform: translateY(-65px) scale(1.3) rotate(var(--mid-rot));
          }
          100% {
            opacity: 0;
            transform: translateY(-130px) scale(0.95) rotate(var(--end-rot));
          }
        }
        @keyframes reactionPopScale {
          0% { transform: scale(1); }
          40% { transform: scale(1.38) rotate(-4deg); }
          75% { transform: scale(0.92) rotate(3deg); }
          100% { transform: scale(1) rotate(0deg); }
        }
        .anim-reaction-float {
          animation: reactionFloatUp 1.25s cubic-bezier(0.25, 1, 0.5, 1) forwards;
          will-change: transform, opacity;
        }
        .anim-reaction-pop {
          animation: reactionPopScale 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
      `}</style>

      {/* Floating Reaction Fountain Particle Overlay */}
      <div className="absolute inset-x-0 bottom-full pointer-events-none h-44 overflow-visible z-30">
        {floatingParticles.map(p => (
          <div
            key={p.id}
            style={{
              left: `${p.leftOffset}%`,
              fontSize: `${p.size}rem`,
              ['--init-rot' as any]: `${p.initRot}deg`,
              ['--mid-rot' as any]: `${p.midRot}deg`,
              ['--end-rot' as any]: `${p.endRot}deg`
            }}
            className="absolute bottom-2 -translate-x-1/2 anim-reaction-float drop-shadow-md select-none pointer-events-none filter drop-shadow-[0_4px_12px_rgba(0,0,0,0.3)]"
          >
            {p.emoji}
          </div>
        ))}

        {/* Combo Multiplier Pill when user clicks repeatedly */}
        {comboState && comboState.count > 1 && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-orange-500 via-rose-500 to-amber-500 text-white font-black text-xs shadow-xl shadow-orange-500/40 animate-bounce z-40 border border-white/30 backdrop-blur-md">
            <Flame className="w-3.5 h-3.5 fill-white text-white animate-pulse" />
            <span>
              {comboState.type.toUpperCase()} STREAK x{comboState.count}!
            </span>
          </div>
        )}
      </div>

      {/* Main Reaction Bar Container */}
      <div className="clay-card bg-white/95 dark:bg-[#181D2E]/95 border border-slate-200/80 dark:border-slate-800/80 rounded-2xl md:rounded-3xl p-3 md:p-3.5 shadow-lg backdrop-blur-md transition-all">
        {/* Header Ticker: Status + Live Sentiment + Mute toggle */}
        <div className="flex items-center justify-between gap-2 px-1 mb-2.5 pb-2 border-b border-slate-100 dark:border-slate-800/60 text-xs">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 font-extrabold text-[11px] border border-rose-200 dark:border-rose-900/50">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
              </span>
              Live Reactions
            </span>
            <span className="hidden sm:inline-block text-[11px] text-slate-500 dark:text-slate-400">
              Tap any reaction to engage with the creator
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-[11px] font-bold text-slate-500 dark:text-slate-400">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>{formatCount(totalReactions)} total</span>
            </span>

            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              title={soundEnabled ? 'Mute reaction sound' : 'Enable reaction sound'}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              aria-label="Toggle reaction sound"
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5 opacity-60" />}
            </button>
          </div>
        </div>

        {/* Reaction Buttons Row (Horizontal Scroll on Mobile, Full Flex on Desktop) */}
        <div className="relative flex items-center justify-between gap-1.5 md:gap-2.5 overflow-x-auto no-scrollbar py-0.5">
          {REACTIONS.map((r) => {
            const isUserReacted = userReactions.includes(r.id);
            const isBouncing = activeBounce === r.id;
            const currentCount = counts[r.id] || 0;

            // Highlight primary requested ones (like, laugh, fire)
            const isPrimary = ['like', 'laugh', 'fire'].includes(r.id);

            return (
              <button
                key={r.id}
                type="button"
                onClick={(e) => handleReact(r, e)}
                className={`group relative flex-1 min-w-[64px] md:min-w-[76px] flex flex-col items-center justify-center p-2 rounded-2xl transition-all duration-150 select-none cursor-pointer border ${
                  isUserReacted
                    ? r.activeBg + ' shadow-md ' + r.glowColor
                    : 'bg-slate-50/80 dark:bg-slate-900/40 border-slate-200/60 dark:border-slate-800 hover:bg-white dark:hover:bg-slate-800/80 hover:border-slate-300 dark:hover:border-slate-700'
                } ${isBouncing ? 'scale-95' : 'hover:-translate-y-0.5 active:scale-90'}`}
              >
                {/* Primary Pill Indicator on Like, Laugh, Fire */}
                {isPrimary && !isUserReacted && (
                  <span className="absolute -top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-violet-500 dark:bg-violet-400 ring-2 ring-white dark:ring-slate-900" />
                )}

                {/* Animated Emoji Icon with Bouncy Scale */}
                <span
                  className={`text-2xl md:text-3xl leading-none transition-transform duration-150 group-hover:scale-125 filter drop-shadow-sm ${
                    isBouncing ? 'anim-reaction-pop' : ''
                  }`}
                >
                  {r.emoji}
                </span>

                {/* Label & Live Counter */}
                <div className="mt-1 flex flex-col items-center">
                  <span className="text-[10px] md:text-[11px] font-black tracking-tight text-slate-700 dark:text-slate-200 group-hover:text-slate-900 dark:group-hover:text-white transition-colors">
                    {r.label}
                  </span>
                  <span
                    className={`text-[9px] md:text-[10px] font-mono font-bold transition-colors ${
                      isUserReacted ? r.textColor : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {formatCount(currentCount)}
                  </span>
                </div>

                {/* Sparkle ring on active user reaction */}
                {isUserReacted && (
                  <span className="absolute -bottom-1 px-1.5 py-0.2 rounded-full bg-white dark:bg-slate-900 text-[8px] font-extrabold uppercase tracking-wider shadow border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300">
                    Sent
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
