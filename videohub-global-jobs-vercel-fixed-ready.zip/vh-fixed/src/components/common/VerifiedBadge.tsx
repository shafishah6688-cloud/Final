import React from 'react';
import { CheckCircle } from 'lucide-react';

interface VerifiedBadgeProps {
  className?: string;
  size?: number;
}

export const VerifiedBadge: React.FC<VerifiedBadgeProps> = ({ className = '', size = 16 }) => {
  return (
    <CheckCircle
      className={`text-violet-500 fill-violet-500/20 ${className}`}
      style={{ width: size, height: size }}
    />
  );
};
