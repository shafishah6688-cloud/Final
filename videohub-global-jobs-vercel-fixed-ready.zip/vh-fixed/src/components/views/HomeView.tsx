import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { Video, Job, User } from '../../types/index.ts';
import {
  Sparkles,
  Flame,
  CheckCircle,
  Eye,
  Clock,
  Briefcase,
  ArrowRight,
  TrendingUp,
  Share2,
  Bookmark,
  Building2,
  MapPin,
  ChevronRight,
  Zap,
  Trophy,
  Gift,
  Coins
} from 'lucide-react';
import { VerifiedBadge } from '../common/VerifiedBadge.tsx';
import { CreatorTipsWidget } from '../common/CreatorTipsWidget.tsx';
import { QuickReactionMenu } from '../common/QuickReactionMenu.tsx';
import { CategoryFilterBar } from '../home/CategoryFilterBar.tsx';
import { VideoFeedCard } from '../video/VideoFeedCard.tsx';
import { GoogleAuthButton } from '../common/GoogleAuthButton.tsx';
import { motion } from 'motion/react';

export const HomeView: React.FC = () => {
  const {
    currentUser,
    openAuthModal,
    setActiveView,
    setActiveVideo,
    setActiveJob,
    setActiveProfileUsername,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setApplyModalJob,
    showToast,
    playlists,
    openLiveMatch,
    isAutoplay
  } = useApp();

  const [videos, setVideos] = useState<Video[]>([]);
  const [featuredJobs, setFeaturedJobs] = useState<Job[]>([]);
  const [liveMatch, setLiveMatch] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchVideos();
    fetchFeaturedJobs();
    fetchLiveMatch();
  }, [selectedCategory, searchQuery]);

  const fetchLiveMatch = async () => {
    try {
      const res = await fetch('/api/live-matches');
      if (res.ok) {
        const data = await res.json();
        if (data.matches && data.matches.length > 0) {
          setLiveMatch(data.matches[0]);
        }
      }
    } catch (e) {
      console.warn('Failed to fetch live matches', e);
    }
  };

  const fetchVideos = async () => {
    setLoading(true);
    try {
      const url = new URL('/api/videos', window.location.origin);
      if (selectedCategory && selectedCategory !== 'All') {
        url.searchParams.set('category', selectedCategory);
      }
      if (searchQuery) {
        url.searchParams.set('search', searchQuery);
      }
      url.searchParams.set('isShort', 'false');

      const res = await fetch(url.toString());
      if (res.ok) {
        const data = await res.json();
        setVideos(data.videos);
      }
    } catch (e) {
      console.warn('Failed to fetch videos', e);
    } finally {
      setLoading(false);
    }
  };

  const fetchFeaturedJobs = async () => {
    try {
      const res = await fetch('/api/jobs?featured=true');
      if (res.ok) {
        const data = await res.json();
        setFeaturedJobs(data.jobs.slice(0, 3));
      }
    } catch (e) {
      console.warn('Failed to fetch featured jobs', e);
    }
  };

  const handleVideoClick = (video: Video) => {
    setActiveVideo(video);
    setActiveView('watch');
  };

  const handleShare = (e: React.MouseEvent, video: Video) => {
    e.stopPropagation();
    navigator.clipboard?.writeText(window.location.origin + `/watch/${video.id}`);
    showToast(`Copied link to "${video.title}"`);
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Category Filter Bar at top */}
      <CategoryFilterBar
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        videoCount={videos.length}
      />

      {/* Guest Welcome & Instant Auth Banner */}
      {!currentUser && (
        <div className="clay-card p-4 sm:p-5 bg-gradient-to-r from-violet-600/10 via-indigo-600/10 to-pink-600/10 border border-violet-300/40 dark:border-violet-700/40 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-4 shadow-md">
          <div className="space-y-1 text-center md:text-left">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-violet-100 dark:bg-violet-900/50 text-violet-700 dark:text-violet-300">
              <Sparkles className="w-3 h-3 text-violet-500" />
              Instant Authentication
            </div>
            <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
              Login or Register for VideoHub & Global Jobs
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Watch 4K engineering streams, enter live match battles, apply to international roles, or trade in the store.
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap justify-center">
            <GoogleAuthButton variant="compact" label="Login with Google" className="px-3.5 py-2 text-xs font-bold" />
            <GoogleAuthButton variant="gmail" label="Login with Gmail" className="px-3.5 py-2 text-xs font-bold" />
            <button
              onClick={() => openAuthModal('login')}
              className="px-4 py-2 rounded-2xl text-xs font-black bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 hover:border-violet-400 hover:shadow transition cursor-pointer"
            >
              Login
            </button>
            <button
              onClick={() => openAuthModal('register')}
              className="clay-btn clay-btn-primary px-4 py-2 text-xs font-black shadow-md shadow-violet-500/25 cursor-pointer"
            >
              Registration
            </button>
          </div>
        </div>
      )}

      {/* Live Match Arena Spotlight Banner for Subscribers */}
      {liveMatch && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="clay-card p-4 sm:p-5 bg-gradient-to-r from-red-500/15 via-purple-500/15 to-blue-500/15 border-2 border-red-500/40 relative overflow-hidden shadow-xl"
        >
          <div className="absolute top-0 right-0 transform translate-x-8 -translate-y-8 w-44 h-44 bg-gradient-to-bl from-rose-500/20 to-transparent rounded-full blur-2xl pointer-events-none" />

          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
            <div className="flex items-start sm:items-center gap-3">
              <div className="relative">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-rose-600 via-pink-600 to-amber-500 text-white flex items-center justify-center shadow-lg shadow-rose-500/30">
                  <Zap className="w-6 h-6 animate-pulse" />
                </div>
                <span className="absolute -top-1 -right-1 px-1.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-red-600 text-white shadow-sm flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                  PK
                </span>
              </div>

              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[11px] font-black text-rose-500 uppercase tracking-widest flex items-center gap-1">
                    Subscriber Battle Arena
                  </span>
                  <span className="text-xs text-slate-400">•</span>
                  <span className="text-xs font-bold text-amber-500 flex items-center gap-1">
                    <Coins className="w-3.5 h-3.5" />
                    {(liveMatch.winningsPool?.totalCoins || 50000).toLocaleString()} Coins Prize Pool
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white flex items-center gap-2 flex-wrap mt-0.5">
                  <span>{liveMatch.redParticipant?.username || 'Team Red'}</span>
                  <span className="text-rose-500 text-sm font-black italic">VS</span>
                  <span>{liveMatch.blueParticipant?.username || 'Team Blue'}</span>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-500 border border-emerald-500/30">
                    Active Drops Inside!
                  </span>
                </h3>
              </div>
            </div>

            <div className="flex items-center gap-3 self-end md:self-auto">
              <button
                onClick={() => openLiveMatch(liveMatch.id)}
                className="clay-btn bg-gradient-to-r from-red-600 via-pink-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-black text-xs sm:text-sm px-5 py-2.5 rounded-2xl shadow-lg shadow-rose-600/30 flex items-center gap-2 hover:scale-105 active:scale-95 transition"
              >
                <Trophy className="w-4 h-4 text-amber-300" />
                <span>Enter Match & Win</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      )}

      <CreatorTipsWidget />

      {/* Featured Global Jobs Spotlight Banner */}
      {!searchQuery && selectedCategory === 'All' && featuredJobs.length > 0 && (
        <div className="clay-card p-5 lg:p-6 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-blue-500/10 border border-emerald-300/40 dark:border-emerald-700/40 relative overflow-hidden">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
            <div>
              <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-extrabold text-xs uppercase tracking-wider">
                <Briefcase className="w-4 h-4" />
                Global Career Spotlight • Façade & Engineering
              </div>
              <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white mt-1">
                Featured International Openings
              </h2>
            </div>
            <button
              onClick={() => setActiveView('jobs')}
              className="clay-btn clay-btn-mint px-4 py-2 text-xs font-bold flex items-center gap-2 self-start md:self-auto shadow-sm"
            >
              Browse All Jobs
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {featuredJobs.map((job) => (
              <div
                key={job.id}
                onClick={() => {
                  setActiveJob(job);
                  setActiveView('jobs');
                }}
                className="clay-card p-3.5 bg-white/90 dark:bg-slate-800/90 hover:border-emerald-400 cursor-pointer transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <img
                      src={job.companyLogo}
                      alt={job.company}
                      className="w-9 h-9 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shadow-sm"
                    />
                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-lg bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300">
                      {job.employmentType}
                    </span>
                  </div>
                  <h4 className="text-xs font-extrabold text-slate-900 dark:text-slate-100 line-clamp-1">
                    {job.title}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-1 truncate">
                    <Building2 className="w-3 h-3 flex-shrink-0" />
                    {job.company}
                  </p>
                  <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5 truncate">
                    <MapPin className="w-3 h-3 flex-shrink-0 text-rose-400" />
                    {job.location}
                  </p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                  <span className="text-xs font-black text-emerald-600 dark:text-emerald-400">
                    {job.currency} {job.salaryMin.toLocaleString()} - {job.salaryMax.toLocaleString()}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setApplyModalJob(job);
                    }}
                    className="clay-btn clay-btn-primary px-2.5 py-1 text-[10px] font-bold"
                  >
                    Apply Now
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Creator Spotlight Section */}
      {!searchQuery && selectedCategory === 'All' && (
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-black text-slate-900 dark:text-slate-100 tracking-tight flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              Creator Spotlight
            </h3>
          </div>
          <div className="flex gap-4 overflow-x-auto pb-4 -mb-4 no-scrollbar">
            {[
              { id: 'u1', name: 'Tech Architect', username: 'techarch', avatar: 'https://i.pravatar.cc/150?u=techarch', followers: 125000 },
              { id: 'u2', name: 'Design Guru', username: 'designguru', avatar: 'https://i.pravatar.cc/150?u=designguru', followers: 85000 },
              { id: 'u3', name: 'BIM Expert', username: 'bimexpert', avatar: 'https://i.pravatar.cc/150?u=bimexpert', followers: 210000 },
              { id: 'u4', name: 'Construction Pro', username: 'constpro', avatar: 'https://i.pravatar.cc/150?u=constpro', followers: 45000 },
              { id: 'u5', name: 'Creative Coder', username: 'creativecode', avatar: 'https://i.pravatar.cc/150?u=creativecode', followers: 98000 },
            ].map((creator) => (
              <div
                key={creator.id}
                className="clay-card p-4 min-w-[200px] flex flex-col items-center text-center gap-3"
              >
                <img
                  src={creator.avatar}
                  alt={creator.name}
                  className="w-16 h-16 rounded-full object-cover border-2 border-slate-200 dark:border-slate-700 shadow-sm"
                />
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                    {creator.name}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    @{creator.username}
                  </p>
                  <p className="text-[11px] font-semibold text-violet-600 dark:text-violet-400 mt-1">
                    {creator.followers.toLocaleString()} followers
                  </p>
                </div>
                <button
                  className="clay-btn clay-btn-primary w-full py-1.5 text-xs font-bold"
                  onClick={(e) => {
                    e.stopPropagation();
                    showToast(`Subscribed to ${creator.name}`);
                  }}
                >
                  Subscribe
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Top Creators Leaderboard */}
      {!searchQuery && selectedCategory === 'All' && (
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-black text-slate-900 dark:text-slate-100 tracking-tight flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-500" />
              Top Creators
            </h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { id: 't1', name: 'Aluminium Pro', avatar: 'https://i.pravatar.cc/150?u=alup', engagement: '98.5', rank: 1 },
              { id: 't2', name: 'Glass Master', avatar: 'https://i.pravatar.cc/150?u=glassm', engagement: '96.2', rank: 2 },
              { id: 't3', name: 'BIM Guru', avatar: 'https://i.pravatar.cc/150?u=bimguru', engagement: '94.8', rank: 3 },
            ].map((creator) => (
              <div
                key={creator.id}
                className="clay-card p-4 flex items-center gap-4 hover:border-emerald-300 transition-colors"
              >
                <div className="relative">
                  <img
                    src={creator.avatar}
                    alt={creator.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-slate-200 dark:border-slate-700"
                  />
                  <motion.div 
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    whileHover={{ scale: 1.2, rotate: 10 }}
                    className={`absolute -top-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black text-white shadow-sm ${
                    creator.rank === 1 ? 'bg-amber-400' : 
                    creator.rank === 2 ? 'bg-slate-400' : 'bg-orange-700'
                  }`}>
                    {creator.rank}
                  </motion.div>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                    {creator.name}
                  </h4>
                  <p className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                    {creator.engagement}% engagement
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

        {/* Recommended for You */}
        {!searchQuery && videos.length > 0 && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-black text-slate-900 dark:text-slate-100 tracking-tight flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-violet-500" />
                Recommended for You
              </h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {videos
                // Mock 'AI' algorithm: Suggest videos based on categories in playlists, then shuffle
                .filter(v => !playlists.flatMap(p => p.videoIds).includes(v.id))
                .sort((a, b) => {
                  const playlistCategories = playlists.map(p => videos.find(v => p.videoIds.includes(v.id))?.category).filter(Boolean);
                  const aScore = playlistCategories.includes(a.category) ? 1 : 0;
                  const bScore = playlistCategories.includes(b.category) ? 1 : 0;
                  return bScore - aScore;
                })
                .slice(0, 4)
                .map((video) => (
                <div
                  key={video.id}
                  draggable
                  onDragStart={(e) => e.dataTransfer.setData('videoId', video.id)}
                  onClick={() => handleVideoClick(video)}
                  className="clay-card p-3 group cursor-pointer flex flex-col justify-between"
                >
                  <div className="relative aspect-video rounded-2xl overflow-hidden bg-slate-900 mb-3 shadow-inner">
                    <img
                      src={video.thumbnailUrl}
                      alt={video.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded-lg bg-black/75 text-white text-[11px] font-bold">
                      {video.duration}
                    </span>
                  </div>
                  <h4 className="text-xs font-extrabold text-slate-900 dark:text-slate-100 line-clamp-2 leading-snug group-hover:text-violet-600 transition-colors">
                    {video.title}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                    {video.creator.name}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Main Video Feed with Category Filter Bar */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-violet-600 dark:text-violet-400" />
              <h3 className="text-lg md:text-xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
                {searchQuery ? `Search Results for "${searchQuery}"` : selectedCategory === 'All' ? 'Main Video Feed' : `${selectedCategory} Videos`}
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-bold">{videos.length} videos</span>
          </div>

          {/* Category Filter Bar Above Main Video Feed */}
          <CategoryFilterBar
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            videoCount={videos.length}
          />

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <div key={n} className="clay-card p-3 animate-pulse space-y-3">
                <div className="w-full aspect-video rounded-2xl bg-slate-200 dark:bg-slate-800" />
                <div className="flex gap-2.5">
                  <div className="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-800 flex-shrink-0" />
                  <div className="space-y-1.5 flex-1">
                    <div className="h-3.5 bg-slate-200 dark:bg-slate-800 rounded w-3/4" />
                    <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded w-1/2" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : videos.length === 0 ? (
          <div className="clay-card p-12 text-center max-w-lg mx-auto">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-violet-100 dark:bg-violet-950/60 text-violet-600 flex items-center justify-center mb-4">
              <Sparkles className="w-8 h-8" />
            </div>
            <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100 mb-1">
              No videos found in this category
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Try switching category filters or upload your own video to share with the engineering community.
            </p>
            <button
              onClick={() => setSelectedCategory('All')}
              className="clay-btn clay-btn-primary px-4 py-2 text-xs font-bold"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {videos.map((video) => (
              <VideoFeedCard
                key={video.id}
                video={video}
                isAutoplay={isAutoplay}
                onVideoClick={handleVideoClick}
                onShare={handleShare}
                onCreatorClick={(username) => {
                  setActiveProfileUsername(username);
                  setActiveView('profile');
                }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Shorts Spotlight Rail */}
      {!searchQuery && (
        <div className="clay-card p-5 bg-gradient-to-r from-rose-500/5 via-purple-500/5 to-pink-500/5 border border-rose-300/30 dark:border-rose-700/30">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-rose-500 to-pink-500 text-white flex items-center justify-center shadow-md shadow-rose-500/30">
                <Flame className="w-4 h-4 fill-white" />
              </div>
              <h3 className="text-base font-black text-slate-900 dark:text-slate-100 tracking-tight">
                Trending Vertical Shorts
              </h3>
            </div>
            <button
              onClick={() => setActiveView('shorts')}
              className="text-xs font-bold text-rose-600 dark:text-rose-400 flex items-center gap-1 hover:underline"
            >
              Watch Fullscreen
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {[
              {
                id: 'v-short-1',
                title: 'Spider Glass Fitting 10M Test 💥',
                views: '184K',
                thumbnail: 'https://images.unsplash.com/photo-1506157786151-b8491531f063?w=400&h=700&fit=crop'
              },
              {
                id: 'v-short-2',
                title: 'Massive 5-Axis CNC Milling ⚡',
                views: '295K',
                thumbnail: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=400&h=700&fit=crop'
              },
              {
                id: 'v-short-3',
                title: 'AutoCAD Detail in 30 Seconds 📐',
                views: '89K',
                thumbnail: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=400&h=700&fit=crop'
              },
              {
                id: 'v-short-4',
                title: 'Claymorphic 3D Inset Shadows 🎨',
                views: '142K',
                thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&h=700&fit=crop'
              },
              {
                id: 'v-short-5',
                title: '1000 Pascal Water Rig Test 🌊',
                views: '215K',
                thumbnail: 'https://images.unsplash.com/photo-1517646287270-a5a9ca602e5c?w=400&h=700&fit=crop'
              }
            ].map((short) => (
              <div
                key={short.id}
                onClick={() => setActiveView('shorts')}
                className="group relative aspect-[9/16] rounded-2xl overflow-hidden cursor-pointer shadow-md hover:scale-[1.02] transition-transform duration-200"
              >
                <img
                  src={short.thumbnail}
                  alt={short.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent p-3 flex flex-col justify-end text-white">
                  <h4 className="text-xs font-bold leading-tight line-clamp-2">
                    {short.title}
                  </h4>
                  <span className="text-[10px] text-slate-300 mt-1 font-semibold flex items-center gap-1">
                    <Eye className="w-3 h-3" />
                    {short.views} views
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
