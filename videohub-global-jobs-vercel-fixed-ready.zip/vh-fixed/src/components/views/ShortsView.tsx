import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { Video, StoreProduct } from '../../types/index.ts';
import {
  Heart,
  MessageCircle,
  Share2,
  Volume2,
  VolumeX,
  Play,
  ChevronUp,
  ChevronDown,
  CheckCircle,
  ShieldAlert,
  Send,
  X,
  Music,
  PlusCircle,
  RefreshCw,
  Trash2,
  Flame,
  Sparkles,
  Repeat2,
  ShoppingBag,
  ExternalLink
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const ShortsView: React.FC = () => {
  const {
    currentUser,
    setActiveProfileUsername,
    setActiveView,
    setReportTarget,
    showToast,
    setAuthModalOpen,
    navigateToUpload,
    addToCart,
    openStore,
    setIsCartOpen,
    isAutoplay
  } = useApp();

  const [shorts, setShorts] = useState<Video[]>([]);
  const [storeProducts, setStoreProducts] = useState<StoreProduct[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [comments, setComments] = useState<any[]>([]);
  const [newCommentText, setNewCommentText] = useState('');
  const [playbackError, setPlaybackError] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [followedMap, setFollowedMap] = useState<Record<string, boolean>>({});
  const [isDeleting, setIsDeleting] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const touchStartY = useRef<number | null>(null);

  useEffect(() => {
    fetchShorts();

    // Fetch store products for shoppable shorts
    fetch('/api/store/products')
      .then(r => r.json())
      .then(d => {
        if (d.products) setStoreProducts(d.products);
      })
      .catch(() => {});
  }, []);

  const fetchShorts = async () => {
    setIsRefreshing(true);
    try {
      const res = await fetch('/api/shorts');
      if (res.ok) {
        const data = await res.json();
        setShorts(data.shorts || []);
        if (data.shorts && data.shorts.length > 0) {
          fetchComments(data.shorts[0].id);
        }
      }
    } catch (e) {
      console.warn('Error fetching shorts:', e);
    } finally {
      setIsRefreshing(false);
    }
  };

  const currentShort = shorts[currentIndex];

  // Match a relevant store product for this short (creator merch / demonstrated gear)
  const activeShortProduct = storeProducts.find(p =>
    (currentShort && p.sellerId === currentShort.creatorId) ||
    (currentShort?.tags && p.tags && currentShort.tags.some(t => p.tags.some(pt => pt.toLowerCase().includes(t.toLowerCase()))))
  ) || (storeProducts.length > 0 ? storeProducts[currentIndex % storeProducts.length] : null);

  // Resolve video source:
  // If it's a server stream, blob URL, or direct path, use it directly.
  // Avoid failing Google Storage links.
  const videoSource = (currentShort?.videoUrl && !currentShort.videoUrl.includes('commondatastorage.googleapis.com'))
    ? currentShort.videoUrl
    : `/api/media/stream/video${((currentIndex % 5) + 1)}.mp4`;

  useEffect(() => {
    if (currentShort && videoRef.current) {
      fetchComments(currentShort.id);
      setPlaybackError(false);

      const v = videoRef.current;
      v.muted = isMuted;

      // If autoplay is disabled in Settings, pause on scroll and wait for user tap
      if (!isAutoplay) {
        v.pause();
        setIsPlaying(false);
        return;
      }

      const playPromise = v.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            setIsPlaying(true);
            setPlaybackError(false);
          })
          .catch((error) => {
            console.log('Autoplay blocked or paused, tap to play:', error);
            setIsPlaying(false);
          });
      }
    }
  }, [currentIndex, currentShort?.id, isAutoplay]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (commentsOpen) return;
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        handleNext();
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        handlePrev();
      } else if (e.key === ' ' || e.key === 'k') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'm') {
        e.preventDefault();
        setIsMuted(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, shorts.length, commentsOpen]);

  const fetchComments = async (videoId: string) => {
    try {
      const res = await fetch(`/api/videos/${videoId}/comments`);
      if (res.ok) {
        const data = await res.json();
        setComments(data.comments || []);
      }
    } catch (e) {
      console.warn('Error fetching comments', e);
    }
  };

  const handleNext = () => {
    if (currentIndex < shorts.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      showToast('You reached the end of the trending shorts feed!');
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  };

  const togglePlay = (e?: React.MouseEvent | React.TouchEvent) => {
    if (e) e.stopPropagation();
    const v = videoRef.current;
    if (!v) return;

    if (playbackError) {
      setPlaybackError(false);
      v.src = `/api/media/stream/video${((currentIndex % 5) + 1)}.mp4`;
      v.load();
    }

    if (!v.paused) {
      v.pause();
      setIsPlaying(false);
    } else {
      v.muted = isMuted;
      const playPromise = v.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            setIsPlaying(true);
            setPlaybackError(false);
          })
          .catch((err) => {
            console.warn('Play error, falling back to muted autoplay:', err);
            v.muted = true;
            setIsMuted(true);
            v.play()
              .then(() => {
                setIsPlaying(true);
                setPlaybackError(false);
              })
              .catch((err2) => {
                console.warn('Playback still blocked:', err2);
                setIsPlaying(false);
              });
          });
      }
    }
  };

  const handleLike = async () => {
    if (!currentShort) return;
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }

    try {
      const res = await fetch(`/api/videos/${currentShort.id}/like`, { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setShorts(prev =>
          prev.map(s =>
            s.id === currentShort.id
              ? { ...s, isLiked: data.isLiked, likesCount: data.likesCount }
              : s
          )
        );
        if (data.isLiked) {
          confetti({
            particleCount: 25,
            spread: 40,
            origin: { y: 0.7 }
          });
        }
      }
    } catch (e) {
      showToast('Could not record reaction', 'error');
    }
  };

  const handleRepost = async () => {
    if (!currentShort) return;
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }

    try {
      const res = await fetch(`/api/videos/${currentShort.id}/repost`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id })
      });
      if (res.ok) {
        const data = await res.json();
        setShorts(prev =>
          prev.map(s =>
            s.id === currentShort.id
              ? { ...s, isReposted: data.isReposted, repostsCount: data.repostsCount }
              : s
          )
        );
        if (data.isReposted) {
          confetti({
            particleCount: 30,
            spread: 50,
            origin: { y: 0.6 }
          });
          showToast('Short reposted to your channel profile!');
        } else {
          showToast('Repost removed');
        }
      }
    } catch (e) {
      showToast('Could not repost short', 'error');
    }
  };

  const handleFollowCreator = (creatorId: string) => {
    setFollowedMap(prev => {
      const next = !prev[creatorId];
      showToast(next ? 'Subscribed to creator channel' : 'Unsubscribed from channel');
      return { ...prev, [creatorId]: next };
    });
  };

  const handleDeleteShort = async () => {
    if (!currentShort) return;
    if (!window.confirm(`Are you sure you want to delete this short: "${currentShort.title}"?`)) {
      return;
    }

    setIsDeleting(true);
    try {
      const res = await fetch(`/api/videos/${currentShort.id}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('Short deleted successfully');
        const remaining = shorts.filter(s => s.id !== currentShort.id);
        setShorts(remaining);
        if (currentIndex >= remaining.length) {
          setCurrentIndex(Math.max(0, remaining.length - 1));
        }
      } else {
        const data = await res.json().catch(() => ({}));
        showToast(data.error || 'Failed to delete short', 'error');
      }
    } catch (e: any) {
      showToast(e.message || 'Error deleting short', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const handlePostComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim() || !currentShort) return;
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }

    try {
      const res = await fetch(`/api/videos/${currentShort.id}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: newCommentText })
      });
      if (res.ok) {
        const data = await res.json();
        setComments(prev => [data.comment, ...prev]);
        setNewCommentText('');
        showToast('Comment posted!');
        setShorts(prev =>
          prev.map(s => s.id === currentShort.id ? { ...s, commentsCount: s.commentsCount + 1 } : s)
        );
      }
    } catch (e) {
      showToast('Error posting comment', 'error');
    }
  };

  const handleShare = () => {
    if (!currentShort) return;
    navigator.clipboard?.writeText(window.location.origin + `/watch/${currentShort.id}`);
    showToast('Copied link to short!');
  };

  // Touch gesture support for vertical swiping
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartY.current === null) return;
    const touchEndY = e.changedTouches[0].clientY;
    const diff = touchStartY.current - touchEndY;

    if (diff > 50) {
      // Swiped up -> Next short
      handleNext();
    } else if (diff < -50) {
      // Swiped down -> Prev short
      handlePrev();
    }
    touchStartY.current = null;
  };

  if (!currentShort) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <div className="clay-card p-8 text-center max-w-sm space-y-4">
          <div className="w-16 h-16 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-500 mx-auto flex items-center justify-center">
            <Flame className="w-8 h-8" />
          </div>
          <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
            No Shorts Available Yet
          </h3>
          <p className="text-xs text-slate-500">
            Be the very first creator to publish a vertical short or reel!
          </p>
          <button
            onClick={() => navigateToUpload('short')}
            className="clay-btn clay-btn-coral w-full py-2.5 text-xs font-black flex items-center justify-center gap-2"
          >
            <PlusCircle className="w-4 h-4" />
            Upload Your First Short
          </button>
        </div>
      </div>
    );
  }

  const isFollowed = followedMap[currentShort.creatorId];
  const isUserUploaded = currentShort.id.includes('-up-') || currentShort.creatorId === currentUser?.id;
  const isRecentShort = isUserUploaded || (Date.now() - new Date(currentShort.createdAt).getTime() < 86400000);

  return (
    <div className="relative flex flex-col items-center justify-center min-h-[calc(100vh-80px)] py-2 sm:py-4">
      {/* Top Quick Actions Bar */}
      <div className="w-full max-w-[420px] flex items-center justify-between px-3 py-2 mb-2">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/10 text-rose-600 dark:text-rose-400 font-black text-xs">
            <Flame className="w-4 h-4" />
            <span>Shorts Reel</span>
            <span className="text-[10px] text-slate-400 font-mono">({currentIndex + 1}/{shorts.length})</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchShorts}
            disabled={isRefreshing}
            className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-rose-500 transition active:scale-95 disabled:opacity-50"
            title="Refresh Feed"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={() => navigateToUpload('short')}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-rose-500 to-pink-500 text-white font-black text-xs shadow-md shadow-rose-500/30 hover:from-rose-600 hover:to-pink-600 transition flex items-center gap-1.5 active:scale-95"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Upload Short</span>
          </button>
        </div>
      </div>

      {/* Container simulating vertical phone frame on desktop */}
      <div
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        className="relative w-full max-w-[420px] h-[780px] max-h-[85vh] rounded-3xl overflow-hidden bg-black shadow-2xl flex items-center justify-center border-4 border-slate-800 select-none"
      >
        {/* Video Element */}
        <video
          ref={videoRef}
          key={currentShort.id}
          src={videoSource}
          poster={currentShort.thumbnailUrl}
          loop
          muted={isMuted}
          playsInline
          preload="auto"
          onClick={(e) => togglePlay(e)}
          className="w-full h-full object-cover cursor-pointer"
          onPlaying={() => {
            setIsPlaying(true);
            setPlaybackError(false);
          }}
          onError={(e) => {
            console.warn('Video playback error for short:', e);
            const v = videoRef.current;
            if (v && !v.src.endsWith('/video1.mp4')) {
              // Fallback to local high-speed sample clip
              v.src = '/api/media/stream/video1.mp4';
              v.load();
              v.play()
                .then(() => {
                  setIsPlaying(true);
                  setPlaybackError(false);
                })
                .catch(() => {
                  setIsPlaying(false);
                });
            } else {
              setPlaybackError(true);
            }
          }}
          onLoadedData={() => setPlaybackError(false)}
        />

        {/* Playback Error Overlay */}
        {playbackError && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/85 text-white z-20 p-6 text-center">
            <ShieldAlert className="w-12 h-12 text-rose-500 mb-3 animate-bounce" />
            <p className="text-base font-extrabold text-white mb-1">Stream Optimizing</p>
            <p className="text-xs text-slate-400 mb-4 max-w-xs">Tap below to stream with instant local acceleration.</p>
            <button
              type="button"
              onClick={togglePlay}
              className="px-6 py-2.5 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 rounded-2xl text-xs font-extrabold shadow-lg shadow-rose-500/30 active:scale-95 transition"
            >
              Play Video Stream
            </button>
          </div>
        )}

        {/* Center Play/Pause Button if paused */}
        {!isPlaying && !playbackError && (
          <button
            type="button"
            onClick={togglePlay}
            aria-label="Play short"
            className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 cursor-pointer z-10 transition-all pointer-events-auto backdrop-blur-[2px]"
          >
            <div className="w-18 h-18 rounded-full bg-rose-600/90 hover:bg-rose-600 text-white shadow-2xl flex items-center justify-center transform hover:scale-105 active:scale-90 transition backdrop-blur-md border border-white/20">
              <Play className="w-8 h-8 fill-white ml-1 text-white" />
            </div>
            {!isAutoplay && (
              <span className="mt-3 px-3 py-1 rounded-full bg-black/75 backdrop-blur-md text-white font-bold text-xs border border-white/20 shadow-lg animate-in fade-in">
                Auto-play paused • Tap to play
              </span>
            )}
          </button>
        )}

        {/* Top Controls: Badges, Mute Pill, Nav Arrows */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-20 pointer-events-none">
          {/* Badge or Unmute prompt */}
          <div className="flex items-center gap-2 pointer-events-auto">
            {isRecentShort && (
              <span className="px-2.5 py-0.5 rounded-full bg-gradient-to-r from-rose-500 to-pink-500 text-white font-black text-[10px] uppercase shadow-lg shadow-rose-500/40 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                {isUserUploaded ? 'Your New Short' : 'New Short'}
              </span>
            )}
            {isMuted && (
              <button
                onClick={() => setIsMuted(false)}
                className="px-2 py-0.5 rounded-full bg-black/60 text-white font-bold text-[10px] backdrop-blur-md hover:bg-black/80 transition flex items-center gap-1"
              >
                <VolumeX className="w-3 h-3 text-rose-400" />
                <span>Tap for sound</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-1 pointer-events-auto">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-2 rounded-xl bg-black/50 backdrop-blur-md text-white hover:bg-black/70 transition"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            </button>
            <button
              onClick={handlePrev}
              disabled={currentIndex === 0}
              className="p-2 rounded-xl bg-black/50 text-white disabled:opacity-30 hover:bg-black/70 transition"
              title="Previous Short (Up)"
            >
              <ChevronUp className="w-4 h-4" />
            </button>
            <button
              onClick={handleNext}
              disabled={currentIndex === shorts.length - 1}
              className="p-2 rounded-xl bg-black/50 text-white disabled:opacity-30 hover:bg-black/70 transition"
              title="Next Short (Down)"
            >
              <ChevronDown className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right Vertical Action Bar */}
        <div className="absolute right-3 bottom-20 flex flex-col items-center gap-3.5 z-20">
          {/* Creator Avatar with Follow Button */}
          <div className="relative mb-1">
            <button
              onClick={() => {
                setActiveProfileUsername(currentShort.creator.username);
                setActiveView('profile');
              }}
              className="w-11 h-11 rounded-full overflow-hidden border-2 border-white shadow-lg"
            >
              <img
                src={currentShort.creator.avatar}
                alt={currentShort.creator.name}
                className="w-full h-full object-cover"
              />
            </button>
            <button
              onClick={() => handleFollowCreator(currentShort.creatorId)}
              className={`absolute -bottom-1.5 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase shadow transition ${
                isFollowed ? 'bg-slate-700 text-white' : 'bg-rose-500 text-white hover:bg-rose-600'
              }`}
            >
              {isFollowed ? '✓' : '+'}
            </button>
          </div>

          {/* Like */}
          <button
            onClick={handleLike}
            className="flex flex-col items-center group active:scale-90 transition"
          >
            <div
              className={`w-11 h-11 rounded-2xl flex items-center justify-center backdrop-blur-md transition ${
                currentShort.isLiked
                  ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/40'
                  : 'bg-black/50 text-white hover:bg-black/70'
              }`}
            >
              <Heart className={`w-5 h-5 ${currentShort.isLiked ? 'fill-white' : ''}`} />
            </div>
            <span className="text-[11px] font-bold text-white mt-1 drop-shadow">
              {currentShort.likesCount.toLocaleString()}
            </span>
          </button>

          {/* Comments */}
          <button
            onClick={() => setCommentsOpen(!commentsOpen)}
            className="flex flex-col items-center group active:scale-90 transition"
          >
            <div className="w-11 h-11 rounded-2xl bg-black/50 backdrop-blur-md text-white flex items-center justify-center hover:bg-black/70 transition">
              <MessageCircle className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-white mt-1 drop-shadow">
              {currentShort.commentsCount}
            </span>
          </button>

          {/* Repost */}
          <button
            onClick={handleRepost}
            className="flex flex-col items-center group active:scale-90 transition"
            title="Repost this Short"
          >
            <div
              className={`w-11 h-11 rounded-2xl backdrop-blur-md flex items-center justify-center transition ${
                currentShort.isReposted
                  ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/40'
                  : 'bg-black/50 text-white hover:bg-black/70'
              }`}
            >
              <Repeat2 className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-white mt-1 drop-shadow">
              {currentShort.repostsCount && currentShort.repostsCount > 0
                ? currentShort.repostsCount.toLocaleString()
                : 'Repost'}
            </span>
          </button>

          {/* Share */}
          <button
            onClick={handleShare}
            className="flex flex-col items-center group active:scale-90 transition"
          >
            <div className="w-11 h-11 rounded-2xl bg-black/50 backdrop-blur-md text-white flex items-center justify-center hover:bg-black/70 transition">
              <Share2 className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-white mt-1 drop-shadow">Share</span>
          </button>

          {/* Shoppable Product in this Short */}
          <button
            onClick={() => {
              if (activeShortProduct) {
                addToCart(activeShortProduct, 1);
                setIsCartOpen(true);
              } else {
                openStore();
              }
            }}
            className="flex flex-col items-center group active:scale-90 transition"
            title="Shop featured product in this short"
          >
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 backdrop-blur-md text-white flex items-center justify-center hover:scale-105 shadow-lg shadow-amber-500/30 transition">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-black text-amber-300 mt-1 drop-shadow uppercase tracking-wider">
              Shop
            </span>
          </button>

          {/* Delete Short (if own uploaded short or admin) */}
          {(isUserUploaded || currentUser?.role === 'admin') && (
            <button
              onClick={handleDeleteShort}
              disabled={isDeleting}
              className="flex flex-col items-center group active:scale-90 transition"
              title="Delete this short"
            >
              <div className="w-11 h-11 rounded-2xl bg-rose-600/80 hover:bg-rose-600 text-white backdrop-blur-md flex items-center justify-center transition">
                <Trash2 className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-bold text-rose-300 mt-1 drop-shadow">Delete</span>
            </button>
          )}

          {/* Report Flag */}
          <button
            onClick={() =>
              setReportTarget({
                type: 'video',
                id: currentShort.id,
                title: currentShort.title
              })
            }
            className="flex flex-col items-center group active:scale-90 transition"
            title="Report content"
          >
            <div className="w-10 h-10 rounded-2xl bg-black/40 backdrop-blur-md text-white/70 hover:text-rose-400 flex items-center justify-center transition">
              <ShieldAlert className="w-4 h-4" />
            </div>
          </button>
        </div>

        {/* Bottom Details Overlay */}
        <div className="absolute left-0 right-16 bottom-0 p-4 bg-gradient-to-t from-black/95 via-black/50 to-transparent z-10 text-white pointer-events-none">
          <div className="flex items-center gap-2 mb-1.5 pointer-events-auto">
            <span
              onClick={() => {
                setActiveProfileUsername(currentShort.creator.username);
                setActiveView('profile');
              }}
              className="font-extrabold text-sm tracking-tight hover:underline cursor-pointer"
            >
              @{currentShort.creator.username}
            </span>
            {currentShort.creator.verified && (
              <CheckCircle className="w-3.5 h-3.5 text-violet-400 fill-violet-400/20" />
            )}
            <span className="text-[10px] text-slate-300 px-2 py-0.5 rounded-md bg-white/10">
              {currentShort.category}
            </span>
          </div>

          <p className="text-xs font-semibold leading-snug line-clamp-2 drop-shadow mb-2 pointer-events-auto">
            {currentShort.title}
          </p>

          {/* Tags */}
          <div className="flex flex-wrap gap-1.5 mb-2 pointer-events-auto">
            {currentShort.tags.map(t => (
              <span key={t} className="text-[10px] font-bold text-rose-300 hover:underline cursor-pointer">
                #{t}
              </span>
            ))}
          </div>

          {/* Shoppable Product Banner Pill on Reel */}
          {activeShortProduct && (
            <div
              onClick={() => {
                addToCart(activeShortProduct, 1);
                setIsCartOpen(true);
              }}
              className="mb-2 p-1.5 pr-2.5 rounded-2xl bg-white/95 dark:bg-[#181D2E]/95 backdrop-blur-md border border-amber-400/80 shadow-lg text-slate-900 dark:text-slate-100 flex items-center justify-between gap-2 cursor-pointer pointer-events-auto hover:bg-amber-50 dark:hover:bg-slate-800 transition active:scale-95 group"
            >
              <div className="flex items-center gap-2 min-w-0">
                <img
                  src={activeShortProduct.thumbnailUrl}
                  alt={activeShortProduct.title}
                  className="w-8 h-8 rounded-xl object-cover bg-slate-900 flex-shrink-0"
                />
                <div className="min-w-0">
                  <p className="text-[11px] font-black truncate group-hover:text-amber-600 transition">
                    {activeShortProduct.title}
                  </p>
                  <p className="text-[10px] font-extrabold text-amber-600 dark:text-amber-400">
                    ${activeShortProduct.price.toFixed(2)}{' '}
                    <span className="text-[9px] text-slate-400 font-medium">
                      (≈ SAR {(activeShortProduct.price * 3.75).toFixed(0)})
                    </span>
                  </p>
                </div>
              </div>

              <span className="px-2 py-1 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-[10px] font-black uppercase tracking-wider shadow-sm flex items-center gap-1 flex-shrink-0">
                <ShoppingBag className="w-3 h-3" />
                Buy
              </span>
            </div>
          )}

          {/* Sound / Music track simulation */}
          <div className="flex items-center gap-1.5 text-[10px] text-slate-300 font-semibold pointer-events-auto">
            <Music className="w-3 h-3 text-pink-400 animate-pulse" />
            <span className="truncate">Original Sound • {currentShort.creator.name}</span>
          </div>
        </div>

        {/* Interactive Comments Drawer */}
        {commentsOpen && (
          <div className="absolute inset-x-0 bottom-0 top-1/3 bg-white dark:bg-[#181D2E] rounded-t-3xl z-30 p-4 flex flex-col shadow-2xl animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h4 className="text-xs font-extrabold text-slate-900 dark:text-slate-100">
                Comments ({comments.length})
              </h4>
              <button
                onClick={() => setCommentsOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-3 space-y-3 no-scrollbar">
              {comments.length === 0 ? (
                <p className="text-center text-xs text-slate-400 py-8">Be the first to comment on this short!</p>
              ) : (
                comments.map((c) => (
                  <div key={c.id} className="flex gap-2.5">
                    <img
                      src={c.user.avatar}
                      alt={c.user.name}
                      className="w-7 h-7 rounded-full object-cover flex-shrink-0"
                    />
                    <div className="flex-1 text-xs">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-800 dark:text-slate-200">{c.user.name}</span>
                        <span className="text-[10px] text-slate-400">@{c.user.username}</span>
                      </div>
                      <p className="text-slate-600 dark:text-slate-300 mt-0.5 leading-snug">{c.text}</p>
                    </div>
                  </div>
                ))
              )}
            </div>

            <form onSubmit={handlePostComment} className="pt-2 border-t border-slate-100 dark:border-slate-800 flex gap-2">
              <input
                type="text"
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                placeholder="Add a comment..."
                className="flex-1 px-3 py-1.5 text-xs clay-input"
              />
              <button
                type="submit"
                className="p-2 rounded-xl bg-violet-600 text-white hover:bg-violet-700 transition"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
