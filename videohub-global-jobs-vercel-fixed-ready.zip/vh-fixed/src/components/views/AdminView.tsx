import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import {
  ShieldAlert,
  Users,
  Video as VideoIcon,
  Briefcase,
  AlertTriangle,
  Send,
  FileText,
  Activity,
  CheckCircle,
  XCircle,
  Eye,
  Trash2,
  Sparkles,
  Lock,
  Search,
  ShieldCheck,
  Building2
} from 'lucide-react';

export const AdminView: React.FC = () => {
  const { currentUser, showToast, switchDemoUser } = useApp();

  const [activeTab, setActiveTab] = useState<'metrics' | 'users' | 'videos' | 'jobs' | 'reports' | 'announcements' | 'audit'>('metrics');
  const [metrics, setMetrics] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [userSearch, setUserSearch] = useState('');
  const [reports, setReports] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [allVideos, setAllVideos] = useState<any[]>([]);
  const [allJobs, setAllJobs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Broadcast announcement form
  const [announcement, setAnnouncement] = useState({ title: '', message: '', target: 'all' });
  const [sendingNotice, setSendingNotice] = useState(false);

  useEffect(() => {
    fetchAdminData();
  }, [activeTab]);

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      const [metricsRes, reportsRes, auditRes, videosRes, jobsRes, usersRes] = await Promise.all([
        fetch('/api/admin/metrics'),
        fetch('/api/admin/reports'),
        fetch('/api/admin/audit-logs'),
        fetch('/api/videos'),
        fetch('/api/jobs'),
        fetch('/api/admin/users')
      ]);

      if (metricsRes.ok) setMetrics(await metricsRes.json());
      if (reportsRes.ok) {
        const rData = await reportsRes.json();
        setReports(rData.reports || []);
      }
      if (auditRes.ok) {
        const aData = await auditRes.json();
        setAuditLogs(aData.auditLogs || []);
      }
      if (videosRes.ok) {
        const vData = await videosRes.json();
        setAllVideos(vData.videos || []);
      }
      if (jobsRes.ok) {
        const jData = await jobsRes.json();
        setAllJobs(jData.jobs || []);
      }
      if (usersRes.ok) {
        const uData = await usersRes.json();
        setUsers(uData.users || []);
      }
    } catch (e) {
      console.warn('Error loading admin data', e);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateUserStatus = async (userId: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'active' ? 'suspended' : 'active';
    try {
      const res = await fetch(`/api/admin/users/${userId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus })
      });
      if (res.ok) {
        setUsers(prev => prev.map(u => (u.id === userId ? { ...u, status: nextStatus } : u)));
        showToast(`User ${userId} status set to ${nextStatus}`);
      }
    } catch (e) {
      showToast('Error updating status', 'error');
    }
  };

  const handleUpdateUserRole = async (userId: string, role: string, verified: boolean) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}/role`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role, verified })
      });
      if (res.ok) {
        setUsers(prev => prev.map(u => (u.id === userId ? { ...u, role, verified } : u)));
        showToast(`User ${userId} updated`);
      }
    } catch (e) {
      showToast('Error updating role', 'error');
    }
  };

  const handleModerateVideo = async (videoId: string, status: string) => {
    try {
      const res = await fetch(`/api/admin/videos/${videoId}/moderation`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ moderationStatus: status })
      });
      if (res.ok) {
        setAllVideos(prev => prev.map(v => (v.id === videoId ? { ...v, moderationStatus: status } : v)));
        showToast(`Video set to ${status}`);
      }
    } catch (e) {
      showToast('Error moderating video', 'error');
    }
  };

  const handleModerateJob = async (jobId: string, status: string, featured?: boolean) => {
    try {
      const res = await fetch(`/api/admin/jobs/${jobId}/moderation`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, featured })
      });
      if (res.ok) {
        setAllJobs(prev =>
          prev.map(j => (j.id === jobId ? { ...j, status, ...(featured !== undefined ? { featured } : {}) } : j))
        );
        showToast(`Job listing updated`);
      }
    } catch (e) {
      showToast('Error moderating job', 'error');
    }
  };

  const handleResolveReport = async (reportId: string, resolution: 'resolved' | 'dismissed') => {
    try {
      const res = await fetch(`/api/admin/reports/${reportId}/resolve`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: resolution })
      });
      if (res.ok) {
        setReports(prev => prev.map(r => (r.id === reportId ? { ...r, status: resolution } : r)));
        showToast(`Report marked as ${resolution}`);
      }
    } catch (e) {
      showToast('Error resolving report', 'error');
    }
  };

  const handleSendAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!announcement.title.trim() || !announcement.message.trim()) return;
    setSendingNotice(true);
    try {
      const res = await fetch('/api/admin/announcements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(announcement)
      });
      if (res.ok) {
        showToast('Administrative announcement broadcasted to all users!');
        setAnnouncement({ title: '', message: '', target: 'all' });
      }
    } catch (e) {
      showToast('Error broadcasting announcement', 'error');
    } finally {
      setSendingNotice(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-16">
      {/* Header Banner */}
      <div className="clay-card p-6 bg-gradient-to-r from-rose-500/10 via-purple-500/10 to-indigo-500/10 border border-rose-300/40 dark:border-rose-700/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 font-extrabold text-xs uppercase tracking-wider">
              <ShieldAlert className="w-4 h-4" />
              Administrative Governance Center • admin.js
            </div>
            <h1 className="text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight mt-1">
              Platform Administration & Moderation
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Server-side authorized control over user roles, video compliance, job verification, and system audit logs.
            </p>
          </div>
        </div>

        {/* Administrator Profile Card */}
        <div className="mt-4 pt-4 border-t border-rose-200/50 dark:border-rose-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <img
              src="/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg"
              alt="Shafi Afzal Shah"
              className="w-14 h-14 rounded-2xl object-cover border-2 border-rose-500 shadow-md ring-2 ring-rose-500/30 flex-shrink-0"
            />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-black text-slate-900 dark:text-white">
                  Shafi Afzal Shah
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-500 text-white shadow-sm">
                  Super Administrator
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                shafi@dometech.sa • Platform Lead & Engineering Governance
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {currentUser?.role !== 'admin' && (
              <button
                type="button"
                onClick={async () => {
                  await switchDemoUser('u-admin');
                  fetchAdminData();
                }}
                className="px-3.5 py-1.5 rounded-xl text-xs font-black bg-rose-600 hover:bg-rose-700 text-white shadow-md shadow-rose-500/30 transition active:scale-95 flex items-center gap-1.5"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Log in as Shafi Afzal Shah</span>
              </button>
            )}
            <span className="px-2.5 py-1 rounded-xl text-xs font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-300 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              {metrics?.databaseType || 'Database Connected'}
            </span>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-5">
          {[
            { id: 'metrics', label: 'Platform KPIs', icon: Activity },
            { id: 'users', label: 'Users & Roles', icon: Users },
            { id: 'videos', label: 'Video Moderation', icon: VideoIcon },
            { id: 'jobs', label: 'Job Vacancies', icon: Briefcase },
            { id: 'reports', label: `Reports Queue (${reports.filter(r => r.status === 'pending').length})`, icon: AlertTriangle },
            { id: 'announcements', label: 'Broadcast Notices', icon: Send },
            { id: 'audit', label: 'Audit Logs', icon: FileText }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-2 rounded-2xl text-xs font-bold flex items-center gap-2 whitespace-nowrap transition active:scale-95 ${
                  isActive
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-500/25'
                    : 'bg-white/80 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* KPI Overview Tab */}
      {activeTab === 'metrics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
            {[
              { label: 'Registered Users', val: metrics?.totalUsers || 12, color: 'text-violet-600', bg: 'bg-violet-50 dark:bg-violet-950/40' },
              { label: 'Total Videos', val: metrics?.totalVideos || 20, color: 'text-rose-600', bg: 'bg-rose-50 dark:bg-rose-950/40' },
              { label: 'Active Jobs', val: metrics?.activeVacancies || 8, color: 'text-emerald-600', bg: 'bg-emerald-50 dark:bg-emerald-950/40' },
              { label: 'Job Applications', val: metrics?.totalApplications || 2, color: 'text-teal-600', bg: 'bg-teal-50 dark:bg-teal-950/40' },
              { label: 'Pro Subscriptions', val: metrics?.proSubscribers || 4, color: 'text-amber-600', bg: 'bg-amber-50 dark:bg-amber-950/40' },
              { label: 'Pending Reports', val: metrics?.pendingReports || 1, color: 'text-red-600', bg: 'bg-red-50 dark:bg-red-950/40' }
            ].map((kpi, i) => (
              <div key={i} className={`clay-card p-4 ${kpi.bg} border border-slate-200/60 dark:border-slate-800 flex flex-col justify-between`}>
                <span className="text-[10px] font-extrabold uppercase text-slate-400">{kpi.label}</span>
                <span className={`text-2xl font-black mt-2 ${kpi.color}`}>{kpi.val}</span>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="clay-card p-5 bg-white dark:bg-[#181D2E]">
              <h3 className="text-xs font-black uppercase text-slate-400 mb-3">System Specifications</h3>
              <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                  <span>Engine Runtime</span>
                  <span className="font-bold text-slate-900 dark:text-slate-100">Node.js 24.x LTS</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                  <span>Database Layer</span>
                  <span className="font-bold text-emerald-600">MongoDB Atlas / Mongoose Schema Driver</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                  <span>Video Storage</span>
                  <span className="font-bold text-slate-900 dark:text-slate-100">External Provider (Cloudinary / Mux)</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                  <span>Administrative Module</span>
                  <span className="font-bold text-rose-600">server/admin.js (Server-Authoritative)</span>
                </div>
              </div>
            </div>

            <div className="clay-card p-5 bg-white dark:bg-[#181D2E]">
              <h3 className="text-xs font-black uppercase text-slate-400 mb-3">Recent Security & Audit Events</h3>
              <div className="space-y-2">
                {auditLogs.slice(0, 4).map((log) => (
                  <div key={log.id} className="text-xs p-2 rounded-xl bg-slate-50 dark:bg-slate-900/40">
                    <div className="flex items-center justify-between font-bold text-slate-800 dark:text-slate-200">
                      <span>{log.action}</span>
                      <span className="text-[10px] text-slate-400">{new Date(log.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">{log.details}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Users & Roles Management Tab */}
      {activeTab === 'users' && (
        <div className="clay-card p-5 bg-white dark:bg-[#181D2E] space-y-4">
          <div className="flex items-center justify-between gap-3">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
              Registered Accounts ({users.length})
            </h3>
            <div className="relative w-64">
              <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search username or email..."
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs clay-input"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-900/60 text-slate-400 font-bold uppercase text-[10px]">
                <tr>
                  <th className="p-3">User</th>
                  <th className="p-3">Role</th>
                  <th className="p-3">Verified Channel</th>
                  <th className="p-3">Plan</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {users
                  .filter(u =>
                    !userSearch ||
                    u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
                    u.email.toLowerCase().includes(userSearch.toLowerCase())
                  )
                  .map((u) => (
                    <tr key={u.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                      <td className="p-3">
                        <div className="flex items-center gap-2.5">
                          <img src={u.avatar} alt={u.name} className="w-7 h-7 rounded-full object-cover" />
                          <div>
                            <p className="font-bold text-slate-800 dark:text-slate-200">{u.name}</p>
                            <p className="text-[10px] text-slate-400">@{u.username} • {u.email}</p>
                          </div>
                        </div>
                      </td>

                      <td className="p-3">
                        <select
                          value={u.role}
                          onChange={(e) => handleUpdateUserRole(u.id, e.target.value, u.verified)}
                          className="px-2 py-1 rounded-lg text-xs clay-input bg-white dark:bg-slate-800 font-bold"
                        >
                          <option value="user">User</option>
                          <option value="creator">Creator</option>
                          <option value="employer">Employer</option>
                          <option value="admin">Admin</option>
                        </select>
                      </td>

                      <td className="p-3">
                        <button
                          onClick={() => handleUpdateUserRole(u.id, u.role, !u.verified)}
                          className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                            u.verified
                              ? 'bg-violet-100 text-violet-700 dark:bg-violet-950 dark:text-violet-300'
                              : 'bg-slate-100 text-slate-400 dark:bg-slate-800'
                          }`}
                        >
                          {u.verified ? 'Verified ✓' : 'Unverified'}
                        </button>
                      </td>

                      <td className="p-3">
                        <span className="font-semibold text-slate-600 dark:text-slate-300 uppercase text-[10px]">
                          {u.membershipPlan}
                        </span>
                      </td>

                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          u.status === 'active'
                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                        }`}>
                          {u.status}
                        </span>
                      </td>

                      <td className="p-3 text-right">
                        <button
                          onClick={() => handleUpdateUserStatus(u.id, u.status)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition ${
                            u.status === 'active'
                              ? 'text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950'
                              : 'text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950'
                          }`}
                        >
                          {u.status === 'active' ? 'Suspend' : 'Restore'}
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Video Content Moderation Tab */}
      {activeTab === 'videos' && (
        <div className="clay-card p-5 bg-white dark:bg-[#181D2E] space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
            Uploaded Videos & Shorts ({allVideos.length})
          </h3>

          <div className="space-y-3">
            {allVideos.map((video) => (
              <div key={video.id} className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/40 flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-3">
                  <img src={video.thumbnailUrl} alt={video.title} className="w-16 h-10 rounded-xl object-cover" />
                  <div>
                    <h4 className="font-extrabold text-slate-900 dark:text-slate-100">{video.title}</h4>
                    <p className="text-[10px] text-slate-400">
                      By {video.creator.name} • {video.category} • Status: <span className="font-bold uppercase">{video.moderationStatus}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleModerateVideo(video.id, 'approved')}
                    className="clay-btn clay-btn-mint px-2.5 py-1 text-[10px] font-bold"
                  >
                    Approve
                  </button>
                  <button
                    onClick={() => handleModerateVideo(video.id, 'flagged')}
                    className="clay-btn clay-btn-secondary px-2.5 py-1 text-[10px] font-bold text-amber-600"
                  >
                    Flag
                  </button>
                  <button
                    onClick={() => handleModerateVideo(video.id, 'removed')}
                    className="clay-btn clay-btn-secondary px-2.5 py-1 text-[10px] font-bold text-rose-600"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Job Postings Moderation Tab */}
      {activeTab === 'jobs' && (
        <div className="clay-card p-5 bg-white dark:bg-[#181D2E] space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
            Job Vacancies Management ({allJobs.length})
          </h3>

          <div className="space-y-3">
            {allJobs.map((job) => (
              <div key={job.id} className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/40 flex items-center justify-between gap-3 text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-extrabold text-slate-900 dark:text-slate-100">{job.title}</h4>
                    {job.featured && (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-amber-100 text-amber-700">FEATURED</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500">
                    {job.company} • {job.location} • Status: <strong className="uppercase">{job.status}</strong>
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleModerateJob(job.id, job.status, !job.featured)}
                    className="clay-btn clay-btn-secondary px-2.5 py-1 text-[10px] font-bold text-amber-600"
                  >
                    {job.featured ? 'Unfeature' : 'Boost Feature'}
                  </button>
                  <button
                    onClick={() => handleModerateJob(job.id, job.status === 'active' ? 'closed' : 'active')}
                    className="clay-btn clay-btn-secondary px-2.5 py-1 text-[10px] font-bold"
                  >
                    {job.status === 'active' ? 'Close Vacancy' : 'Reactivate'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Reports Queue Tab */}
      {activeTab === 'reports' && (
        <div className="clay-card p-5 bg-white dark:bg-[#181D2E] space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
            Community Reports & Copyright Moderation ({reports.length})
          </h3>

          <div className="space-y-3">
            {reports.map((report) => (
              <div key={report.id} className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200/60 dark:border-slate-800 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-rose-600 uppercase text-[10px]">
                    Flagged {report.targetType} • Reason: {report.reason}
                  </span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    report.status === 'pending' ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'
                  }`}>
                    {report.status}
                  </span>
                </div>
                <h4 className="font-bold text-slate-800 dark:text-slate-200">"{report.targetTitle}"</h4>
                <p className="text-slate-500 italic">"{report.details || 'No additional details provided by reporter.'}"</p>
                <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400">Reporter: {report.reporterName}</span>
                  {report.status === 'pending' && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleResolveReport(report.id, 'resolved')}
                        className="clay-btn clay-btn-mint px-3 py-1 text-[10px] font-bold"
                      >
                        Take Down / Resolve
                      </button>
                      <button
                        onClick={() => handleResolveReport(report.id, 'dismissed')}
                        className="clay-btn clay-btn-secondary px-3 py-1 text-[10px] font-bold"
                      >
                        Dismiss Flag
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Announcements Tab */}
      {activeTab === 'announcements' && (
        <div className="clay-card p-6 bg-white dark:bg-[#181D2E] space-y-4 max-w-2xl">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
            Broadcast System Announcement
          </h3>
          <p className="text-xs text-slate-500">
            Sends an immediate high-priority notification to all registered candidates, creators, and employers.
          </p>

          <form onSubmit={handleSendAnnouncement} className="space-y-3.5">
            <div>
              <label className="block text-xs font-bold mb-1">Notice Headline</label>
              <input
                type="text"
                required
                placeholder="e.g. VideoHub v2.5 Major Release: 4K Video Encoding Live"
                value={announcement.title}
                onChange={(e) => setAnnouncement({ ...announcement, title: e.target.value })}
                className="w-full px-3 py-2 text-xs clay-input"
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">Message Content</label>
              <textarea
                rows={4}
                required
                placeholder="Write message to community..."
                value={announcement.message}
                onChange={(e) => setAnnouncement({ ...announcement, message: e.target.value })}
                className="w-full px-3 py-2 text-xs clay-input"
              />
            </div>
            <button
              type="submit"
              disabled={sendingNotice}
              className="clay-btn clay-btn-coral px-5 py-2.5 text-xs font-bold shadow-md"
            >
              {sendingNotice ? 'Broadcasting...' : 'Broadcast to All Users'}
            </button>
          </form>
        </div>
      )}

      {/* Audit Logs Tab */}
      {activeTab === 'audit' && (
        <div className="clay-card p-5 bg-white dark:bg-[#181D2E] space-y-3">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
            System Audit Trail ({auditLogs.length} events logged)
          </h3>
          <div className="space-y-2">
            {auditLogs.map((log) => (
              <div key={log.id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/40 text-xs flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-violet-600 dark:text-violet-400">{log.action}</span>
                    <span className="text-[10px] text-slate-400">by {log.adminName}</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 mt-0.5">{log.details}</p>
                </div>
                <span className="text-[10px] text-slate-400 font-mono flex-shrink-0">
                  {new Date(log.timestamp).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
