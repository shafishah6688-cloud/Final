import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { LiveMatchRoom, LiveGiftItem, LiveMatchGiftEvent } from '../../types/index.ts';
import {
  Flame,
  Trophy,
  Zap,
  Gift,
  Coins,
  Send,
  Crown,
  Sparkles,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Users,
  CheckCircle,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  ChevronDown,
  X,
  Plus,
  RefreshCw,
  Award,
  Camera,
  CameraOff,
  Mic,
  MicOff,
  RotateCw,
  Radio,
  Sliders,
  Maximize2
} from 'lucide-react';
import { VerifiedBadge } from '../common/VerifiedBadge.tsx';
import confetti from 'canvas-confetti';

const GIFTS_CATALOG: LiveGiftItem[] = [
  { id: 'rose', name: 'Rose', icon: '🌹', coins: 10, points: 10, effect: 'sparkle' },
  { id: 'espresso', name: 'Espresso', icon: '☕', coins: 50, points: 50, effect: 'fire' },
  { id: 'wrench', name: 'Gold Wrench', icon: '🔧', coins: 200, points: 200, effect: 'sparkle' },
  { id: 'rocket', name: 'Turbo Rocket', icon: '🚀', coins: 500, points: 500, effect: 'rocket' },
  { id: 'trophy', name: 'Victory Cup', icon: '🏆', coins: 1200, points: 1200, effect: 'trophy' },
  { id: 'galaxy', name: 'Galaxy Blast', icon: '🌌', coins: 3000, points: 3000, exclusiveSubscriber: true, effect: 'galaxy' },
  { id: 'crown', name: 'Crown of Legends', icon: '👑', coins: 5000, points: 5000, exclusiveSubscriber: true, effect: 'crown' }
];

export const LiveMatchView: React.FC = () => {
  const {
    currentUser,
    setAuthModalOpen,
    showToast,
    userCoins,
    setUserCoins,
    activeMatchId,
    setActiveMatchId,
    setActiveProfileUsername,
    setActiveView
  } = useApp();

  const [matches, setMatches] = useState<LiveMatchRoom[]>([]);
  const [currentMatch, setCurrentMatch] = useState<LiveMatchRoom | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedTeam, setSelectedTeam] = useState<'red' | 'blue'>('red');
  const [selectedGift, setSelectedGift] = useState<LiveGiftItem>(GIFTS_CATALOG[0]);
  const [activeTab, setActiveTab] = useState<'chat' | 'gifts' | 'leaderboard'>('chat');
  const [chatInput, setChatInput] = useState('');
  const [isSubscribingToMatch, setIsSubscribingToMatch] = useState(false);
  const [isClaimingDrop, setIsClaimingDrop] = useState(false);
  const [isSendingGift, setIsSendingGift] = useState(false);
  const [flyingGifts, setFlyingGifts] = useState<{ id: string; name: string; icon: string; team: 'red' | 'blue'; donor: string }[]>([]);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newMatchTitle, setNewMatchTitle] = useState('');
  const [newMatchOpponent, setNewMatchOpponent] = useState('');
  const [winningsModalOpen, setWinningsModalOpen] = useState(false);
  const [claimedWinningsTotal, setClaimedWinningsTotal] = useState(0);

  // Video players mute/play state
  const [isHostMuted, setIsHostMuted] = useState(false);
  const [isOpponentMuted, setIsOpponentMuted] = useState(true);
  const hostVideoRef = useRef<HTMLVideoElement>(null);
  const opponentVideoRef = useRef<HTMLVideoElement>(null);
  const pipVideoRef = useRef<HTMLVideoElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Live Camera Broadcast State
  const [isBroadcastingLive, setIsBroadcastingLive] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [isCameraVideoEnabled, setIsCameraVideoEnabled] = useState(true);
  const [isCameraMicMuted, setIsCameraMicMuted] = useState(false);
  const [cameraFacingMode, setCameraFacingMode] = useState<'user' | 'environment'>('user');
  const [broadcastSlot, setBroadcastSlot] = useState<'host' | 'opponent' | 'pip'>('host');
  const [cameraFilter, setCameraFilter] = useState<'normal' | 'studio' | 'vibrant' | 'cyber'>('normal');
  const [audioLevel, setAudioLevel] = useState(0); // 0 to 100 for live mic visualizer
  const [broadcastDuration, setBroadcastDuration] = useState(0);
  const [isCameraLoading, setIsCameraLoading] = useState(false);
  const [enableCameraOnCreate, setEnableCameraOnCreate] = useState(true);

  const [isRealWebcam, setIsRealWebcam] = useState(false);
  const [cameraDiagnosticsOpen, setCameraDiagnosticsOpen] = useState(false);
  const [cameraDeviceList, setCameraDeviceList] = useState<{ video: MediaDeviceInfo[]; audio: MediaDeviceInfo[] }>({ video: [], audio: [] });
  const [cameraPermissionStatus, setCameraPermissionStatus] = useState<'granted' | 'prompt' | 'denied' | 'unknown'>('unknown');
  const [cameraErrorMessage, setCameraErrorMessage] = useState<string | null>(null);

  // Audio analyser refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Time remaining in match
  const [secondsRemaining, setSecondsRemaining] = useState(240);

  // Fetch matches
  useEffect(() => {
    fetchMatches();
    const interval = setInterval(fetchMatches, 8000);
    return () => clearInterval(interval);
  }, []);

  // Timer countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsRemaining(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Live Broadcast Timer
  useEffect(() => {
    let timer: any = null;
    if (isBroadcastingLive) {
      timer = setInterval(() => {
        setBroadcastDuration(prev => prev + 1);
      }, 1000);
    } else {
      setBroadcastDuration(0);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isBroadcastingLive]);

  // Scroll chat
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentMatch?.chatMessages]);

  // Check hardware devices and query permissions on mount
  useEffect(() => {
    checkCameraDevices();
  }, []);

  const checkCameraDevices = async () => {
    if (navigator?.mediaDevices?.enumerateDevices) {
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const video = devices.filter(d => d.kind === 'videoinput');
        const audio = devices.filter(d => d.kind === 'audioinput');
        setCameraDeviceList({ video, audio });
      } catch (err) {
        console.warn('Error enumerating devices:', err);
      }
    }
    if ((navigator as any)?.permissions?.query) {
      try {
        const status = await (navigator as any).permissions.query({ name: 'camera' });
        setCameraPermissionStatus(status.state || 'unknown');
        status.onchange = () => setCameraPermissionStatus(status.state);
      } catch (e) {
        // Ignored if camera permission query not supported
      }
    }
  };

  // Synchronize Camera MediaStream to Video Elements
  const syncMediaToElements = () => {
    if (isBroadcastingLive && cameraStream) {
      if (broadcastSlot === 'host' && hostVideoRef.current) {
        hostVideoRef.current.defaultMuted = true;
        hostVideoRef.current.muted = true;
        hostVideoRef.current.playsInline = true;
        if (hostVideoRef.current.srcObject !== cameraStream) {
          hostVideoRef.current.srcObject = cameraStream;
        }
        hostVideoRef.current.play().catch(e => console.warn('Host cam play error:', e));
        if (opponentVideoRef.current && opponentVideoRef.current.srcObject === cameraStream) {
          opponentVideoRef.current.srcObject = null;
        }
      } else if (broadcastSlot === 'opponent' && opponentVideoRef.current) {
        opponentVideoRef.current.defaultMuted = true;
        opponentVideoRef.current.muted = true;
        opponentVideoRef.current.playsInline = true;
        if (opponentVideoRef.current.srcObject !== cameraStream) {
          opponentVideoRef.current.srcObject = cameraStream;
        }
        opponentVideoRef.current.play().catch(e => console.warn('Opponent cam play error:', e));
        if (hostVideoRef.current && hostVideoRef.current.srcObject === cameraStream) {
          hostVideoRef.current.srcObject = null;
        }
      } else if (broadcastSlot === 'pip' && pipVideoRef.current) {
        pipVideoRef.current.defaultMuted = true;
        pipVideoRef.current.muted = true;
        pipVideoRef.current.playsInline = true;
        if (pipVideoRef.current.srcObject !== cameraStream) {
          pipVideoRef.current.srcObject = cameraStream;
        }
        pipVideoRef.current.play().catch(e => console.warn('PiP cam play error:', e));
      }
    } else {
      if (hostVideoRef.current && hostVideoRef.current.srcObject) {
        hostVideoRef.current.srcObject = null;
      }
      if (opponentVideoRef.current && opponentVideoRef.current.srcObject) {
        opponentVideoRef.current.srcObject = null;
      }
      if (pipVideoRef.current && pipVideoRef.current.srcObject) {
        pipVideoRef.current.srcObject = null;
      }
    }
  };

  useEffect(() => {
    syncMediaToElements();
  }, [isBroadcastingLive, cameraStream, broadcastSlot, isCameraVideoEnabled]);

  // Cleanup camera and audio on unmount
  useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach(t => t.stop());
      }
      if (audioContextRef.current) {
        audioContextRef.current.close().catch(console.warn);
      }
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [cameraStream]);

  // Robust Studio Camera Generator with BOTH Video AND Silent Audio Tracks
  const createSimulatedStudioCam = (): MediaStream => {
    const canvas = document.createElement('canvas');
    canvas.width = 1280;
    canvas.height = 720;
    const ctx = canvas.getContext('2d');
    let frame = 0;

    const draw = () => {
      if (!ctx) return;
      frame++;
      // Background gradient
      const grad = ctx.createLinearGradient(0, 0, 1280, 720);
      grad.addColorStop(0, '#0a0f1d');
      grad.addColorStop(0.5, '#1e1b4b');
      grad.addColorStop(1, '#080c14');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 1280, 720);

      // Studio grid
      ctx.strokeStyle = 'rgba(99, 102, 241, 0.15)';
      ctx.lineWidth = 1.5;
      for (let x = 0; x < 1280; x += 80) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, 720);
        ctx.stroke();
      }
      for (let y = 0; y < 720; y += 80) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(1280, y);
        ctx.stroke();
      }

      // Live Pulse Ring
      const pulse = Math.sin(frame * 0.08) * 16;
      ctx.fillStyle = 'rgba(239, 68, 68, 0.22)';
      ctx.beginPath();
      ctx.arc(640, 310, 130 + pulse, 0, Math.PI * 2);
      ctx.fill();

      // Studio avatar circle
      ctx.fillStyle = '#6366f1';
      ctx.beginPath();
      ctx.arc(640, 310, 105, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 50px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const initials = (currentUser?.name || 'STUDIO').slice(0, 2).toUpperCase();
      ctx.fillText(initials, 640, 305);

      // Label
      ctx.font = 'bold 32px system-ui, sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(currentUser?.name?.toUpperCase() || 'STUDIO BROADCASTER', 640, 460);

      ctx.font = 'bold 20px system-ui, sans-serif';
      ctx.fillStyle = '#f43f5e';
      ctx.fillText('🔴 LIVE ON AIR • STUDIO HD 1080p', 640, 500);

      // Dynamic Equalizer bars
      ctx.fillStyle = '#10b981';
      const numBars = 40;
      const barW = 14;
      const startX = 640 - (numBars * barW) / 2;
      for (let b = 0; b < numBars; b++) {
        const h = Math.abs(Math.sin(frame * 0.1 + b * 0.3)) * 60 + 8;
        ctx.fillRect(startX + b * barW, 620 - h, barW - 3, h);
      }

      // Live Stats Footer
      ctx.fillStyle = '#94a3b8';
      ctx.font = '16px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(new Date().toLocaleTimeString() + ' | 60 FPS | BROADCAST READY', 40, 680);
      ctx.textAlign = 'right';
      ctx.fillText('STUDIO STREAM FEED', 1240, 680);
    };

    const timer = setInterval(draw, 1000 / 30);
    const canvasStream = canvas.captureStream(30);

    // Create a companion silent Web Audio track so stream is complete
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        const actx = new AudioCtx();
        const dest = actx.createMediaStreamDestination();
        const osc = actx.createOscillator();
        const gain = actx.createGain();
        gain.gain.value = 0; // Silent carrier
        osc.connect(gain);
        gain.connect(dest);
        osc.start();
        dest.stream.getAudioTracks().forEach(track => canvasStream.addTrack(track));
      }
    } catch (e) {
      console.warn('Silent audio generator error:', e);
    }

    const firstTrack = canvasStream.getVideoTracks()[0];
    if (firstTrack) {
      firstTrack.addEventListener('ended', () => clearInterval(timer));
    }
    return canvasStream;
  };

  // Start Camera Broadcast (Robust Multi-tiered hardware access with graceful fallback)
  const startCameraBroadcast = async (
    facing: 'user' | 'environment' = cameraFacingMode,
    targetSlot: 'host' | 'opponent' | 'pip' = broadcastSlot
  ) => {
    setIsCameraLoading(true);
    setCameraErrorMessage(null);
    try {
      let finalStream: MediaStream | null = null;
      let acquiredRealWebcam = false;

      if (navigator?.mediaDevices?.getUserMedia) {
        // Step 1: Attempt to acquire physical video track
        let videoTrack: MediaStreamTrack | null = null;
        let audioTrack: MediaStreamTrack | null = null;

        // Try high-resolution facing mode
        try {
          const vStream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: { ideal: facing },
              width: { ideal: 1280 },
              height: { ideal: 720 }
            }
          });
          videoTrack = vStream.getVideoTracks()[0] || null;
        } catch (err1) {
          // Fallback to basic facing mode
          try {
            const vStream = await navigator.mediaDevices.getUserMedia({
              video: { facingMode: facing }
            });
            videoTrack = vStream.getVideoTracks()[0] || null;
          } catch (err2) {
            // Fallback to any generic video
            try {
              const vStream = await navigator.mediaDevices.getUserMedia({ video: true });
              videoTrack = vStream.getVideoTracks()[0] || null;
            } catch (err3: any) {
              console.warn('Physical video access failed or blocked:', err3);
              setCameraErrorMessage(err3.message || 'Camera permission denied or device busy');
            }
          }
        }

        // Step 2: Attempt to acquire physical audio track separately
        try {
          const aStream = await navigator.mediaDevices.getUserMedia({ audio: true });
          audioTrack = aStream.getAudioTracks()[0] || null;
        } catch (aErr: any) {
          console.warn('Microphone access unavailable or denied:', aErr);
        }

        // Step 3: Combine acquired physical tracks
        if (videoTrack) {
          const combinedTracks: MediaStreamTrack[] = [videoTrack];
          if (audioTrack) combinedTracks.push(audioTrack);
          finalStream = new MediaStream(combinedTracks);
          acquiredRealWebcam = true;
        }
      }

      // Step 4: If physical camera is blocked or unavailable, launch Studio WebCam stream
      if (!finalStream) {
        finalStream = createSimulatedStudioCam();
        acquiredRealWebcam = false;
        showToast('Webcam hardware blocked or restricted. Started High-Definition Studio Cam preview!', 'info');
      }

      // Step 5: Setup audio visualizer analyzer if audio track present
      if (finalStream.getAudioTracks().length > 0) {
        try {
          const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
          if (AudioCtx) {
            const audioCtx = new AudioCtx();
            audioContextRef.current = audioCtx;
            const source = audioCtx.createMediaStreamSource(finalStream);
            const analyser = audioCtx.createAnalyser();
            analyser.fftSize = 64;
            source.connect(analyser);
            analyserRef.current = analyser;

            const dataArray = new Uint8Array(analyser.frequencyBinCount);
            const updateAudioVisualizer = () => {
              if (!analyserRef.current) return;
              analyserRef.current.getByteFrequencyData(dataArray);
              let sum = 0;
              for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
              const avg = sum / dataArray.length;
              setAudioLevel(Math.min(100, Math.round((avg / 128) * 100)));
              animFrameRef.current = requestAnimationFrame(updateAudioVisualizer);
            };
            updateAudioVisualizer();
          }
        } catch (e) {
          console.warn('Audio analyser error', e);
        }
      } else {
        // Simulated audio bounce when broadcasting
        setAudioLevel(45);
      }

      setCameraStream(finalStream);
      setIsRealWebcam(acquiredRealWebcam);
      setIsBroadcastingLive(true);
      setIsCameraVideoEnabled(true);
      setIsCameraMicMuted(false);
      setBroadcastSlot(targetSlot);
      showToast(acquiredRealWebcam ? '🎥 Physical Camera LIVE in HD 1080p!' : '🎥 Studio Camera LIVE!');
    } catch (err: any) {
      showToast(`Camera error: ${err.message || 'Could not start camera'}`, 'error');
    } finally {
      setIsCameraLoading(false);
    }
  };

  // Stop Camera Broadcast
  const stopCameraBroadcast = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(t => t.stop());
    }
    if (audioContextRef.current) {
      audioContextRef.current.close().catch(console.warn);
      audioContextRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    setCameraStream(null);
    setIsBroadcastingLive(false);
    setIsRealWebcam(false);
    setAudioLevel(0);
    showToast('Camera broadcast ended.');
  };

  // Toggle Camera Video track
  const toggleCameraVideo = () => {
    if (cameraStream) {
      const vTracks = cameraStream.getVideoTracks();
      vTracks.forEach(t => {
        t.enabled = !isCameraVideoEnabled;
      });
      setIsCameraVideoEnabled(!isCameraVideoEnabled);
      showToast(!isCameraVideoEnabled ? 'Camera video enabled' : 'Camera video paused', 'info');
    }
  };

  // Toggle Camera Microphone
  const toggleCameraMic = () => {
    if (cameraStream) {
      const aTracks = cameraStream.getAudioTracks();
      aTracks.forEach(t => {
        t.enabled = isCameraMicMuted;
      });
      setIsCameraMicMuted(!isCameraMicMuted);
      showToast(isCameraMicMuted ? 'Microphone unmuted' : 'Microphone muted', 'info');
    }
  };

  // Switch Facing Camera (Front / Rear)
  const switchCameraFacing = async () => {
    const nextFacing = cameraFacingMode === 'user' ? 'environment' : 'user';
    setCameraFacingMode(nextFacing);
    if (isBroadcastingLive) {
      if (cameraStream) {
        cameraStream.getTracks().forEach(t => t.stop());
      }
      await startCameraBroadcast(nextFacing, broadcastSlot);
    }
  };

  // Cycle studio filters
  const cycleCameraFilter = () => {
    const filters: ('normal' | 'studio' | 'vibrant' | 'cyber')[] = ['normal', 'studio', 'vibrant', 'cyber'];
    const nextIdx = (filters.indexOf(cameraFilter) + 1) % filters.length;
    setCameraFilter(filters[nextIdx]);
    showToast(`Filter set to: ${filters[nextIdx].toUpperCase()}`, 'info');
  };

  const getCameraFilterStyle = () => {
    switch (cameraFilter) {
      case 'studio':
        return 'contrast(1.08) brightness(1.06) saturate(1.15)';
      case 'vibrant':
        return 'saturate(1.45) contrast(1.12)';
      case 'cyber':
        return 'hue-rotate(190deg) contrast(1.2) saturate(1.3)';
      default:
        return undefined;
    }
  };

  const fetchMatches = async () => {
    try {
      const res = await fetch('/api/live-matches');
      if (res.ok) {
        const data = await res.json();
        setMatches(data.matches || []);
        if (!currentMatch && data.matches?.length > 0) {
          const matchToSelect = activeMatchId
            ? data.matches.find((m: LiveMatchRoom) => m.id === activeMatchId) || data.matches[0]
            : data.matches[0];
          fetchMatchDetails(matchToSelect.id);
        } else if (currentMatch) {
          fetchMatchDetails(currentMatch.id, false);
        }
      }
    } catch (err) {
      console.warn('Error fetching live matches:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchMatchDetails = async (matchId: string, setFullLoading = true) => {
    if (setFullLoading) setLoading(true);
    try {
      const res = await fetch(`/api/live-matches/${matchId}`);
      if (res.ok) {
        const data = await res.json();
        setCurrentMatch(data.match);
      }
    } catch (err) {
      console.warn('Error fetching match details:', err);
    } finally {
      if (setFullLoading) setLoading(false);
    }
  };

  const isUserSubscriber = Boolean(currentUser && currentUser.membershipPlan !== 'free');

  // Send Gift function
  const handleSendGift = async (giftItem: LiveGiftItem = selectedGift) => {
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    if (!currentMatch) return;

    if (userCoins < giftItem.coins) {
      showToast(`Not enough coins! You need ${giftItem.coins} coins. Click Top-up to add coins.`, 'error');
      return;
    }

    if (giftItem.exclusiveSubscriber && !isUserSubscriber) {
      showToast(`'${giftItem.name}' is an exclusive gift for Subscribers! Subscribe to unlock.`, 'info');
      return;
    }

    setIsSendingGift(true);
    try {
      const res = await fetch(`/api/live-matches/${currentMatch.id}/gift`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          giftId: giftItem.id,
          targetTeam: selectedTeam,
          isSubscriber: isUserSubscriber
        })
      });

      if (res.ok) {
        const data = await res.json();
        // Deduct coins locally
        setUserCoins(prev => Math.max(0, prev - giftItem.coins));

        // Trigger flying gift animation
        const flyId = `fly-${Date.now()}`;
        setFlyingGifts(prev => [
          ...prev,
          {
            id: flyId,
            name: giftItem.name,
            icon: giftItem.icon,
            team: selectedTeam,
            donor: currentUser.name
          }
        ]);
        setTimeout(() => {
          setFlyingGifts(prev => prev.filter(g => g.id !== flyId));
        }, 2500);

        // Confetti if high value gift
        if (giftItem.coins >= 500) {
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.6 }
          });
        }

        showToast(
          `Sent ${giftItem.name}! Added +${data.pointsAwarded.toLocaleString()} pts (${data.multiplier}x Multiplier) to ${
            selectedTeam === 'red' ? currentMatch.host.teamName : currentMatch.opponent.teamName
          }!`
        );

        // Update match state
        setCurrentMatch(prev => {
          if (!prev) return null;
          return {
            ...prev,
            winningsPool: data.winningsPool,
            activeDrop: data.activeDrop || prev.activeDrop,
            host: { ...prev.host, score: data.hostScore },
            opponent: { ...prev.opponent, score: data.opponentScore },
            recentGifts: [data.giftEvent, ...(prev.recentGifts || [])]
          };
        });
      }
    } catch (err) {
      showToast('Failed to send gift', 'error');
    } finally {
      setIsSendingGift(false);
    }
  };

  // Claim Mystery Drop
  const handleClaimDrop = async () => {
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    if (!currentMatch?.activeDrop) return;

    if (!isUserSubscriber) {
      showToast('Mystery Gift Drops are reserved for Channel Subscribers! Upgrade to claim.', 'info');
      return;
    }

    setIsClaimingDrop(true);
    try {
      const res = await fetch(`/api/live-matches/${currentMatch.id}/claim-drop`, {
        method: 'POST'
      });
      const data = await res.json();
      if (res.ok && data.success) {
        // Award coins
        setUserCoins(prev => prev + data.prizeCoins);
        setClaimedWinningsTotal(prev => prev + data.prizeCoins);
        confetti({
          particleCount: 70,
          spread: 80,
          origin: { y: 0.5 }
        });
        showToast(`🎉 WINNER! Claimed +${data.prizeCoins} Gift Winnings Coins to your wallet!`);
        fetchMatchDetails(currentMatch.id, false);
      } else {
        showToast(data.error || 'Could not claim drop', 'error');
      }
    } catch (err) {
      showToast('Error claiming drop', 'error');
    } finally {
      setIsClaimingDrop(false);
    }
  };

  // Send Chat message
  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !currentMatch) return;
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }

    try {
      const res = await fetch(`/api/live-matches/${currentMatch.id}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: chatInput.trim(),
          isSubscriber: isUserSubscriber
        })
      });
      if (res.ok) {
        const data = await res.json();
        setChatInput('');
        setCurrentMatch(prev => {
          if (!prev) return null;
          return {
            ...prev,
            chatMessages: [...(prev.chatMessages || []), data.message]
          };
        });
      }
    } catch (err) {
      showToast('Could not send message', 'error');
    }
  };

  // Create Match Room
  const handleCreateMatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }

    try {
      const res = await fetch('/api/live-matches/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newMatchTitle,
          opponentName: newMatchOpponent
        })
      });
      if (res.ok) {
        const data = await res.json();
        showToast('Live Subscriber Match Room created successfully! ⚡');
        setIsCreateModalOpen(false);
        setNewMatchTitle('');
        setNewMatchOpponent('');
        setMatches(prev => [data.match, ...prev]);
        setCurrentMatch(data.match);
        if (enableCameraOnCreate) {
          setTimeout(() => {
            startCameraBroadcast('user', 'host');
          }, 300);
        }
      }
    } catch (err) {
      showToast('Could not create live match', 'error');
    }
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  if (loading && !currentMatch) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-500 flex items-center justify-center animate-spin">
          <RefreshCw className="w-6 h-6" />
        </div>
        <p className="text-sm font-extrabold text-slate-600 dark:text-slate-300">
          Entering Live Subscriber Match Arena...
        </p>
      </div>
    );
  }

  if (!currentMatch) {
    return (
      <div className="text-center py-20 clay-card max-w-lg mx-auto">
        <Flame className="w-12 h-12 text-rose-500 mx-auto mb-3" />
        <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">No active live match rooms</h3>
        <p className="text-xs text-slate-500 mt-1 mb-4">Start a live subscriber battle and invite challengers!</p>
        <button onClick={() => setIsCreateModalOpen(true)} className="clay-btn clay-btn-primary px-4 py-2 text-xs font-bold">
          Start Live Match
        </button>
      </div>
    );
  }

  // Calculate scores percentages for tug-of-war bar
  const totalScore = currentMatch.host.score + currentMatch.opponent.score;
  const redPercent = totalScore > 0 ? Math.round((currentMatch.host.score / totalScore) * 100) : 50;
  const bluePercent = 100 - redPercent;

  return (
    <div className="max-w-7xl mx-auto space-y-5 pb-16">
      {/* Top Banner: Match Header, Winnings Pool & Rooms Selector */}
      <div className="clay-card p-4 bg-gradient-to-r from-slate-900 via-[#181D2E] to-slate-900 text-white rounded-3xl shadow-2xl border border-rose-500/30 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <span className="flex h-3.5 w-3.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-rose-500" />
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-rose-500 text-white tracking-wider flex items-center gap-1">
                <Flame className="w-3 h-3 fill-white" />
                Live Match Arena
              </span>
              {currentMatch.status === 'speed_challenge' && (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-amber-400 text-slate-950 tracking-wider flex items-center gap-1 animate-pulse">
                  <Zap className="w-3 h-3 fill-slate-950" />
                  Speed Challenge (2x Gifts)
                </span>
              )}
            </div>
            <h2 className="text-base sm:text-lg font-black tracking-tight text-white mt-1 line-clamp-1">
              {currentMatch.title}
            </h2>
          </div>
        </div>

        {/* Center: Live Timer and Viewers */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-black/40 border border-white/10 font-mono text-xs font-bold">
            <Clock className="w-4 h-4 text-rose-400" />
            <span className="text-rose-400">{formatTimer(secondsRemaining)}</span>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-black/40 border border-white/10 text-xs font-bold text-slate-300">
            <Users className="w-4 h-4 text-emerald-400" />
            <span>{currentMatch.viewersCount.toLocaleString()} watching</span>
            <span className="text-white/40">•</span>
            <span className="text-amber-300 font-extrabold">{currentMatch.subscribersCount} Subs</span>
          </div>
        </div>

        {/* Right: Subscriber Winnings Pool & Wallet balance */}
        <div className="flex items-center gap-2">
          {/* JackPot / Winnings Pool */}
          <div
            onClick={() => setWinningsModalOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-gradient-to-r from-amber-500/20 to-orange-500/30 border border-amber-400/40 cursor-pointer hover:scale-105 transition active:scale-95"
            title="Click to view Subscriber Winnings details"
          >
            <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black">
              💰
            </div>
            <div>
              <p className="text-[10px] uppercase font-black text-amber-300 tracking-wider">
                Subscriber Winning Pool
              </p>
              <p className="text-sm font-black text-amber-100 flex items-center gap-1">
                {currentMatch.winningsPool.toLocaleString()} Coins
                <span className="text-[10px] text-amber-300 font-bold">(${(currentMatch.winningsPool / 10).toFixed(0)})</span>
              </p>
            </div>
          </div>

          {/* User Coins Quick Balance */}
          <div className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-violet-950/60 border border-violet-500/30 text-xs">
            <Coins className="w-4 h-4 text-amber-300" />
            <span className="font-extrabold text-white">{userCoins.toLocaleString()}</span>
            <button
              onClick={() => {
                setUserCoins(prev => prev + 1000);
                showToast('+1,000 Coins added to your gift wallet!');
              }}
              className="ml-1 px-1.5 py-0.5 rounded bg-violet-600 hover:bg-violet-500 text-[10px] font-bold text-white"
              title="Add 1,000 Free Demo Coins"
            >
              +Topup
            </button>
          </div>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="clay-btn clay-btn-primary px-3.5 py-2 text-xs font-bold gap-1 inline-flex items-center"
          >
            <Plus className="w-3.5 h-3.5" />
            Start Match
          </button>
        </div>
      </div>

      {/* Active Match Rooms Switcher Bar */}
      {matches.length > 1 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-xs font-extrabold text-slate-400 whitespace-nowrap">Active Rooms:</span>
          {matches.map(m => (
            <button
              key={m.id}
              onClick={() => fetchMatchDetails(m.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
                currentMatch.id === m.id
                  ? 'bg-rose-500 text-white shadow-md shadow-rose-500/30'
                  : 'clay-card bg-white/70 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping inline-block" />
              <span className="truncate max-w-[200px]">{m.title}</span>
              <span className="text-[10px] opacity-75">({m.winningsPool.toLocaleString()} Coins)</span>
            </button>
          ))}
        </div>
      )}

      {/* Main Battle Grid: Streams + Tug of War + Chat/Gifts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Battle Arena & Tug of War */}
        <div className="lg:col-span-2 space-y-4">
          {/* LIVE CAMERA STUDIO BROADCAST DOCK */}
          {!isBroadcastingLive ? (
            <div className="clay-card p-3 sm:p-4 bg-gradient-to-r from-violet-950/40 via-slate-900/80 to-rose-950/40 border border-violet-500/30 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-600 to-amber-500 text-white flex items-center justify-center shadow-lg shadow-rose-500/30">
                  <Camera className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-black text-rose-400 uppercase tracking-wider flex items-center gap-1">
                      <Radio className="w-3.5 h-3.5 animate-pulse text-red-400" />
                      Live Camera & Mic Access
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                      WebRTC HD 1080p
                    </span>
                    {cameraDeviceList.video.length > 0 && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-bold">
                        {cameraDeviceList.video.length} Camera(s) Detected
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Broadcast your live camera and microphone directly into this subscriber match room.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end flex-wrap">
                <button
                  type="button"
                  onClick={() => setCameraDiagnosticsOpen(true)}
                  className="clay-btn bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-2 rounded-xl border border-slate-700 flex items-center gap-1.5"
                  title="Test Camera & Audio Devices"
                >
                  <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Camera Help</span>
                </button>

                <select
                  value={broadcastSlot}
                  onChange={e => setBroadcastSlot(e.target.value as any)}
                  className="clay-input text-xs py-2 px-3 rounded-xl bg-slate-800 text-white font-bold border border-slate-700"
                >
                  <option value="host">Stream as Red Host</option>
                  <option value="opponent">Stream as Blue Challenger</option>
                  <option value="pip">Stream in Floating PiP</option>
                </select>

                <button
                  onClick={() => startCameraBroadcast()}
                  disabled={isCameraLoading}
                  className="clay-btn bg-gradient-to-r from-red-600 via-rose-600 to-pink-600 hover:from-red-500 hover:to-rose-500 text-white text-xs font-black px-4 py-2.5 rounded-2xl flex items-center gap-2 shadow-lg shadow-rose-600/30 hover:scale-105 active:scale-95 transition whitespace-nowrap"
                >
                  <Camera className="w-4 h-4" />
                  <span>{isCameraLoading ? 'Starting Camera...' : 'Go Live With Camera'}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="clay-card p-3 sm:p-4 bg-slate-900 border-2 border-rose-500 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-3 shadow-2xl shadow-rose-950/60">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-600 to-rose-600 text-white flex items-center justify-center shadow-lg shadow-rose-600/50">
                    <Camera className="w-5 h-5 animate-pulse" />
                  </div>
                  <span className="absolute -top-1 -right-1 flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-red-600" />
                  </span>
                </div>

                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-2 py-0.5 rounded-full bg-red-600 text-white font-black text-[10px] tracking-wider uppercase animate-pulse">
                      ON AIR LIVE
                    </span>
                    <span className="font-mono text-xs font-bold text-amber-300">
                      {formatTimer(broadcastDuration)}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      • <strong className="text-white capitalize">{broadcastSlot === 'host' ? 'Team Red Host' : broadcastSlot === 'opponent' ? 'Team Blue Challenger' : 'Floating PiP'}</strong>
                    </span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                      isRealWebcam ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40'
                    }`}>
                      {isRealWebcam ? '📹 Physical HD Webcam' : '🟣 Studio WebCam Live'}
                    </span>
                  </div>

                  {/* Real-time Voice Level Meter */}
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] text-slate-400 font-bold">MIC AUDIO:</span>
                    <div className="flex items-center gap-0.5 h-3">
                      {[1, 2, 3, 4, 5, 6, 7, 8].map(i => {
                        const active = !isCameraMicMuted && audioLevel > (i * 11);
                        return (
                          <span
                            key={i}
                            className={`w-1 rounded-full transition-all duration-75 ${
                              active
                                ? i > 6 ? 'h-3 bg-red-500' : i > 4 ? 'h-2.5 bg-amber-400' : 'h-2 bg-emerald-400'
                                : 'h-1 bg-slate-700'
                            }`}
                          />
                        );
                      })}
                    </div>
                    <span className="text-[10px] font-mono font-bold text-emerald-400">
                      {isCameraMicMuted ? 'MIC MUTED' : `${audioLevel}% Input Level`}
                    </span>
                  </div>
                </div>
              </div>

              {/* Live Broadcast Control Actions */}
              <div className="flex items-center gap-2 flex-wrap">
                {/* Cam Video Toggle */}
                <button
                  onClick={toggleCameraVideo}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                    isCameraVideoEnabled ? 'bg-slate-800 text-white hover:bg-slate-700 border border-slate-700' : 'bg-red-600 text-white shadow-md shadow-red-600/30'
                  }`}
                  title={isCameraVideoEnabled ? 'Pause Camera Video' : 'Resume Camera Video'}
                >
                  {isCameraVideoEnabled ? <Camera className="w-3.5 h-3.5" /> : <CameraOff className="w-3.5 h-3.5" />}
                  <span>{isCameraVideoEnabled ? 'Cam On' : 'Cam Paused'}</span>
                </button>

                {/* Mic Mute Toggle */}
                <button
                  onClick={toggleCameraMic}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                    !isCameraMicMuted ? 'bg-slate-800 text-white hover:bg-slate-700 border border-slate-700' : 'bg-red-600 text-white shadow-md shadow-red-600/30'
                  }`}
                  title={isCameraMicMuted ? 'Unmute Microphone' : 'Mute Microphone'}
                >
                  {!isCameraMicMuted ? <Mic className="w-3.5 h-3.5 text-emerald-400" /> : <MicOff className="w-3.5 h-3.5" />}
                  <span>{!isCameraMicMuted ? 'Mic On' : 'Muted'}</span>
                </button>

                {/* Flip Facing Camera */}
                <button
                  onClick={switchCameraFacing}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center gap-1.5 transition border border-slate-700"
                  title="Switch Front / Rear Camera"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Flip ({cameraFacingMode === 'user' ? 'Front' : 'Rear'})</span>
                </button>

                {/* Filter Selector */}
                <button
                  onClick={cycleCameraFilter}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold flex items-center gap-1.5 transition border border-slate-700"
                  title="Cycle Studio Filter"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span className="capitalize">{cameraFilter}</span>
                </button>

                {/* Slot Switcher */}
                <select
                  value={broadcastSlot}
                  onChange={e => setBroadcastSlot(e.target.value as any)}
                  className="clay-input text-xs py-1.5 px-2.5 rounded-xl bg-slate-800 text-white font-bold border border-slate-700"
                >
                  <option value="host">Slot: Host (Red)</option>
                  <option value="opponent">Slot: Opponent (Blue)</option>
                  <option value="pip">Slot: Floating PiP</option>
                </select>

                {/* Stop Broadcast */}
                <button
                  onClick={stopCameraBroadcast}
                  className="px-3 py-1.5 rounded-xl bg-rose-600/20 text-rose-300 hover:bg-rose-600 hover:text-white border border-rose-500/50 text-xs font-bold transition flex items-center gap-1"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>End Live</span>
                </button>
              </div>
            </div>
          )}

          {/* Tug-Of-War Scoreboard Header */}
          <div className="clay-card p-4 bg-slate-900 text-white rounded-3xl border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs font-black">
              {/* Team Red Info */}
              <div className="flex items-center gap-2 text-rose-400">
                <span className="w-3 h-3 rounded-full bg-rose-500 shadow-lg shadow-rose-500/50" />
                <span className="font-black text-sm">{currentMatch.host.teamName}</span>
                <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-[10px]">
                  {currentMatch.host.score.toLocaleString()} pts
                </span>
              </div>

              {/* Lead Indicator */}
              <div className="text-center px-3 py-1 rounded-full bg-white/10 font-mono text-[11px] font-bold text-amber-300">
                {currentMatch.host.score >= currentMatch.opponent.score
                  ? `Red Leads by +${(currentMatch.host.score - currentMatch.opponent.score).toLocaleString()}`
                  : `Blue Leads by +${(currentMatch.opponent.score - currentMatch.host.score).toLocaleString()}`}
              </div>

              {/* Team Blue Info */}
              <div className="flex items-center gap-2 text-cyan-400">
                <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px]">
                  {currentMatch.opponent.score.toLocaleString()} pts
                </span>
                <span className="font-black text-sm">{currentMatch.opponent.teamName}</span>
                <span className="w-3 h-3 rounded-full bg-cyan-500 shadow-lg shadow-cyan-500/50" />
              </div>
            </div>

            {/* Split Tug-Of-War Meter Bar */}
            <div className="w-full h-4 bg-slate-800 rounded-full overflow-hidden flex p-0.5 shadow-inner relative">
              <div
                className="bg-gradient-to-r from-rose-600 to-rose-400 h-full rounded-l-full transition-all duration-500 flex items-center justify-start pl-2 text-[9px] font-black"
                style={{ width: `${Math.max(10, Math.min(90, redPercent))}%` }}
              >
                {redPercent}%
              </div>
              <div
                className="bg-gradient-to-r from-cyan-400 to-cyan-600 h-full rounded-r-full transition-all duration-500 flex items-center justify-end pr-2 text-[9px] font-black"
                style={{ width: `${Math.max(10, Math.min(90, bluePercent))}%` }}
              >
                {bluePercent}%
              </div>
            </div>
          </div>

          {/* DUAL STREAM ARENA (Red Host vs Blue Challenger) */}
          <div className="relative aspect-[16/9] sm:aspect-[16/8] rounded-3xl overflow-hidden bg-black shadow-2xl border-2 border-slate-800 grid grid-cols-2">
            {/* Flying Gifts Canvas Overlay */}
            <div className="absolute inset-0 pointer-events-none z-30 overflow-hidden">
              {flyingGifts.map(fg => (
                <div
                  key={fg.id}
                  className={`absolute bottom-10 animate-bounce duration-1000 flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/80 text-white border text-xs font-bold shadow-2xl ${
                    fg.team === 'red' ? 'left-8 border-rose-500' : 'right-8 border-cyan-500'
                  }`}
                >
                  <span className="text-2xl animate-spin">{fg.icon}</span>
                  <div>
                    <p className="text-[10px] text-amber-300 font-black">{fg.donor} sent {fg.name}!</p>
                    <p className="text-[9px] text-white/80">Boosted {fg.team === 'red' ? 'Team Red' : 'Team Blue'}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* FLOATING PiP (When User broadcasts in PiP mode) */}
            {isBroadcastingLive && broadcastSlot === 'pip' && (
              <div className="absolute bottom-4 right-4 z-30 w-36 sm:w-48 aspect-video rounded-2xl overflow-hidden border-2 border-rose-500 shadow-2xl bg-slate-900 group">
                {isCameraVideoEnabled ? (
                  <video
                    ref={(el) => {
                      pipVideoRef.current = el;
                      if (el && cameraStream && el.srcObject !== cameraStream) {
                        el.defaultMuted = true;
                        el.muted = true;
                        el.playsInline = true;
                        el.srcObject = cameraStream;
                        el.play().catch(e => console.warn('PiP cam play error:', e));
                      }
                    }}
                    autoPlay
                    playsInline
                    muted={true}
                    style={{ filter: getCameraFilterStyle() }}
                    className="w-full h-full object-cover transform scale-x-[-1]"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950 text-white p-2 text-center">
                    <CameraOff className="w-5 h-5 text-rose-400 mb-1" />
                    <span className="text-[9px] font-bold">Cam Video Off</span>
                  </div>
                )}
                <div className="absolute top-1 left-1.5 px-1.5 py-0.5 rounded bg-red-600 text-white font-black text-[8px] flex items-center gap-1 shadow">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                  YOU LIVE
                </div>
                <button
                  onClick={() => setBroadcastSlot('host')}
                  className="absolute bottom-1.5 right-1.5 p-1 rounded-lg bg-black/70 text-white hover:bg-black text-[9px] flex items-center gap-1"
                  title="Expand to Host Stream"
                >
                  <Maximize2 className="w-3 h-3" />
                </button>
              </div>
            )}

            {/* Center VS Battle Stamp */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none">
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-500 to-rose-600 text-white font-black flex items-center justify-center shadow-2xl shadow-rose-500/50 border-2 border-white text-sm animate-pulse">
                VS
              </div>
            </div>

            {/* LEFT STREAM: RED TEAM (Host) */}
            <div className="relative h-full bg-slate-900 border-r border-slate-700/60 overflow-hidden group">
              {isBroadcastingLive && broadcastSlot === 'host' ? (
                isCameraVideoEnabled ? (
                  <video
                    ref={(el) => {
                      hostVideoRef.current = el;
                      if (el) {
                        el.defaultMuted = true;
                        el.muted = true;
                        el.playsInline = true;
                        if (cameraStream && el.srcObject !== cameraStream) {
                          el.srcObject = cameraStream;
                        }
                        el.play().catch(e => console.warn('Host cam play error:', e));
                      }
                    }}
                    autoPlay
                    playsInline
                    muted={true}
                    style={{ filter: getCameraFilterStyle() }}
                    className="w-full h-full object-cover transform scale-x-[-1]"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-b from-slate-900 via-rose-950/40 to-slate-900 text-white p-4">
                    <div className="w-16 h-16 rounded-full bg-rose-600/30 border-2 border-rose-500 flex items-center justify-center mb-2 animate-pulse">
                      <CameraOff className="w-8 h-8 text-rose-400" />
                    </div>
                    <p className="text-xs font-black uppercase text-rose-300">Camera Video Muted</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">Streaming Audio Only to Subscribers</p>
                    <button
                      onClick={toggleCameraVideo}
                      className="mt-3 px-3 py-1 rounded-xl bg-rose-600 text-white text-xs font-bold"
                    >
                      Turn On Camera Video
                    </button>
                  </div>
                )
              ) : (
                <video
                  ref={hostVideoRef}
                  src={currentMatch.host.videoUrl}
                  autoPlay
                  playsInline
                  loop
                  muted={isHostMuted}
                  className="w-full h-full object-cover"
                />
              )}

              {/* Red Overlay Header */}
              <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10">
                <div
                  onClick={() => {
                    setActiveProfileUsername(currentMatch.host.username);
                    setActiveView('profile');
                  }}
                  className="flex items-center gap-2 bg-black/60 backdrop-blur-md px-2.5 py-1.5 rounded-2xl cursor-pointer border border-rose-500/40 hover:bg-black/80 transition"
                >
                  <img
                    src={currentMatch.host.avatar}
                    alt={currentMatch.host.name}
                    className="w-7 h-7 rounded-full object-cover border border-rose-400"
                  />
                  <div>
                    <div className="flex items-center gap-1">
                      <span className="text-xs font-bold text-white">
                        {isBroadcastingLive && broadcastSlot === 'host'
                          ? (currentUser?.name || currentMatch.host.name)
                          : currentMatch.host.name}
                      </span>
                      {currentMatch.host.verified && <VerifiedBadge />}
                    </div>
                    <span className="text-[9px] text-rose-300 font-extrabold flex items-center gap-1">
                      <Flame className="w-2.5 h-2.5 fill-rose-300" />
                      {isBroadcastingLive && broadcastSlot === 'host' ? '🔴 YOU ARE LIVE AS HOST' : 'Red Team'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  {isBroadcastingLive && broadcastSlot === 'host' && (
                    <span className="px-2 py-0.5 rounded-full bg-red-600 text-white font-black text-[9px] flex items-center gap-1 shadow animate-pulse">
                      <Radio className="w-3 h-3" />
                      LIVE
                    </span>
                  )}
                  <button
                    onClick={() => setIsHostMuted(!isHostMuted)}
                    className="p-2 rounded-xl bg-black/60 text-white hover:bg-black/80 transition"
                    title={isHostMuted ? 'Unmute Host' : 'Mute Host'}
                  >
                    {isHostMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Bottom Quick Boost button for Red */}
              <div className="absolute bottom-3 left-3 z-10">
                <button
                  onClick={() => {
                    setSelectedTeam('red');
                    handleSendGift(GIFTS_CATALOG[0]);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-rose-600/90 hover:bg-rose-600 text-white font-extrabold text-[11px] shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                >
                  <span>🌹 Tap Boost Red (10)</span>
                </button>
              </div>
            </div>

            {/* RIGHT STREAM: BLUE TEAM (Challenger) */}
            <div className="relative h-full bg-slate-900 overflow-hidden group">
              {isBroadcastingLive && broadcastSlot === 'opponent' ? (
                isCameraVideoEnabled ? (
                  <video
                    ref={(el) => {
                      opponentVideoRef.current = el;
                      if (el) {
                        el.defaultMuted = true;
                        el.muted = true;
                        el.playsInline = true;
                        if (cameraStream && el.srcObject !== cameraStream) {
                          el.srcObject = cameraStream;
                        }
                        el.play().catch(e => console.warn('Opponent cam play error:', e));
                      }
                    }}
                    autoPlay
                    playsInline
                    muted={true}
                    style={{ filter: getCameraFilterStyle() }}
                    className="w-full h-full object-cover transform scale-x-[-1]"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-b from-slate-900 via-cyan-950/40 to-slate-900 text-white p-4">
                    <div className="w-16 h-16 rounded-full bg-cyan-600/30 border-2 border-cyan-500 flex items-center justify-center mb-2 animate-pulse">
                      <CameraOff className="w-8 h-8 text-cyan-400" />
                    </div>
                    <p className="text-xs font-black uppercase text-cyan-300">Camera Video Muted</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">Streaming Audio Only to Subscribers</p>
                    <button
                      onClick={toggleCameraVideo}
                      className="mt-3 px-3 py-1 rounded-xl bg-cyan-600 text-white text-xs font-bold"
                    >
                      Turn On Camera Video
                    </button>
                  </div>
                )
              ) : (
                <video
                  ref={opponentVideoRef}
                  src={currentMatch.opponent.videoUrl}
                  autoPlay
                  playsInline
                  loop
                  muted={isOpponentMuted}
                  className="w-full h-full object-cover"
                />
              )}

              {/* Blue Overlay Header */}
              <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10">
                <div
                  onClick={() => {
                    setActiveProfileUsername(currentMatch.opponent.username);
                    setActiveView('profile');
                  }}
                  className="flex items-center gap-2 bg-black/60 backdrop-blur-md px-2.5 py-1.5 rounded-2xl cursor-pointer border border-cyan-500/40 hover:bg-black/80 transition"
                >
                  <img
                    src={currentMatch.opponent.avatar}
                    alt={currentMatch.opponent.name}
                    className="w-7 h-7 rounded-full object-cover border border-cyan-400"
                  />
                  <div>
                    <div className="flex items-center gap-1">
                      <span className="text-xs font-bold text-white">
                        {isBroadcastingLive && broadcastSlot === 'opponent'
                          ? (currentUser?.name || currentMatch.opponent.name)
                          : currentMatch.opponent.name}
                      </span>
                      {currentMatch.opponent.verified && <VerifiedBadge />}
                    </div>
                    <span className="text-[9px] text-cyan-300 font-extrabold flex items-center gap-1">
                      <Zap className="w-2.5 h-2.5 fill-cyan-300" />
                      {isBroadcastingLive && broadcastSlot === 'opponent' ? '🔴 YOU ARE LIVE AS CHALLENGER' : 'Blue Team'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  {isBroadcastingLive && broadcastSlot === 'opponent' && (
                    <span className="px-2 py-0.5 rounded-full bg-cyan-600 text-white font-black text-[9px] flex items-center gap-1 shadow animate-pulse">
                      <Radio className="w-3 h-3" />
                      LIVE
                    </span>
                  )}
                  <button
                    onClick={() => setIsOpponentMuted(!isOpponentMuted)}
                    className="p-2 rounded-xl bg-black/60 text-white hover:bg-black/80 transition"
                    title={isOpponentMuted ? 'Unmute Challenger' : 'Mute Challenger'}
                  >
                    {isOpponentMuted ? <VolumeX className="w-4 h-4 text-cyan-400" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Bottom Quick Boost button for Blue */}
              <div className="absolute bottom-3 right-3 z-10">
                <button
                  onClick={() => {
                    setSelectedTeam('blue');
                    handleSendGift(GIFTS_CATALOG[0]);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-cyan-600/90 hover:bg-cyan-600 text-white font-extrabold text-[11px] shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                >
                  <span>☕ Tap Boost Blue (50)</span>
                </button>
              </div>
            </div>
          </div>

          {/* ACTIVE LUCKY SUBSCRIBER MYSTERY DROP BANNER */}
          {currentMatch.activeDrop && (
            <div className="clay-card p-4 bg-gradient-to-r from-amber-500/25 via-orange-500/20 to-amber-500/25 border-2 border-amber-400/60 rounded-3xl flex items-center justify-between gap-4 animate-in fade-in">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center text-2xl shadow-lg shadow-amber-400/40 animate-bounce">
                  🎁
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black uppercase">
                      Subscribers Winnings Drop
                    </span>
                    <span className="text-[11px] text-amber-700 dark:text-amber-300 font-bold">
                      {currentMatch.activeDrop.remainingClaims} claims left!
                    </span>
                  </div>
                  <h4 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 mt-0.5">
                    {currentMatch.activeDrop.title} (+{currentMatch.activeDrop.prizeCoins} Coins)
                  </h4>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300">
                    All active room subscribers can claim free gift coins directly to their wallet!
                  </p>
                </div>
              </div>

              <button
                onClick={handleClaimDrop}
                disabled={isClaimingDrop}
                className="clay-btn bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-black px-5 py-2.5 rounded-2xl text-xs gap-1.5 shadow-xl shadow-amber-500/30 flex-shrink-0"
              >
                <Gift className="w-4 h-4" />
                {isClaimingDrop ? 'Claiming...' : `Claim +${currentMatch.activeDrop.prizeCoins} Coins!`}
              </button>
            </div>
          )}

          {/* GIFTING CONTROL TRAY */}
          <div className="clay-card p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-3">
            {/* Target Team & Multiplier bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-slate-600 dark:text-slate-400">Choose Side to Boost:</span>
                <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800">
                  <button
                    onClick={() => setSelectedTeam('red')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 ${
                      selectedTeam === 'red'
                        ? 'bg-rose-500 text-white shadow-md shadow-rose-500/30'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full bg-rose-400" />
                    Team Red ({currentMatch.host.name.split(' ')[0]})
                  </button>
                  <button
                    onClick={() => setSelectedTeam('blue')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 ${
                      selectedTeam === 'blue'
                        ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/30'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full bg-cyan-400" />
                    Team Blue ({currentMatch.opponent.name.split(' ')[0]})
                  </button>
                </div>
              </div>

              {/* Multiplier status badge */}
              <div className="flex items-center gap-2">
                {isUserSubscriber ? (
                  <span className="px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-xs font-black flex items-center gap-1 border border-emerald-400/40">
                    <Zap className="w-3.5 h-3.5 fill-emerald-500" />
                    2x Subscriber Power Active
                  </span>
                ) : (
                  <button
                    onClick={() => {
                      if (!currentUser) setAuthModalOpen(true);
                      else showToast('Subscribe to channel to unlock 2x multiplier and jackpot winnings!', 'info');
                    }}
                    className="px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 text-xs font-black flex items-center gap-1 border border-amber-400/40 hover:bg-amber-200"
                  >
                    <Crown className="w-3.5 h-3.5 text-amber-500" />
                    Unlock 2x Subscriber Multiplier
                  </button>
                )}
              </div>
            </div>

            {/* Gift Items Grid */}
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2.5">
              {GIFTS_CATALOG.map(gift => {
                const isSelected = selectedGift.id === gift.id;
                return (
                  <button
                    key={gift.id}
                    onClick={() => {
                      setSelectedGift(gift);
                      handleSendGift(gift);
                    }}
                    className={`p-2.5 rounded-2xl flex flex-col items-center justify-between border-2 transition group relative ${
                      isSelected
                        ? 'border-violet-600 bg-violet-50 dark:bg-violet-950/40 shadow-md'
                        : 'border-slate-200 dark:border-slate-800 hover:border-violet-300 dark:hover:border-slate-700 bg-slate-50/60 dark:bg-slate-800/40'
                    }`}
                  >
                    {gift.exclusiveSubscriber && (
                      <span className="absolute -top-2 -right-1 px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 text-[9px] font-black uppercase">
                        VIP
                      </span>
                    )}

                    <span className="text-2xl group-hover:scale-125 transition-transform mb-1">
                      {gift.icon}
                    </span>
                    <span className="text-[11px] font-bold text-slate-900 dark:text-slate-100 truncate w-full text-center">
                      {gift.name}
                    </span>
                    <span className="text-[10px] text-amber-600 dark:text-amber-400 font-extrabold flex items-center gap-0.5 mt-0.5">
                      <Coins className="w-2.5 h-2.5" />
                      {gift.coins}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Live Chat, Gifts Feed & Leaderboard */}
        <div className="space-y-4">
          <div className="clay-card bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-4 flex flex-col h-[680px]">
            {/* Segmented Switcher */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl mb-3">
              <button
                onClick={() => setActiveTab('chat')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-extrabold transition ${
                  activeTab === 'chat'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-200'
                }`}
              >
                Live Chat
              </button>
              <button
                onClick={() => setActiveTab('gifts')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-extrabold transition ${
                  activeTab === 'gifts'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-200'
                }`}
              >
                Gifts Stream
              </button>
              <button
                onClick={() => setActiveTab('leaderboard')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-extrabold transition ${
                  activeTab === 'leaderboard'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-200'
                }`}
              >
                Top Donors
              </button>
            </div>

            {/* TAB 1: LIVE CHAT */}
            {activeTab === 'chat' && (
              <div className="flex-1 flex flex-col justify-between overflow-hidden">
                <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
                  {currentMatch.chatMessages.map(msg => (
                    <div key={msg.id} className="flex items-start gap-2 text-xs">
                      <img
                        src={msg.userAvatar}
                        alt={msg.userName}
                        className="w-6 h-6 rounded-full object-cover flex-shrink-0 mt-0.5"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-extrabold text-slate-800 dark:text-slate-200">
                            {msg.userName}
                          </span>
                          {msg.isSubscriber && (
                            <span className="px-1.5 py-0.2 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-[9px]">
                              {msg.subscriberTier || 'Subscriber'}
                            </span>
                          )}
                        </div>
                        <p className="text-slate-700 dark:text-slate-300 break-words mt-0.5 leading-snug">
                          {msg.text}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div ref={chatBottomRef} />
                </div>

                {/* Chat Form */}
                <form onSubmit={handleSendChat} className="pt-3 border-t border-slate-100 dark:border-slate-800 flex gap-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={e => setChatInput(e.target.value)}
                    placeholder={currentUser ? 'Cheer your team or discuss...' : 'Sign in to participate'}
                    className="flex-1 px-3 py-2 text-xs clay-input"
                    maxLength={150}
                  />
                  <button
                    type="submit"
                    disabled={!chatInput.trim()}
                    className="clay-btn clay-btn-primary px-3.5 py-2 text-xs font-bold gap-1 disabled:opacity-40"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              </div>
            )}

            {/* TAB 2: GIFTS FEED */}
            {activeTab === 'gifts' && (
              <div className="flex-1 overflow-y-auto space-y-2 pr-1">
                {currentMatch.recentGifts?.length === 0 ? (
                  <p className="text-center text-xs text-slate-400 py-10">No gifts sent yet. Be the first to boost!</p>
                ) : (
                  currentMatch.recentGifts?.map(gift => (
                    <div
                      key={gift.id}
                      className={`p-2.5 rounded-2xl flex items-center justify-between text-xs border ${
                        gift.targetTeam === 'red'
                          ? 'bg-rose-50/60 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900'
                          : 'bg-cyan-50/60 dark:bg-cyan-950/30 border-cyan-200 dark:border-cyan-900'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="text-xl">{gift.giftIcon}</span>
                        <div className="min-w-0">
                          <p className="font-extrabold text-slate-900 dark:text-slate-100 truncate">
                            {gift.userName}
                          </p>
                          <p className="text-[10px] text-slate-500 dark:text-slate-400">
                            sent {gift.giftName} to{' '}
                            <span className={gift.targetTeam === 'red' ? 'text-rose-600 font-bold' : 'text-cyan-600 font-bold'}>
                              {gift.targetTeam === 'red' ? 'Team Red' : 'Team Blue'}
                            </span>
                          </p>
                        </div>
                      </div>

                      <div className="text-right">
                        <p className="font-black text-amber-500 text-xs">+{gift.points.toLocaleString()} pts</p>
                        {gift.multiplier > 1 && (
                          <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.5 rounded">
                            {gift.multiplier}x boost
                          </span>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* TAB 3: LEADERBOARD */}
            {activeTab === 'leaderboard' && (
              <div className="flex-1 overflow-y-auto space-y-2 pr-1">
                <p className="text-[11px] text-slate-400 font-semibold mb-2">
                  Top gifters contribute to winning team and unlock larger share of the prize pool:
                </p>
                {currentMatch.topDonors?.map((donor, idx) => (
                  <div
                    key={donor.userId}
                    className="p-2.5 rounded-2xl clay-card bg-white/80 dark:bg-slate-800 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className={`w-5 h-5 rounded-full flex items-center justify-center font-black text-[10px] ${
                        idx === 0 ? 'bg-amber-400 text-slate-900' : idx === 1 ? 'bg-slate-300 text-slate-800' : 'bg-amber-700 text-white'
                      }`}>
                        {idx + 1}
                      </span>
                      <img
                        src={donor.userAvatar}
                        alt={donor.userName}
                        className="w-7 h-7 rounded-full object-cover"
                      />
                      <div className="min-w-0">
                        <p className="font-extrabold text-slate-900 dark:text-slate-100 truncate">
                          {donor.userName}
                        </p>
                        <span className={`text-[10px] font-bold ${donor.targetTeam === 'red' ? 'text-rose-500' : 'text-cyan-500'}`}>
                          {donor.targetTeam === 'red' ? 'Team Red' : 'Team Blue'}
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="font-black text-amber-500">{donor.totalPoints.toLocaleString()} pts</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* WINNINGS POOL DETAILS MODAL */}
      {winningsModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
          <div className="clay-card bg-white dark:bg-slate-900 max-w-md w-full p-6 space-y-4 shadow-2xl relative border border-amber-400/50">
            <button
              onClick={() => setWinningsModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center text-2xl shadow-xl shadow-amber-400/40">
                💰
              </div>
              <div>
                <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
                  Subscriber Gift Winnings Pool
                </h3>
                <p className="text-xs text-slate-500">
                  How subscribers earn winnings in this live battle room
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 dark:text-slate-400 font-bold">Total Room Jackpot:</span>
                <span className="font-black text-amber-600 dark:text-amber-400 text-base">
                  {currentMatch.winningsPool.toLocaleString()} Coins
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 dark:text-slate-400 font-bold">Your Claimed Winnings:</span>
                <span className="font-black text-emerald-600 text-base">
                  +{claimedWinningsTotal} Coins
                </span>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
              <h4 className="font-extrabold text-slate-900 dark:text-slate-100">Ways to Earn:</h4>
              <ul className="space-y-1.5 list-disc list-inside">
                <li><strong className="text-emerald-500">Lucky Mystery Drops:</strong> When big gifts are sent, subscribers can claim instant 250-500 coin drops.</li>
                <li><strong className="text-amber-500">Winning Team Share:</strong> When the timer expires, subscribers who supported the winning team divide 70% of the jackpot.</li>
                <li><strong className="text-violet-500">Subscriber 2x Multiplier:</strong> Every coin sent as a subscriber counts double for your team's score.</li>
              </ul>
            </div>

            <button
              onClick={() => {
                setWinningsModalOpen(false);
                handleClaimDrop();
              }}
              className="clay-btn clay-btn-primary w-full py-2.5 text-xs font-bold gap-1.5"
            >
              <Gift className="w-4 h-4" />
              Check for Active Gift Drops
            </button>
          </div>
        </div>
      )}

      {/* CREATE LIVE MATCH ROOM MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
          <div className="clay-card bg-white dark:bg-slate-900 max-w-md w-full p-6 space-y-4 shadow-2xl relative border border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setIsCreateModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/20 text-rose-500 flex items-center justify-center">
                <Flame className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                  Start Live Match Room
                </h3>
                <p className="text-xs text-slate-500">
                  Launch a subscriber PK battle with gift winnings
                </p>
              </div>
            </div>

            <form onSubmit={handleCreateMatch} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Match Title
                </label>
                <input
                  type="text"
                  value={newMatchTitle}
                  onChange={e => setNewMatchTitle(e.target.value)}
                  placeholder="e.g. 50,000 Coin Engineering Face-off"
                  className="w-full px-3 py-2 text-xs clay-input"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Challenger / Opponent Name
                </label>
                <input
                  type="text"
                  value={newMatchOpponent}
                  onChange={e => setNewMatchOpponent(e.target.value)}
                  placeholder="e.g. Façade Academy or Tech Explorer"
                  className="w-full px-3 py-2 text-xs clay-input"
                  required
                />
              </div>

              <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/30 text-xs text-amber-800 dark:text-amber-300 space-y-1">
                <p className="font-bold flex items-center gap-1">
                  <Coins className="w-3.5 h-3.5" /> Initial Prize Pool: 5,000 Coins
                </p>
                <p className="text-[11px] opacity-80">
                  A welcome mystery drop will automatically be placed in the room for your channel subscribers.
                </p>
              </div>

              {/* Camera Broadcast Option */}
              <label className="flex items-center gap-3 cursor-pointer p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 hover:border-rose-400 transition">
                <input
                  type="checkbox"
                  checked={enableCameraOnCreate}
                  onChange={e => setEnableCameraOnCreate(e.target.checked)}
                  className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500"
                />
                <div className="flex-1">
                  <span className="text-xs font-black text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <Camera className="w-3.5 h-3.5 text-rose-500" />
                    Go Live with Camera as Host
                  </span>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                    Accesses webcam and microphone to stream your live video when the match starts
                  </p>
                </div>
              </label>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="clay-btn clay-btn-secondary px-3 py-1.5 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="clay-btn clay-btn-primary px-4 py-1.5 text-xs font-bold gap-1"
                >
                  <Flame className="w-3.5 h-3.5" />
                  Launch Room
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CAMERA DIAGNOSTICS & TROUBLESHOOTING MODAL */}
      {cameraDiagnosticsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="clay-card bg-white dark:bg-slate-900 max-w-lg w-full p-6 space-y-5 shadow-2xl relative border border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setCameraDiagnosticsOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-indigo-500/20 text-indigo-500 flex items-center justify-center">
                <Camera className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                  Camera & Microphone Diagnostics
                </h3>
                <p className="text-xs text-slate-500">
                  Hardware detection and browser permission guide
                </p>
              </div>
            </div>

            {/* Hardware Status Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-1">
                <span className="text-[10px] uppercase font-black text-slate-400">Video Devices</span>
                <p className="text-sm font-black text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${cameraDeviceList.video.length > 0 ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                  {cameraDeviceList.video.length} Connected
                </p>
                <p className="text-[10px] text-slate-500">
                  {cameraDeviceList.video[0]?.label || (cameraDeviceList.video.length > 0 ? 'Webcam ready' : 'Check USB/webcam connection')}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-1">
                <span className="text-[10px] uppercase font-black text-slate-400">Audio Devices</span>
                <p className="text-sm font-black text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${cameraDeviceList.audio.length > 0 ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                  {cameraDeviceList.audio.length} Connected
                </p>
                <p className="text-[10px] text-slate-500">
                  {cameraDeviceList.audio[0]?.label || (cameraDeviceList.audio.length > 0 ? 'Mic ready' : 'Check microphone input')}
                </p>
              </div>
            </div>

            {/* Error or block notice */}
            {cameraErrorMessage && (
              <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 text-xs text-rose-800 dark:text-rose-200 space-y-1">
                <span className="font-extrabold flex items-center gap-1.5">
                  <CameraOff className="w-4 h-4 text-rose-500" />
                  Hardware Warning:
                </span>
                <p className="text-[11px] opacity-90">{cameraErrorMessage}</p>
              </div>
            )}

            {/* Troubleshooting Steps */}
            <div className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
              <h4 className="font-black text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                How to Enable Camera & Microphone:
              </h4>
              <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-600 dark:text-slate-400 pl-1">
                <li>Look for the <strong>Camera / Lock icon</strong> in your browser's address bar.</li>
                <li>Ensure <strong>Camera</strong> and <strong>Microphone</strong> permissions are set to <strong>Allow</strong>.</li>
                <li>If browsing inside an embedded frame, open the match room in a direct standalone tab below.</li>
              </ol>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-2">
              <button
                onClick={() => {
                  window.open(window.location.origin, '_blank');
                  showToast('Opened platform in direct standalone window!');
                }}
                className="w-full py-2.5 px-4 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/20 active:scale-95 transition"
              >
                <span>Launch in Standalone Window (Bypasses Frame Blocks)</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex gap-2">
                <button
                  onClick={async () => {
                    await checkCameraDevices();
                    await startCameraBroadcast();
                    setCameraDiagnosticsOpen(false);
                  }}
                  className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition flex items-center justify-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Retry Camera Access</span>
                </button>
                <button
                  onClick={() => setCameraDiagnosticsOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold hover:bg-slate-200 transition"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
