import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { MembershipPlan, Video } from '../../types/index.ts';
import {
  Sparkles,
  CheckCircle2,
  Zap,
  Shield,
  Briefcase,
  Users,
  Check,
  CreditCard,
  ArrowRight,
  Flame
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const SubscriptionsView: React.FC = () => {
  const { currentUser, setCurrentUser, showToast, refreshUserData, setActiveVideo, setActiveView } = useApp();
  const [plans, setPlans] = useState<MembershipPlan[]>([]);
  const [followedVideos, setFollowedVideos] = useState<Video[]>([]);
  const [subscribingTier, setSubscribingTier] = useState<string | null>(null);

  useEffect(() => {
    fetchPlans();
    fetchFollowedVideos();
  }, []);

  const fetchPlans = async () => {
    try {
      const res = await fetch('/api/subscriptions/plans');
      if (res.ok) {
        const data = await res.json();
        setPlans(data.plans);
      }
    } catch (e) {
      console.warn('Could not load plans', e);
    }
  };

  const fetchFollowedVideos = async () => {
    try {
      const res = await fetch('/api/videos');
      if (res.ok) {
        const data = await res.json();
        setFollowedVideos(data.videos.slice(0, 6));
      }
    } catch (e) {
      console.warn('Could not load videos', e);
    }
  };

  const handleSubscribe = async (tier: string) => {
    setSubscribingTier(tier);
    try {
      const res = await fetch('/api/subscriptions/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tier })
      });
      if (res.ok) {
        const data = await res.json();
        if (currentUser) {
          setCurrentUser({ ...currentUser, membershipPlan: tier as any });
        }
        confetti({ particleCount: 75, spread: 70 });
        showToast(data.message || 'Membership upgraded successfully!');
        refreshUserData();
      }
    } catch (e) {
      showToast('Error upgrading plan', 'error');
    } finally {
      setSubscribingTier(null);
    }
  };

  return (
    <div className="space-y-10 pb-16">
      {/* Header */}
      <div className="clay-card p-6 bg-gradient-to-r from-violet-500/10 via-purple-500/10 to-amber-500/10 border border-violet-300/40 dark:border-violet-700/40">
        <div className="flex items-center gap-2 text-violet-600 dark:text-violet-400 font-extrabold text-xs uppercase tracking-wider">
          <Sparkles className="w-4 h-4" />
          Subscriptions & Creator Memberships
        </div>
        <h1 className="text-2xl md:text-3xl font-black text-slate-900 dark:text-slate-100 tracking-tight mt-1">
          Elevate Your Video & Recruitment Power
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl">
          Choose a tailored membership tier for advanced audience analytics, 4K uploads, verified checkmark eligibility, or enterprise applicant tracking.
        </p>

        {/* Demo Mode Notice Banner */}
        <div className="mt-4 p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 flex items-center justify-between text-xs text-amber-800 dark:text-amber-300">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-500 flex-shrink-0" />
            <span>
              <strong>Demo Payment Mode Active:</strong> Clicking "Upgrade" immediately activates all perks with zero real credit card charge.
            </span>
          </div>
          <span className="font-extrabold uppercase text-[10px] px-2 py-0.5 rounded bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-200">
            Simulated
          </span>
        </div>
      </div>

      {/* Pricing Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {plans.map((plan) => {
          const isCurrent = currentUser?.membershipPlan === plan.id;
          const isProcessing = subscribingTier === plan.id;

          return (
            <div
              key={plan.id}
              className={`clay-card p-5 bg-white dark:bg-[#181D2E] flex flex-col justify-between relative transition-all ${
                plan.recommended
                  ? 'border-2 border-violet-500 ring-2 ring-violet-500/20 shadow-xl'
                  : 'border border-slate-200/80 dark:border-slate-800'
              }`}
            >
              {plan.recommended && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-gradient-to-r from-violet-600 to-pink-500 text-white font-black text-[10px] uppercase shadow-md">
                  Most Popular
                </span>
              )}

              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                    {plan.name}
                  </h3>
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase ${plan.badgeColor}`}>
                    {plan.badge}
                  </span>
                </div>

                <div className="mb-3">
                  <span className="text-2xl font-black text-slate-900 dark:text-slate-100">
                    ${plan.priceMonthly}
                  </span>
                  <span className="text-xs text-slate-400 font-bold"> / month</span>
                </div>

                <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 leading-relaxed">
                  {plan.tagline}
                </p>

                <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  {plan.perks.map((perk, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-300">
                      <Check className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0 mt-0.5" />
                      <span className="leading-snug">{perk}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={() => handleSubscribe(plan.id)}
                  disabled={isCurrent || isProcessing}
                  className={`w-full py-2.5 rounded-xl text-xs font-bold transition active:scale-95 ${
                    isCurrent
                      ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-300 cursor-default'
                      : plan.recommended
                      ? 'clay-btn clay-btn-primary'
                      : 'clay-btn clay-btn-secondary'
                  }`}
                >
                  {isCurrent ? 'Current Active Plan' : isProcessing ? 'Processing...' : `Upgrade to ${plan.name}`}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Latest Content from Followed Creators */}
      <div className="space-y-4 pt-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-violet-600 dark:text-violet-400" />
            <h2 className="text-lg font-black text-slate-900 dark:text-slate-100">
              Latest Uploads from Followed Creators
            </h2>
          </div>
          <span className="text-xs text-slate-400">Channels you subscribe to</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {followedVideos.map((video) => (
            <div
              key={video.id}
              onClick={() => {
                setActiveVideo(video);
                setActiveView('watch');
              }}
              className="clay-card p-3 flex gap-3 cursor-pointer group hover:border-violet-400 transition"
            >
              <div className="relative w-36 aspect-video rounded-xl overflow-hidden bg-slate-900 flex-shrink-0">
                <img
                  src={video.thumbnailUrl}
                  alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-black/80 text-white">
                  {video.duration}
                </span>
              </div>
              <div className="flex-1 min-w-0 flex flex-col justify-between">
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 line-clamp-2 leading-tight group-hover:text-violet-600 transition-colors">
                  {video.title}
                </h4>
                <div className="text-[10px] text-slate-400 mt-1">
                  <p className="truncate font-semibold text-slate-600 dark:text-slate-300">{video.creator.name}</p>
                  <p>{video.views.toLocaleString()} views • {video.category}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
