import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { useSearchHistory } from '../../hooks/useSearchHistory.ts';
import {
  Search,
  PlusCircle,
  Bell,
  MessageSquare,
  Moon,
  Sun,
  ShieldAlert,
  Briefcase,
  Video as VideoIcon,
  User as UserIcon,
  ChevronDown,
  LogOut,
  Sparkles,
  Users,
  ShoppingBag,
  Clock,
  X,
  ArrowUpRight,
  UserPlus
} from 'lucide-react';
import { GoogleAuthButton } from '../common/GoogleAuthButton.tsx';

export const TopBar: React.FC<{ onToggleSidebar: () => void; sidebarOpen: boolean }> = ({ onToggleSidebar, sidebarOpen }) => {
  const {
    currentUser,
    activeView,
    setActiveView,
    searchQuery,
    setSearchQuery,
    unreadCount,
    setAuthModalOpen,
    openAuthModal,
    logout,
    setSettingsModalOpen,
    isDarkMode,
    toggleDarkMode,
    switchDemoUser,
    showToast,
    navigateToUpload,
    cartCount
  } = useApp();

  const { history, addQuery, removeQuery, clearHistory } = useSearchHistory();
  const [showHistory, setShowHistory] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [demoSwitchOpen, setDemoSwitchOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      addQuery(searchQuery);
    }
    setShowHistory(false);
    setMobileSearchOpen(false);
    if (activeView !== 'home' && activeView !== 'jobs' && activeView !== 'explore') {
      setActiveView('home');
    }
  };

  const demoAccounts = [
    { id: 'u-candidate1', name: 'Tariq Mansoor', role: 'Candidate / Engineer', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100&h=100&fit=crop' },
    { id: 'u-facade', name: 'Façade Academy', role: 'Top Creator Channel', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop' },
    { id: 'u-recruiter1', name: 'Apex Façade Talent', role: 'Recruiter & Employer', avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&h=100&fit=crop' },
    { id: 'u-admin', name: 'Shafi Afzal Shah', role: 'Super Admin', avatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg' }
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/80 dark:bg-[#131722]/85 backdrop-blur-md border-b border-slate-200/60 dark:border-slate-800/80 px-4 lg:px-6 py-2.5 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Left: Hamburger + Brand */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSidebar}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition active:scale-95"
            aria-label="Toggle Navigation Sidebar"
          >
            <div className="w-5 h-4 flex flex-col justify-between">
              <span className={`h-0.5 w-full bg-current rounded-full transition-all ${sidebarOpen ? 'rotate-45 translate-y-1.5' : ''}`} />
              <span className={`h-0.5 w-full bg-current rounded-full transition-all ${sidebarOpen ? 'opacity-0' : ''}`} />
              <span className={`h-0.5 w-full bg-current rounded-full transition-all ${sidebarOpen ? '-rotate-45 -translate-y-1.5' : ''}`} />
            </div>
          </button>

          <button
            onClick={() => {
              setSearchQuery('');
              setActiveView('home');
            }}
            className="flex items-center gap-2 group text-left"
          >
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-violet-600 via-purple-500 to-pink-500 flex items-center justify-center text-white shadow-md shadow-purple-500/30 group-hover:scale-105 transition-transform">
              <VideoIcon className="w-5 h-5 fill-white/20" />
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold text-base md:text-lg tracking-tight bg-gradient-to-r from-violet-600 via-indigo-600 to-pink-600 bg-clip-text text-transparent">
                VideoHub
              </span>
              <span className="text-[10px] -mt-1 font-bold text-emerald-600 dark:text-emerald-400 tracking-wider uppercase">
                + Global Jobs
              </span>
            </div>
          </button>
        </div>

        {/* Center: Global Search Bar */}
        <div className="hidden md:flex flex-1 max-w-xl mx-4 relative">
          <form onSubmit={handleSearchSubmit} className="w-full">
            <div className="relative w-full flex items-center">
              <Search className="absolute left-3.5 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setShowHistory(true)}
                onBlur={() => setTimeout(() => setShowHistory(false), 250)}
                placeholder="Search videos, curtain wall tech, Revit BIM, jobs, companies..."
                className="w-full pl-10 pr-10 py-2 text-sm clay-input text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 rounded-2xl"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  ✕
                </button>
              )}
            </div>
          </form>

          {/* Recent Searches Dropdown (Last 5 Queries) */}
          {showHistory && history.length > 0 && (
            <div
              onMouseDown={(e) => e.preventDefault()}
              className="absolute top-full left-0 w-full mt-2 clay-card bg-white dark:bg-[#181D2E] border border-slate-200/80 dark:border-slate-800 shadow-2xl rounded-2xl p-2.5 z-50 animate-in fade-in zoom-in-95 duration-150"
            >
              <div className="flex justify-between items-center px-2 py-1.5 border-b border-slate-100 dark:border-slate-800/80 text-[10px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500">
                <span className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-violet-500" />
                  Recent Searches
                </span>
                <button
                  type="button"
                  onClick={clearHistory}
                  className="text-violet-600 dark:text-violet-400 hover:text-violet-700 dark:hover:text-violet-300 font-extrabold normal-case text-[11px] hover:underline"
                >
                  Clear All
                </button>
              </div>

              <div className="py-1 divide-y divide-slate-100/60 dark:divide-slate-800/60">
                {history.slice(0, 5).map((query, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between group hover:bg-slate-100/80 dark:hover:bg-slate-800/80 rounded-xl px-2.5 py-1.5 transition"
                  >
                    <button
                      type="button"
                      onClick={() => {
                        setSearchQuery(query);
                        addQuery(query);
                        setShowHistory(false);
                        if (activeView !== 'home' && activeView !== 'jobs' && activeView !== 'explore') {
                          setActiveView('home');
                        }
                      }}
                      className="flex-1 flex items-center gap-2.5 text-left text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-violet-600 dark:hover:text-violet-400 truncate"
                    >
                      <Clock className="w-3.5 h-3.5 text-slate-400 group-hover:text-violet-500 transition-colors flex-shrink-0" />
                      <span className="truncate">{query}</span>
                    </button>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSearchQuery(query);
                        }}
                        title="Fill search input"
                        className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-violet-600 transition rounded-lg"
                      >
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          removeQuery(query);
                        }}
                        title="Delete from recent searches"
                        className="p-1 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition rounded-lg"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>


        {/* Right: Actions & Profile */}
        <div className="flex items-center gap-2 md:gap-3">
          {/* Mobile Search Toggle Button */}
          <button
            onClick={() => setMobileSearchOpen(!mobileSearchOpen)}
            className="md:hidden p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition active:scale-95"
            aria-label="Toggle Search"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Quick Demo Persona Switcher */}
          <div className="relative">
            <button
              onClick={() => setDemoSwitchOpen(!demoSwitchOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-300 border border-violet-200/60 dark:border-violet-800/50 hover:bg-violet-100 dark:hover:bg-violet-900/50 transition active:scale-95"
              title="Switch demo persona for instant role preview"
            >
              <Users className="w-3.5 h-3.5 text-violet-600 dark:text-violet-400" />
              <span className="hidden xl:inline">Role:</span>
              <span className="font-bold truncate max-w-[85px]">
                {currentUser?.role === 'admin' ? 'Admin' : currentUser?.role === 'employer' ? 'Recruiter' : currentUser?.role === 'creator' ? 'Creator' : 'Candidate'}
              </span>
              <ChevronDown className="w-3 h-3 text-violet-500" />
            </button>

            {demoSwitchOpen && (
              <div className="absolute right-0 mt-2 w-64 clay-card p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-2 py-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                  Switch Active Demo Profile
                </div>
                {demoAccounts.map(acc => (
                  <button
                    key={acc.id}
                    onClick={() => {
                      switchDemoUser(acc.id);
                      setDemoSwitchOpen(false);
                    }}
                    className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left transition ${
                      currentUser?.id === acc.id
                        ? 'bg-violet-100 dark:bg-violet-900/40 text-violet-900 dark:text-violet-200'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <img src={acc.avatar} alt={acc.name} className="w-7 h-7 rounded-full object-cover shadow-sm" />
                    <div className="truncate flex-1">
                      <div className="text-xs font-bold truncate">{acc.name}</div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400">{acc.role}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Live Match Room Button */}
          <button
            onClick={() => setActiveView('live_match')}
            className={`px-3 py-1.5 rounded-2xl text-xs font-black gap-1.5 shadow-sm hover:shadow active:scale-95 transition flex items-center ${
              activeView === 'live_match'
                ? 'bg-rose-600 text-white shadow-rose-500/40'
                : 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-300 border border-rose-300 dark:border-rose-800'
            }`}
            title="Live Subscriber Match Arena (Win Gifts)"
          >
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping inline-block" />
            <span className="hidden sm:inline">Live Match</span>
            <span className="text-[10px] bg-rose-500 text-white px-1.5 py-0.2 rounded-full font-black uppercase">
              Win Gifts
            </span>
          </button>

          {/* Upload Button */}
          <button
            onClick={() => navigateToUpload(activeView === 'shorts' ? 'short' : 'long')}
            className="clay-btn clay-btn-coral px-3 py-1.5 text-xs font-bold gap-1.5 shadow-sm hover:shadow active:scale-95 transition"
          >
            <PlusCircle className="w-4 h-4" />
            <span className="hidden sm:inline">Upload</span>
          </button>

          {/* Dark / Light Toggle */}
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition active:scale-95"
            aria-label="Toggle Color Theme"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-500" />}
          </button>

          {/* Messages */}
          <button
            onClick={() => setActiveView('messages')}
            className={`relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition active:scale-95 ${
              activeView === 'messages' ? 'bg-violet-100 dark:bg-violet-900/30 text-violet-600' : ''
            }`}
            aria-label="Direct Messages"
          >
            <MessageSquare className="w-4 h-4" />
          </button>

          {/* Notifications Bell */}
          <button
            onClick={() => setActiveView('notifications')}
            className={`relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition active:scale-95 ${
              activeView === 'notifications' ? 'bg-violet-100 dark:bg-violet-900/30 text-violet-600' : ''
            }`}
            aria-label="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>

          {/* Online Store & Cart Button */}
          <button
            onClick={() => setActiveView('store')}
            className={`relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition active:scale-95 ${
              activeView === 'store' ? 'bg-amber-100 dark:bg-amber-950/40 text-amber-600' : ''
            }`}
            title="Online Store & Shopping Bag"
            aria-label="Online Store"
          >
            <ShoppingBag className="w-4 h-4" />
            {cartCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-amber-500 text-white text-[10px] font-black flex items-center justify-center shadow-sm">
                {cartCount > 9 ? '9+' : cartCount}
              </span>
            )}
          </button>

          {/* User Profile / Auth */}
          {currentUser ? (
            <div className="relative">
              <button
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center gap-1.5 p-1 rounded-2xl hover:ring-2 hover:ring-violet-400/40 transition active:scale-95"
              >
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-full object-cover border border-purple-200 dark:border-purple-800"
                />
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {userMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 clay-card p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800">
                    <p className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">{currentUser.name}</p>
                    <p className="text-[11px] text-slate-400 truncate">@{currentUser.username}</p>
                    <span className="inline-block mt-1 px-2 py-0.5 text-[10px] font-bold rounded-md bg-purple-100 text-purple-700 dark:bg-purple-900/50 dark:text-purple-300 uppercase">
                      {currentUser.role}
                    </span>
                  </div>

                  <div className="py-1">
                    <button
                      onClick={() => {
                        setActiveView('profile');
                        setUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60 rounded-xl"
                    >
                      <UserIcon className="w-4 h-4 text-violet-500" />
                      My Channel & Profile
                    </button>

                    <button
                      onClick={() => {
                        setActiveView('applications');
                        setUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60 rounded-xl"
                    >
                      <Briefcase className="w-4 h-4 text-emerald-500" />
                      {currentUser.role === 'employer' ? 'Candidate Applications' : 'My Job Applications'}
                    </button>

                    <button
                      onClick={() => {
                        setActiveView('subscriptions');
                        setUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60 rounded-xl"
                    >
                      <Sparkles className="w-4 h-4 text-amber-500" />
                      Membership Plans
                    </button>

                    {currentUser.role === 'admin' && (
                      <button
                        onClick={() => {
                          setActiveView('admin');
                          setUserMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl"
                      >
                        <ShieldAlert className="w-4 h-4" />
                        Admin Dashboard
                      </button>
                    )}
                  </div>

                  <div className="pt-1 border-t border-slate-100 dark:border-slate-800">
                    <button
                      onClick={() => {
                        setSettingsModalOpen(true);
                        setUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60 rounded-xl"
                    >
                      <span className="text-sm">⚙️</span>
                      Settings
                    </button>
                    <button
                      onClick={() => {
                        openAuthModal('login');
                        setUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-violet-600 dark:text-violet-400 hover:bg-violet-50 dark:hover:bg-violet-950/40 rounded-xl"
                    >
                      <UserIcon className="w-4 h-4" />
                      Switch Account / Login
                    </button>
                    <button
                      onClick={() => {
                        openAuthModal('register');
                        setUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-xl"
                    >
                      <UserPlus className="w-4 h-4" />
                      Registration (New Account)
                    </button>
                    <div className="pt-1 mt-1 border-t border-slate-100 dark:border-slate-800 space-y-1">
                      <GoogleAuthButton
                        variant="full"
                        label="Login with Google"
                        className="w-full py-1.5 text-[11px]"
                        onSuccess={() => setUserMenuOpen(false)}
                      />
                      <GoogleAuthButton
                        variant="gmail"
                        label="Login with Gmail"
                        className="w-full py-1.5 text-[11px]"
                        onSuccess={() => setUserMenuOpen(false)}
                      />
                    </div>
                    <div className="pt-1 mt-1 border-t border-slate-100 dark:border-slate-800">
                      <button
                        onClick={async () => {
                          setUserMenuOpen(false);
                          await logout();
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl"
                      >
                        <LogOut className="w-4 h-4" />
                        Log Out
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-1.5 sm:gap-2">
              <GoogleAuthButton
                variant="compact"
                label="Google"
                className="px-2.5 sm:px-3 py-1.5 text-xs font-bold shadow-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
              <GoogleAuthButton
                variant="gmail"
                label="Gmail"
                className="hidden md:flex px-2.5 py-1.5 text-xs font-bold shadow-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
              <button
                onClick={() => openAuthModal('login')}
                className="px-2.5 sm:px-3 py-1.5 text-xs font-bold text-slate-700 dark:text-slate-200 hover:text-violet-600 dark:hover:text-violet-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer"
              >
                Login
              </button>
              <button
                onClick={() => openAuthModal('register')}
                className="clay-btn clay-btn-primary px-3 sm:px-3.5 py-1.5 text-xs font-bold active:scale-95 shadow-md shadow-violet-500/20 cursor-pointer"
              >
                Registration
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Search Bar Dropdown & Recent Searches */}
      {mobileSearchOpen && (
        <div className="md:hidden pt-2.5 pb-1 px-1 border-t border-slate-100 dark:border-slate-800/80 animate-in slide-in-from-top-2 duration-150 relative">
          <form onSubmit={handleSearchSubmit} className="w-full">
            <div className="relative w-full flex items-center">
              <Search className="absolute left-3.5 w-4 h-4 text-slate-400 pointer-events-none" />
              <input
                type="text"
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search videos, jobs, tech..."
                className="w-full pl-10 pr-9 py-2 text-xs clay-input rounded-xl"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 text-xs text-slate-400"
                >
                  ✕
                </button>
              )}
            </div>
          </form>

          {history.length > 0 && (
            <div className="mt-2 clay-card bg-white dark:bg-[#181D2E] p-2 rounded-2xl shadow-xl border border-slate-200/80 dark:border-slate-800">
              <div className="flex justify-between items-center px-2 py-1 text-[10px] font-black uppercase tracking-wider text-slate-400">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-violet-500" />
                  Recent Searches (Last 5)
                </span>
                <button type="button" onClick={clearHistory} className="text-violet-600 hover:underline">
                  Clear
                </button>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {history.slice(0, 5).map((q, idx) => (
                  <div key={idx} className="flex items-center justify-between py-1.5 px-2">
                    <button
                      type="button"
                      onClick={() => {
                        setSearchQuery(q);
                        addQuery(q);
                        setMobileSearchOpen(false);
                        if (activeView !== 'home' && activeView !== 'jobs') setActiveView('home');
                      }}
                      className="flex-1 flex items-center gap-2 text-left text-xs font-semibold text-slate-700 dark:text-slate-200 truncate"
                    >
                      <Clock className="w-3 h-3 text-slate-400 flex-shrink-0" />
                      <span className="truncate">{q}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => removeQuery(q)}
                      className="p-1 text-slate-400 hover:text-rose-500"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
