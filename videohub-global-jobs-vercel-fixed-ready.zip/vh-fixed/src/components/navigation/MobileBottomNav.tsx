import React from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { Home, Flame, PlusCircle, Briefcase, User, Zap } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const { activeView, setActiveView, navigateToUpload } = useApp();

  const items = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'shorts', label: 'Shorts', icon: Flame },
    { id: 'live_match', label: 'Live PK', icon: Zap, isLive: true },
    { id: 'upload', label: 'Upload', icon: PlusCircle, isPrimary: true },
    { id: 'jobs', label: 'Jobs', icon: Briefcase },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  const handleNav = (id: string) => {
    if (id === 'upload') {
      navigateToUpload(activeView === 'shorts' ? 'short' : 'long');
    } else {
      setActiveView(id as any);
    }
  };

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#131722]/95 backdrop-blur-lg border-t border-slate-200/60 dark:border-slate-800/80 px-2 py-1.5 flex items-center justify-around shadow-lg">
      {items.map((item) => {
        const Icon = item.icon;
        const isActive = activeView === item.id;

        if (item.isPrimary) {
          return (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className="flex flex-col items-center justify-center -mt-5"
            >
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-pink-500 via-rose-500 to-amber-500 text-white flex items-center justify-center shadow-lg shadow-rose-500/30 active:scale-90 transition">
                <Icon className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-bold text-slate-600 dark:text-slate-300 mt-1">
                {item.label}
              </span>
            </button>
          );
        }

        return (
          <button
            key={item.id}
            onClick={() => setActiveView(item.id as any)}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition relative ${
              isActive
                ? 'text-violet-600 dark:text-violet-400 font-bold'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
            }`}
          >
            <div className="relative">
              <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
              {(item as any).isLive && (
                <span className="absolute -top-1 -right-1 flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500" />
                </span>
              )}
            </div>
            <span className="text-[10px] mt-0.5">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
