import crypto from 'crypto';
import { MongoClient } from 'mongodb';
import {
  SEED_USERS,
  SEED_VIDEOS,
  SEED_JOBS,
  SEED_APPLICATIONS,
  SEED_NOTIFICATIONS,
  SEED_COMMENTS,
  SEED_CONVERSATIONS,
  SEED_MESSAGES,
  SEED_REPORTS,
  SEED_AUDIT_LOGS,
  SEED_PLANS,
  SEED_STORE_PRODUCTS
} from './seed-data.js';

// Cached MongoDB Client for Serverless / Node runtime
let cachedClient = null;
let cachedDb = null;
let isMongoConnected = false;

// Fallback in-memory resilient storage if MongoDB_URI is not set or during local preview
export class MemoryStore {
  constructor() {
    // Never ship demo identities, seeded administrator accounts, fake messages or
    // sample financial balances into production. Production starts clean.
    const demo = process.env.NODE_ENV !== 'production';
    this.users = demo ? [...SEED_USERS] : [];
    this.videos = demo ? [...SEED_VIDEOS] : [];
    this.jobs = demo ? [...SEED_JOBS] : [];
    this.applications = demo ? [...SEED_APPLICATIONS] : [];
    this.notifications = demo ? [...SEED_NOTIFICATIONS] : [];
    this.comments = demo ? [...SEED_COMMENTS] : [];
    this.conversations = demo ? [...SEED_CONVERSATIONS] : [];
    this.messages = demo ? [...SEED_MESSAGES] : [];
    this.reports = demo ? [...SEED_REPORTS] : [];
    this.auditLogs = demo ? [...SEED_AUDIT_LOGS] : [];
    this.follows = demo ? [
      { followerId: 'u-candidate1', targetId: 'u-facade' },
      { followerId: 'u-candidate1', targetId: 'u-construction' },
      { followerId: 'u-candidate1', targetId: 'u-bim' }
    ] : [];
    this.savedJobs = demo ? [
      { userId: 'u-candidate1', jobId: 'job-1' },
      { userId: 'u-candidate1', jobId: 'job-3' }
    ] : [];
    this.likedVideos = demo ? [
      { userId: 'u-candidate1', videoId: 'v-1' },
      { userId: 'u-candidate1', videoId: 'v-short-1' }
    ] : [];
    this.reposts = demo ? [
      {
        id: 'rep-1',
        videoId: 'v-1',
        userId: 'u-admin',
        user: {
          name: 'Shafi Afzal Shah',
          username: 'shafi_shah',
          avatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg',
          verified: true,
          role: 'admin'
        },
        quoteText: 'Essential video for all façade engineering consultants and curtain wall fabrication engineers in KSA and the Gulf.',
        createdAt: new Date(Date.now() - 3600000 * 24).toISOString()
      },
      {
        id: 'rep-2',
        videoId: 'v-1',
        userId: 'u-tech',
        user: {
          name: 'Tech Explorer Lab',
          username: 'techexplorer',
          avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
          verified: true,
          role: 'creator'
        },
        quoteText: 'The structural pressure calculations and seismic anchor displacement analysis here are world class.',
        createdAt: new Date(Date.now() - 3600000 * 12).toISOString()
      },
      {
        id: 'rep-3',
        videoId: 'v-short-1',
        userId: 'u-admin',
        user: {
          name: 'Shafi Afzal Shah',
          username: 'shafi_shah',
          avatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg',
          verified: true,
          role: 'admin'
        },
        quoteText: 'Stainless steel point-fixing mechanics in action! Amazing deflection demonstration.',
        createdAt: new Date(Date.now() - 3600000 * 6).toISOString()
      }
    ] : [];

    this.liveMatches = demo ? [
      {
        id: 'match-1',
        title: '🔥 50,000 COIN SUBSCRIBER BATTLE: Shafi Shah vs Façade Academy',
        category: 'Engineering & Tech',
        status: 'speed_challenge',
        startedAt: new Date(Date.now() - 1000 * 180).toISOString(),
        endsAt: new Date(Date.now() + 1000 * 240).toISOString(),
        durationSeconds: 420,
        viewersCount: 1420,
        subscribersCount: 840,
        winningsPool: 38500,
        activeDrop: {
          id: 'drop-1',
          title: '🎁 500 COIN SUBSCRIBER MYSTERY DROP!',
          prizeCoins: 500,
          remainingClaims: 12,
          totalClaims: 20,
          expiresAt: new Date(Date.now() + 1000 * 180).toISOString(),
          claimedByUserIds: []
        },
        host: {
          id: 'u-admin',
          name: 'Shafi Afzal Shah',
          username: 'shafi_shah',
          avatar: '/assets/aistudio/Screenshot_20240115_120152_DWG_FastView_e3b92bfb.jpg',
          role: 'admin',
          verified: true,
          team: 'red',
          teamName: 'Red Titans (Shafi)',
          score: 19800,
          videoUrl: '/api/media/stream/video1.mp4',
          subscribersGiftingCount: 42
        },
        opponent: {
          id: 'u-facade',
          name: 'Façade Engineering Academy',
          username: 'facade_academy',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
          role: 'creator',
          verified: true,
          team: 'blue',
          teamName: 'Blue Force (Façade)',
          score: 18700,
          videoUrl: '/api/media/stream/short1.mp4',
          subscribersGiftingCount: 38
        },
        chatMessages: [
          {
            id: 'm-1',
            userId: 'u-tech',
            userName: 'Tech Explorer Lab',
            userAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
            isSubscriber: true,
            subscriberTier: 'Pro Sub',
            text: 'Drop the Turbo Rockets on Team Red! Double points active! 🚀🔥',
            createdAt: new Date(Date.now() - 45000).toISOString()
          },
          {
            id: 'm-2',
            userId: 'u-construction',
            userName: 'Global Construction Leaders',
            userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces',
            isSubscriber: true,
            subscriberTier: 'VIP Sub',
            text: 'Blue Team catching up fast! Everyone tap and boost! 🏆⚡',
            createdAt: new Date(Date.now() - 25000).toISOString()
          },
          {
            id: 'm-3',
            userId: 'u-bim',
            userName: 'BIM Innovations Global',
            userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces',
            isSubscriber: true,
            subscriberTier: 'Sub',
            text: 'I just won 250 coins from the mystery drop! Claim yours! 🎁🎉',
            createdAt: new Date(Date.now() - 10000).toISOString()
          }
        ],
        recentGifts: [
          {
            id: 'g-1',
            userId: 'u-tech',
            userName: 'Tech Explorer Lab',
            userAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
            giftId: 'rocket',
            giftName: 'Turbo Rocket',
            giftIcon: '🚀',
            giftCost: 500,
            points: 1000,
            multiplier: 2,
            targetTeam: 'red',
            createdAt: new Date(Date.now() - 40000).toISOString()
          },
          {
            id: 'g-2',
            userId: 'u-construction',
            userName: 'Global Construction Leaders',
            userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces',
            giftId: 'trophy',
            giftName: 'Victory Cup',
            giftIcon: '🏆',
            giftCost: 1200,
            points: 2400,
            multiplier: 2,
            targetTeam: 'blue',
            createdAt: new Date(Date.now() - 20000).toISOString()
          }
        ],
        topDonors: [
          {
            userId: 'u-tech',
            userName: 'Tech Explorer Lab',
            userAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
            targetTeam: 'red',
            totalPoints: 8500,
            isSubscriber: true
          },
          {
            userId: 'u-construction',
            userName: 'Global Construction Leaders',
            userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces',
            targetTeam: 'blue',
            totalPoints: 7200,
            isSubscriber: true
          },
          {
            userId: 'u-candidate1',
            userName: 'Ahmed Al-Shehri',
            userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop&crop=faces',
            targetTeam: 'red',
            totalPoints: 3400,
            isSubscriber: true
          }
        ]
      },
      {
        id: 'match-2',
        title: '⚡ ARCHITECTURE DERBY: BIM Global vs Modern Structures',
        category: 'Architecture',
        status: 'live',
        startedAt: new Date(Date.now() - 1000 * 60).toISOString(),
        endsAt: new Date(Date.now() + 1000 * 360).toISOString(),
        durationSeconds: 420,
        viewersCount: 890,
        subscribersCount: 410,
        winningsPool: 14800,
        activeDrop: {
          id: 'drop-2',
          title: '🎁 250 COIN SPEED CHALLENGE DROP!',
          prizeCoins: 250,
          remainingClaims: 8,
          totalClaims: 15,
          expiresAt: new Date(Date.now() + 1000 * 120).toISOString(),
          claimedByUserIds: []
        },
        host: {
          id: 'u-bim',
          name: 'BIM Innovations Global',
          username: 'bim_innovations',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces',
          role: 'creator',
          verified: true,
          team: 'red',
          teamName: 'Revit Masters',
          score: 8400,
          videoUrl: '/api/media/stream/video1.mp4',
          subscribersGiftingCount: 22
        },
        opponent: {
          id: 'u-tech',
          name: 'Tech Explorer Lab',
          username: 'techexplorer',
          avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&h=200&fit=crop&crop=faces',
          role: 'creator',
          verified: true,
          team: 'blue',
          teamName: 'Parametric Squad',
          score: 9100,
          videoUrl: '/api/media/stream/short1.mp4',
          subscribersGiftingCount: 26
        },
        chatMessages: [],
        recentGifts: [],
        topDonors: []
      }
    ] : [];

    this.storeProducts = demo ? [...SEED_STORE_PRODUCTS] : [];
    this.storeOrders = [];
    this.reactions = {};
  }
}

export const memoryStore = new MemoryStore();

// ----------------------------------------------------
// MongoDB persistence (write-behind snapshot sync)
//
// Every route reads/writes `memoryStore`. When MONGODB_URI is set, the store is
// loaded from MongoDB on startup and every change is saved back (per document,
// only what changed), so users, videos, jobs, etc. survive restarts/redeploys.
// ----------------------------------------------------
const ARRAY_COLLECTIONS = [
  'users', 'videos', 'jobs', 'applications', 'notifications', 'comments',
  'conversations', 'messages', 'reports', 'auditLogs', 'follows', 'savedJobs',
  'likedVideos', 'reposts', 'storeOrders'
];
// Plain objects (keyed maps) are stored one document per key in "kv_<name>"
const OBJECT_COLLECTIONS = ['reactions', 'creatorMonetization'];

// What we last wrote/loaded: "collection" -> Map(docKey -> json string)
const savedState = new Map();
let persistChain = Promise.resolve();
let initPromise = null;
let lastLoadAt = 0;

function docKey(doc) {
  if (doc && doc.id !== undefined && doc.id !== null) return String(doc.id);
  return crypto.createHash('sha1').update(JSON.stringify(doc)).digest('hex');
}

function stripId(doc) {
  if (!doc) return doc;
  const { _id, ...rest } = doc;
  return rest;
}

function snapshotEntries(name) {
  if (ARRAY_COLLECTIONS.includes(name)) {
    const list = Array.isArray(memoryStore[name]) ? memoryStore[name] : [];
    return list.map(doc => [docKey(doc), doc]);
  }
  const obj = memoryStore[name] && typeof memoryStore[name] === 'object' ? memoryStore[name] : {};
  return Object.entries(obj).map(([k, v]) => [k, { value: v }]);
}

function mongoCollectionName(name) {
  return OBJECT_COLLECTIONS.includes(name) ? 'kv_' + name : name;
}

async function loadFromMongo(db) {
  for (const name of [...ARRAY_COLLECTIONS, ...OBJECT_COLLECTIONS]) {
    const docs = await db.collection(mongoCollectionName(name)).find({}).toArray();
    const known = new Map();
    if (ARRAY_COLLECTIONS.includes(name)) {
      const list = docs.map(d => {
        const clean = stripId(d);
        known.set(String(d._id), JSON.stringify(clean));
        return clean;
      });
      memoryStore[name] = list;
    } else {
      const obj = {};
      for (const d of docs) {
        obj[String(d._id)] = d.value;
        known.set(String(d._id), JSON.stringify({ value: d.value }));
      }
      memoryStore[name] = obj;
    }
    savedState.set(name, known);
  }
  lastLoadAt = Date.now();
}

async function writeDiff(db) {
  for (const name of [...ARRAY_COLLECTIONS, ...OBJECT_COLLECTIONS]) {
    const previous = savedState.get(name) || new Map();
    const next = new Map();
    const ops = [];

    for (const [key, doc] of snapshotEntries(name)) {
      const json = JSON.stringify(doc);
      next.set(key, json);
      if (previous.get(key) !== json) {
        ops.push({ replaceOne: { filter: { _id: key }, replacement: stripId(JSON.parse(json)), upsert: true } });
      }
    }
    for (const key of previous.keys()) {
      if (!next.has(key)) ops.push({ deleteOne: { filter: { _id: key } } });
    }

    if (ops.length) {
      await db.collection(mongoCollectionName(name)).bulkWrite(ops, { ordered: false });
    }
    savedState.set(name, next);
  }
}

/** Save all changes made to memoryStore since the last save. Safe to call often. */
export function persistToMongo() {
  if (!cachedDb) return Promise.resolve();
  persistChain = persistChain
    .then(() => writeDiff(cachedDb))
    .catch(err => console.error('[Database] Persist failed:', err.message));
  return persistChain;
}

/** Reload from MongoDB (used on serverless, where each instance may be stale). */
export async function refreshFromMongo(maxAgeMs = 0) {
  if (!cachedDb) return;
  if (Date.now() - lastLoadAt < maxAgeMs) return;
  await persistChain;
  await loadFromMongo(cachedDb);
}

function purgeProductionDemoData() {
  if (process.env.NODE_ENV !== 'production') return;
  const ids = (items) => new Set((items || []).map(item => item.id).filter(Boolean));
  const demoUserIds = ids(SEED_USERS);
  const demoVideoIds = ids(SEED_VIDEOS);
  const demoJobIds = ids(SEED_JOBS);
  const demoApplicationIds = ids(SEED_APPLICATIONS);
  const demoNotificationIds = ids(SEED_NOTIFICATIONS);
  const demoCommentIds = ids(SEED_COMMENTS);
  const demoConversationIds = ids(SEED_CONVERSATIONS);
  const demoMessageIds = ids(SEED_MESSAGES);
  const demoReportIds = ids(SEED_REPORTS);
  const demoAuditIds = ids(SEED_AUDIT_LOGS);
  memoryStore.users = memoryStore.users.filter(x => !demoUserIds.has(x.id));
  memoryStore.videos = memoryStore.videos.filter(x => !demoVideoIds.has(x.id));
  memoryStore.jobs = memoryStore.jobs.filter(x => !demoJobIds.has(x.id));
  memoryStore.applications = memoryStore.applications.filter(x => !demoApplicationIds.has(x.id));
  memoryStore.notifications = memoryStore.notifications.filter(x => !demoNotificationIds.has(x.id) && !demoUserIds.has(x.recipientId) && !demoUserIds.has(x.actorId));
  memoryStore.comments = memoryStore.comments.filter(x => !demoCommentIds.has(x.id) && !demoUserIds.has(x.userId));
  memoryStore.conversations = memoryStore.conversations.filter(x => !demoConversationIds.has(x.id) && !(x.participants || []).some(p => demoUserIds.has(p.id)));
  memoryStore.messages = memoryStore.messages.filter(x => !demoMessageIds.has(x.id) && !demoConversationIds.has(x.conversationId) && !demoUserIds.has(x.senderId));
  memoryStore.reports = memoryStore.reports.filter(x => !demoReportIds.has(x.id) && !demoUserIds.has(x.reporterId));
  memoryStore.auditLogs = memoryStore.auditLogs.filter(x => !demoAuditIds.has(x.id) && !demoUserIds.has(x.adminId));
  memoryStore.follows = (memoryStore.follows || []).filter(x => !demoUserIds.has(x.followerId) && !demoUserIds.has(x.targetId));
  memoryStore.savedJobs = (memoryStore.savedJobs || []).filter(x => !demoUserIds.has(x.userId) && !demoJobIds.has(x.jobId));
  memoryStore.likedVideos = (memoryStore.likedVideos || []).filter(x => !demoUserIds.has(x.userId) && !demoVideoIds.has(x.videoId));
  memoryStore.reposts = (memoryStore.reposts || []).filter(x => !demoUserIds.has(x.userId) && !demoVideoIds.has(x.videoId));
}

/** Connect once, then load persisted data (or seed MongoDB on first run). */
export function initDatabase() {
  if (!initPromise) {
    initPromise = (async () => {
      const { db, isConnected } = await connectToDatabase();
      if (!isConnected || !db) return false;
      try {
        const meta = await db.collection('meta').findOne({ _id: 'seeded' });
        if (meta) {
          await loadFromMongo(db);
          if (process.env.NODE_ENV === 'production') {
            purgeProductionDemoData();
            await writeDiff(db);
          }
        } else {
          console.log('[Database] First run: seeding MongoDB with starter data...');
          await writeDiff(db);
          await db.collection('meta').updateOne(
            { _id: 'seeded' }, { $set: { at: new Date().toISOString() } }, { upsert: true });
          lastLoadAt = Date.now();
        }
        return true;
      } catch (err) {
        console.error('[Database] Initial load failed, using in-memory data:', err.message);
        return false;
      }
    })();
  }
  return initPromise;
}

/**
 * Connects to MongoDB Atlas using process.env.MONGODB_URI.
 * Caches the connection across serverless invocations.
 */
export async function connectToDatabase() {
  const uri = process.env.MONGODB_URI;
  const dbName = process.env.MONGODB_DB_NAME || 'videohub_jobs';

  if (!uri || uri.includes('username:password')) {
    return { client: null, db: null, isConnected: false };
  }

  if (cachedClient && cachedDb) {
    return { client: cachedClient, db: cachedDb, isConnected: true };
  }

  try {
    const client = new MongoClient(uri, {
      connectTimeoutMS: 8000,
      serverSelectionTimeoutMS: 8000
    });
    await client.connect();
    const db = client.db(dbName);
    cachedClient = client;
    cachedDb = db;
    isMongoConnected = true;
    console.log(`[Database] Connected to MongoDB Atlas database: ${dbName}`);
    return { client, db, isConnected: true };
  } catch (error) {
    console.warn('[Database] MongoDB connection failed (' + error.message + '). Using in-memory store.');
    return { client: null, db: null, isConnected: false };
  }
}

export function isDbLive() {
  return isMongoConnected;
}
